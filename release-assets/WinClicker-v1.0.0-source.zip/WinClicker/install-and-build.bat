@echo off
chcp 65001 >nul
title WinClicker - установка и сборка

set "PROJECT_DIR=%~dp0"
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%PROJECT_DIR%scripts\setup-and-build.ps1"

if errorlevel 1 (
    echo.
    echo Сборка завершилась с ошибкой. Текст ошибки находится выше.
    pause
    exit /b 1
)

echo.
echo Готово. Нажмите любую клавишу, чтобы закрыть это окно.
pause >nul
