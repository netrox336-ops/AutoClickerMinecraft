@echo off
start "" "%~dp0WinClicker.exe"
