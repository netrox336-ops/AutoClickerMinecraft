using System.ComponentModel;
using System.Runtime.InteropServices;
using WinClicker.Models;

namespace WinClicker.Services;

internal enum HotkeyAction
{
    ToggleClicker,
    SwitchButton
}

internal sealed record HookConfiguration(
    HotkeyBinding Toggle,
    HotkeyBinding SwitchButton,
    bool IgnoreExtraModifiers,
    bool SuppressHotkeys);

internal sealed class KeyboardHook : IDisposable
{
    private readonly NativeMethods.LowLevelKeyboardProc _callback;
    private readonly HashSet<int> _pressedKeys = new();
    private readonly HashSet<int> _suppressedKeys = new();
    private IntPtr _hookHandle;
    private HookConfiguration _configuration = new(
        HotkeyBinding.Disabled(),
        HotkeyBinding.Disabled(),
        true,
        false);
    private bool _suspended;
    private bool _disposed;

    internal KeyboardHook()
    {
        _callback = HookCallback;
    }

    internal event EventHandler<HotkeyAction>? HotkeyPressed;

    internal bool Suspended
    {
        get => _suspended;
        set
        {
            _suspended = value;
            _pressedKeys.Clear();
            _suppressedKeys.Clear();
        }
    }

    internal void Start()
    {
        ObjectDisposedException.ThrowIf(_disposed, this);
        if (_hookHandle != IntPtr.Zero)
        {
            return;
        }

        _hookHandle = NativeMethods.SetWindowsHookEx(
            NativeMethods.WhKeyboardLl,
            _callback,
            NativeMethods.GetModuleHandle(null),
            0);

        if (_hookHandle == IntPtr.Zero)
        {
            throw new Win32Exception(Marshal.GetLastWin32Error(), "Не удалось подключить глобальные горячие клавиши.");
        }
    }

    internal void UpdateConfiguration(AppSettings settings)
    {
        _configuration = new HookConfiguration(
            settings.ToggleHotkey.Clone(),
            settings.SwitchButtonHotkey.Clone(),
            settings.IgnoreExtraModifiers,
            settings.SuppressHotkeys);
    }

    private IntPtr HookCallback(int nCode, IntPtr wParam, IntPtr lParam)
    {
        if (nCode < 0)
        {
            return NativeMethods.CallNextHookEx(_hookHandle, nCode, wParam, lParam);
        }

        var message = unchecked((int)wParam.ToInt64());
        var isKeyDown = message is NativeMethods.WmKeyDown or NativeMethods.WmSysKeyDown;
        var isKeyUp = message is NativeMethods.WmKeyUp or NativeMethods.WmSysKeyUp;
        if (!isKeyDown && !isKeyUp)
        {
            return NativeMethods.CallNextHookEx(_hookHandle, nCode, wParam, lParam);
        }

        var data = Marshal.PtrToStructure<NativeMethods.KbdLlHookStruct>(lParam);
        var virtualKey = unchecked((int)data.vkCode);

        if (isKeyUp)
        {
            _pressedKeys.Remove(virtualKey);
            if (_suppressedKeys.Remove(virtualKey))
            {
                return new IntPtr(1);
            }

            return NativeMethods.CallNextHookEx(_hookHandle, nCode, wParam, lParam);
        }

        if (_suspended)
        {
            return NativeMethods.CallNextHookEx(_hookHandle, nCode, wParam, lParam);
        }

        if (!_pressedKeys.Add(virtualKey))
        {
            return _suppressedKeys.Contains(virtualKey)
                ? new IntPtr(1)
                : NativeMethods.CallNextHookEx(_hookHandle, nCode, wParam, lParam);
        }

        var configuration = _configuration;
        var control = NativeMethods.IsKeyDown(NativeMethods.VkControl);
        var alt = NativeMethods.IsKeyDown(NativeMethods.VkMenu);
        var shift = NativeMethods.IsKeyDown(NativeMethods.VkShift);
        var win = NativeMethods.IsKeyDown(NativeMethods.VkLWin) || NativeMethods.IsKeyDown(NativeMethods.VkRWin);

        var toggleMatches = configuration.Toggle.Matches(
            virtualKey, control, alt, shift, win, configuration.IgnoreExtraModifiers);
        var switchMatches = configuration.SwitchButton.Matches(
            virtualKey, control, alt, shift, win, configuration.IgnoreExtraModifiers);

        HotkeyAction? action = null;
        if (toggleMatches && switchMatches)
        {
            action = configuration.SwitchButton.ModifierCount > configuration.Toggle.ModifierCount
                ? HotkeyAction.SwitchButton
                : HotkeyAction.ToggleClicker;
        }
        else if (toggleMatches)
        {
            action = HotkeyAction.ToggleClicker;
        }
        else if (switchMatches)
        {
            action = HotkeyAction.SwitchButton;
        }

        if (action is null)
        {
            return NativeMethods.CallNextHookEx(_hookHandle, nCode, wParam, lParam);
        }

        try
        {
            HotkeyPressed?.Invoke(this, action.Value);
        }
        catch
        {
            // Исключение обработчика не должно нарушить глобальную цепочку клавиатурных хуков.
        }

        if (!configuration.SuppressHotkeys)
        {
            return NativeMethods.CallNextHookEx(_hookHandle, nCode, wParam, lParam);
        }

        _suppressedKeys.Add(virtualKey);
        return new IntPtr(1);
    }

    public void Dispose()
    {
        if (_disposed)
        {
            return;
        }

        _disposed = true;
        if (_hookHandle != IntPtr.Zero)
        {
            NativeMethods.UnhookWindowsHookEx(_hookHandle);
            _hookHandle = IntPtr.Zero;
        }

        GC.SuppressFinalize(this);
    }
}
