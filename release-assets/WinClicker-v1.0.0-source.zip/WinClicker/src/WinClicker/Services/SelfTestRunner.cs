using System.Windows.Forms;
using WinClicker.Models;

namespace WinClicker.Services;

internal static class SelfTestRunner
{
    internal static int Run()
    {
        try
        {
            var plainF6 = HotkeyBinding.FromKey(Keys.F6);
            Assert(plainF6.Matches((int)Keys.F6, false, false, true, false, true),
                "F6 должен срабатывать при дополнительно зажатом Shift.");
            Assert(!plainF6.Matches((int)Keys.F6, false, false, true, false, false),
                "F6 не должен срабатывать с лишним Shift в строгом режиме.");

            var ctrlF7 = HotkeyBinding.FromKey(Keys.F7, control: true);
            Assert(!ctrlF7.Matches((int)Keys.F7, false, false, false, false, true),
                "Ctrl+F7 не должен срабатывать без Ctrl.");
            Assert(ctrlF7.Matches((int)Keys.F7, true, false, true, false, true),
                "Ctrl+F7 должен принимать лишний Shift в совместимом режиме.");

            var low = new AppSettings { IntervalMs = 0 };
            low.Normalize();
            Assert(low.IntervalMs == 1, "Нижняя граница интервала должна быть 1 мс.");

            var high = new AppSettings { IntervalMs = 5000 };
            high.Normalize();
            Assert(high.IntervalMs == 1000, "Верхняя граница интервала должна быть 1000 мс.");
            return 0;
        }
        catch
        {
            return 1;
        }
    }

    private static void Assert(bool condition, string message)
    {
        if (!condition)
        {
            throw new InvalidOperationException(message);
        }
    }
}
