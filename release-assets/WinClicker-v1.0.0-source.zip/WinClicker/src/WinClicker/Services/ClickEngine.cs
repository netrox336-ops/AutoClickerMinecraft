using System.Runtime.InteropServices;
using WinClicker.Models;

namespace WinClicker.Services;

internal sealed class ClickEngine : IDisposable
{
    private readonly object _gate = new();
    private volatile int _intervalMs = 50;
    private volatile int _button = (int)ClickButton.Left;
    private ManualResetEvent? _stopSignal;
    private Thread? _worker;
    private bool _disposed;

    internal bool IsRunning
    {
        get
        {
            lock (_gate)
            {
                return _worker is { IsAlive: true };
            }
        }
    }

    internal void Start(int intervalMs, ClickButton button)
    {
        ObjectDisposedException.ThrowIf(_disposed, this);
        lock (_gate)
        {
            if (_worker is { IsAlive: true })
            {
                return;
            }

            _intervalMs = Math.Clamp(intervalMs, 1, 1000);
            _button = (int)button;
            var stopSignal = new ManualResetEvent(false);
            _stopSignal = stopSignal;
            _worker = new Thread(() => WorkerLoop(stopSignal))
            {
                IsBackground = true,
                Name = "WinClicker.ClickEngine",
                Priority = ThreadPriority.AboveNormal
            };
            _worker.Start();
        }
    }

    internal void Stop()
    {
        ManualResetEvent? stopSignal;
        Thread? worker;
        lock (_gate)
        {
            stopSignal = _stopSignal;
            worker = _worker;
            if (stopSignal is null || worker is null)
            {
                return;
            }

            stopSignal.Set();
        }

        var stopped = Thread.CurrentThread == worker;
        if (!stopped)
        {
            stopped = worker.Join(TimeSpan.FromSeconds(2));
        }

        if (!stopped)
        {
            return;
        }

        lock (_gate)
        {
            if (ReferenceEquals(_worker, worker))
            {
                _worker = null;
                _stopSignal = null;
                stopSignal.Dispose();
            }
        }
    }

    internal void UpdateInterval(int intervalMs)
    {
        _intervalMs = Math.Clamp(intervalMs, 1, 1000);
    }

    internal void UpdateButton(ClickButton button)
    {
        _button = (int)button;
    }

    private void WorkerLoop(ManualResetEvent stopSignal)
    {
        NativeMethods.timeBeginPeriod(1);
        try
        {
            while (!stopSignal.WaitOne(0))
            {
                SendClick((ClickButton)_button);
                if (stopSignal.WaitOne(_intervalMs))
                {
                    break;
                }
            }
        }
        finally
        {
            NativeMethods.timeEndPeriod(1);
        }
    }

    private static void SendClick(ClickButton button)
    {
        var downFlag = button == ClickButton.Left
            ? NativeMethods.MouseeventfLeftdown
            : NativeMethods.MouseeventfRightdown;
        var upFlag = button == ClickButton.Left
            ? NativeMethods.MouseeventfLeftup
            : NativeMethods.MouseeventfRightup;

        var inputs = new[]
        {
            CreateMouseInput(downFlag),
            CreateMouseInput(upFlag)
        };

        NativeMethods.SendInput((uint)inputs.Length, inputs, Marshal.SizeOf<NativeMethods.Input>());
    }

    private static NativeMethods.Input CreateMouseInput(uint flags)
    {
        return new NativeMethods.Input
        {
            type = NativeMethods.InputMouse,
            data = new NativeMethods.InputUnion
            {
                mouse = new NativeMethods.MouseInput
                {
                    dwFlags = flags
                }
            }
        };
    }

    public void Dispose()
    {
        if (_disposed)
        {
            return;
        }

        Stop();
        _disposed = true;
        GC.SuppressFinalize(this);
    }
}
