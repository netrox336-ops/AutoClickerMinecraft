using WinClicker.Models;

namespace WinClicker.UI;

internal sealed class HotkeyCaptureDialog : Form
{
    private static readonly Color Background = Color.FromArgb(17, 24, 39);
    private static readonly Color Card = Color.FromArgb(31, 41, 55);
    private static readonly Color TextPrimary = Color.FromArgb(243, 244, 246);
    private static readonly Color TextMuted = Color.FromArgb(156, 163, 175);
    private static readonly Color Accent = Color.FromArgb(59, 130, 246);

    private readonly Label _capturedLabel;

    internal HotkeyCaptureDialog(string actionName, HotkeyBinding current)
    {
        SelectedHotkey = current.Clone();

        Text = "Настройка горячей клавиши";
        ClientSize = new Size(470, 245);
        MinimumSize = MaximumSize = Size;
        StartPosition = FormStartPosition.CenterParent;
        FormBorderStyle = FormBorderStyle.FixedDialog;
        MaximizeBox = false;
        MinimizeBox = false;
        ShowInTaskbar = false;
        KeyPreview = true;
        BackColor = Background;
        ForeColor = TextPrimary;
        Font = new Font("Segoe UI", 10F);

        var title = new Label
        {
            Text = actionName,
            AutoSize = true,
            Font = new Font("Segoe UI Semibold", 14F),
            Location = new Point(22, 18),
            ForeColor = TextPrimary
        };

        var hint = new Label
        {
            Text = "Нажмите нужную клавишу или комбинацию.\nEsc — отмена, Delete — убрать назначение.",
            AutoSize = true,
            Location = new Point(24, 56),
            ForeColor = TextMuted
        };

        var captureCard = new Panel
        {
            Location = new Point(22, 106),
            Size = new Size(426, 55),
            BackColor = Card
        };

        _capturedLabel = new Label
        {
            Text = current.ToDisplayString(),
            Dock = DockStyle.Fill,
            TextAlign = ContentAlignment.MiddleCenter,
            Font = new Font("Segoe UI Semibold", 13F),
            ForeColor = Accent
        };
        captureCard.Controls.Add(_capturedLabel);

        var clearButton = CreateButton("Очистить", new Point(150, 184), new Size(92, 36), Card);
        clearButton.Click += (_, _) =>
        {
            SelectedHotkey = HotkeyBinding.Disabled();
            DialogResult = DialogResult.OK;
            Close();
        };

        var cancelButton = CreateButton("Отмена", new Point(252, 184), new Size(92, 36), Card);
        cancelButton.DialogResult = DialogResult.Cancel;

        var keepButton = CreateButton("Оставить", new Point(354, 184), new Size(94, 36), Accent);
        keepButton.Click += (_, _) =>
        {
            DialogResult = DialogResult.OK;
            Close();
        };

        Controls.AddRange(new Control[] { title, hint, captureCard, clearButton, cancelButton, keepButton });
        CancelButton = cancelButton;
    }

    internal HotkeyBinding SelectedHotkey { get; private set; }

    protected override void OnKeyDown(KeyEventArgs e)
    {
        base.OnKeyDown(e);

        if (e.KeyCode == Keys.Escape && e.Modifiers == Keys.None)
        {
            DialogResult = DialogResult.Cancel;
            Close();
            return;
        }

        if (e.KeyCode == Keys.Delete && e.Modifiers == Keys.None)
        {
            SelectedHotkey = HotkeyBinding.Disabled();
            DialogResult = DialogResult.OK;
            Close();
            return;
        }

        if (HotkeyBinding.IsModifierKey(e.KeyCode))
        {
            _capturedLabel.Text = "Добавьте обычную клавишу…";
            e.Handled = true;
            e.SuppressKeyPress = true;
            return;
        }

        SelectedHotkey = HotkeyBinding.FromKey(
            e.KeyCode,
            e.Control,
            e.Alt,
            e.Shift,
            NativeMethods.IsKeyDown(NativeMethods.VkLWin) || NativeMethods.IsKeyDown(NativeMethods.VkRWin));

        _capturedLabel.Text = SelectedHotkey.ToDisplayString();
        e.Handled = true;
        e.SuppressKeyPress = true;
        DialogResult = DialogResult.OK;
        Close();
    }

    private static Button CreateButton(string text, Point location, Size size, Color color)
    {
        return new Button
        {
            Text = text,
            Location = location,
            Size = size,
            BackColor = color,
            ForeColor = TextPrimary,
            FlatStyle = FlatStyle.Flat,
            Cursor = Cursors.Hand,
            TabStop = true,
            FlatAppearance = { BorderSize = 0 }
        };
    }
}
