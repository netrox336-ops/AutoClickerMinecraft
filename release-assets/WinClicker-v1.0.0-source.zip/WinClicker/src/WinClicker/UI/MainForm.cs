using WinClicker.Models;
using WinClicker.Services;

namespace WinClicker.UI;

internal sealed class MainForm : Form
{
    private static readonly Color Background = Color.FromArgb(11, 18, 32);
    private static readonly Color Card = Color.FromArgb(24, 34, 52);
    private static readonly Color CardLight = Color.FromArgb(34, 46, 67);
    private static readonly Color TextPrimary = Color.FromArgb(243, 244, 246);
    private static readonly Color TextMuted = Color.FromArgb(156, 163, 175);
    private static readonly Color Accent = Color.FromArgb(59, 130, 246);
    private static readonly Color Running = Color.FromArgb(34, 197, 94);
    private static readonly Color Stopped = Color.FromArgb(239, 68, 68);

    private readonly SettingsStore _settingsStore = new();
    private readonly ClickEngine _clickEngine = new();
    private readonly AppSettings _settings;
    private readonly Label _statusLabel;
    private readonly Label _modeLabel;
    private readonly Label _cpsLabel;
    private readonly Label _toggleHotkeyLabel;
    private readonly Label _switchHotkeyLabel;
    private readonly NumericUpDown _intervalInput;
    private readonly RadioButton _leftButton;
    private readonly RadioButton _rightButton;
    private readonly CheckBox _ignoreExtraModifiers;
    private readonly CheckBox _suppressHotkeys;
    private readonly CheckBox _minimizeToTray;
    private readonly Button _startStopButton;
    private readonly NotifyIcon _trayIcon;
    private KeyboardHook? _keyboardHook;
    private bool _loading = true;
    private bool _closing;
    private bool _trayHintShown;

    internal MainForm()
    {
        _settings = _settingsStore.Load();

        Text = "WinClicker — автокликер";
        ClientSize = new Size(600, 650);
        MinimumSize = MaximumSize = Size;
        StartPosition = FormStartPosition.CenterScreen;
        FormBorderStyle = FormBorderStyle.FixedSingle;
        MaximizeBox = false;
        BackColor = Background;
        ForeColor = TextPrimary;
        Font = new Font("Segoe UI", 10F);
        AutoScaleMode = AutoScaleMode.Dpi;

        var title = new Label
        {
            Text = "WinClicker",
            Font = new Font("Segoe UI Semibold", 22F),
            AutoSize = true,
            Location = new Point(24, 14),
            ForeColor = TextPrimary
        };
        var subtitle = new Label
        {
            Text = "Глобальный автокликер для Windows 11",
            Font = new Font("Segoe UI", 9.5F),
            AutoSize = true,
            Location = new Point(27, 52),
            ForeColor = TextMuted
        };

        var statusCard = CreateCard(new Point(20, 82), new Size(560, 105));
        _statusLabel = CreateLabel("●  ОСТАНОВЛЕН", new Point(20, 17), new Size(280, 30), 15F, Stopped, true);
        _modeLabel = CreateLabel("Текущая кнопка: левая", new Point(22, 57), new Size(285, 25), 10F, TextMuted);
        _startStopButton = CreateButton("Запустить", new Point(367, 24), new Size(170, 58), Accent, 12F);
        _startStopButton.Click += (_, _) => ToggleClicking();
        statusCard.Controls.AddRange(new Control[] { _statusLabel, _modeLabel, _startStopButton });

        var clickCard = CreateCard(new Point(20, 199), new Size(560, 145));
        clickCard.Controls.Add(CreateSectionTitle("ПАРАМЕТРЫ КЛИКА", new Point(18, 14)));
        clickCard.Controls.Add(CreateLabel("Интервал", new Point(20, 53), new Size(90, 25), 10F, TextPrimary));
        _intervalInput = new NumericUpDown
        {
            Location = new Point(112, 49),
            Size = new Size(102, 31),
            Minimum = 1,
            Maximum = 1000,
            Increment = 1,
            Value = 50,
            BackColor = CardLight,
            ForeColor = TextPrimary,
            BorderStyle = BorderStyle.FixedSingle,
            TextAlign = HorizontalAlignment.Center,
            Font = new Font("Segoe UI Semibold", 10F)
        };
        _intervalInput.ValueChanged += (_, _) => IntervalChanged();
        clickCard.Controls.Add(_intervalInput);
        clickCard.Controls.Add(CreateLabel("мс", new Point(220, 53), new Size(34, 25), 10F, TextMuted));
        _cpsLabel = CreateLabel("≈ 20 кликов/с", new Point(20, 94), new Size(220, 25), 9.5F, TextMuted);
        clickCard.Controls.Add(_cpsLabel);

        clickCard.Controls.Add(CreateLabel("Кнопка мыши", new Point(302, 24), new Size(190, 25), 10F, TextPrimary));
        _leftButton = CreateRadioButton("Левая", new Point(303, 57));
        _rightButton = CreateRadioButton("Правая", new Point(403, 57));
        _leftButton.CheckedChanged += (_, _) => MouseButtonChanged();
        _rightButton.CheckedChanged += (_, _) => MouseButtonChanged();
        clickCard.Controls.AddRange(new Control[] { _leftButton, _rightButton });
        clickCard.Controls.Add(CreateLabel("Смена работает без остановки", new Point(302, 94), new Size(230, 25), 9F, TextMuted));

        var hotkeyCard = CreateCard(new Point(20, 356), new Size(560, 215));
        hotkeyCard.Controls.Add(CreateSectionTitle("ГОРЯЧИЕ КЛАВИШИ", new Point(18, 14)));
        hotkeyCard.Controls.Add(CreateLabel("Включить / выключить", new Point(20, 52), new Size(185, 28), 10F, TextPrimary));
        _toggleHotkeyLabel = CreateHotkeyValue(new Point(210, 49));
        var editToggleButton = CreateButton("Изменить", new Point(431, 47), new Size(105, 34), CardLight, 9.5F);
        editToggleButton.Click += (_, _) => EditHotkey(HotkeyAction.ToggleClicker);
        hotkeyCard.Controls.AddRange(new Control[] { _toggleHotkeyLabel, editToggleButton });

        hotkeyCard.Controls.Add(CreateLabel("Сменить левую / правую", new Point(20, 94), new Size(190, 28), 10F, TextPrimary));
        _switchHotkeyLabel = CreateHotkeyValue(new Point(210, 91));
        var editSwitchButton = CreateButton("Изменить", new Point(431, 89), new Size(105, 34), CardLight, 9.5F);
        editSwitchButton.Click += (_, _) => EditHotkey(HotkeyAction.SwitchButton);
        hotkeyCard.Controls.AddRange(new Control[] { _switchHotkeyLabel, editSwitchButton });

        _ignoreExtraModifiers = CreateCheckBox(
            "Разрешать хоткей при других зажатых клавишах",
            new Point(20, 137),
            new Size(355, 27));
        _ignoreExtraModifiers.CheckedChanged += (_, _) => HookOptionChanged();
        _suppressHotkeys = CreateCheckBox(
            "Не передавать саму клавишу хоткея в игру",
            new Point(20, 172),
            new Size(355, 27));
        _suppressHotkeys.CheckedChanged += (_, _) => HookOptionChanged();
        hotkeyCard.Controls.AddRange(new Control[] { _ignoreExtraModifiers, _suppressHotkeys });

        _minimizeToTray = CreateCheckBox(
            "Сворачивать в системный трей",
            new Point(25, 583),
            new Size(285, 27));
        _minimizeToTray.CheckedChanged += (_, _) => MinimizeOptionChanged();

        var footer = new Label
        {
            Text = "1–1000 мс  •  настройки сохраняются автоматически",
            AutoSize = true,
            Location = new Point(26, 620),
            ForeColor = TextMuted,
            Font = new Font("Segoe UI", 8.5F)
        };

        Controls.AddRange(new Control[] { title, subtitle, statusCard, clickCard, hotkeyCard, _minimizeToTray, footer });

        var trayMenu = new ContextMenuStrip();
        trayMenu.Items.Add("Показать", null, (_, _) => RestoreFromTray());
        trayMenu.Items.Add("Включить / выключить", null, (_, _) => ToggleClicking());
        trayMenu.Items.Add(new ToolStripSeparator());
        trayMenu.Items.Add("Выход", null, (_, _) => Close());
        _trayIcon = new NotifyIcon
        {
            Text = "WinClicker",
            Icon = SystemIcons.Application,
            Visible = false,
            ContextMenuStrip = trayMenu
        };
        _trayIcon.DoubleClick += (_, _) => RestoreFromTray();

        ApplySettingsToInterface();
        _loading = false;
        UpdateStatus();

        Shown += (_, _) => InstallKeyboardHook();
        Resize += (_, _) => MinimizeIfNeeded();
        FormClosing += MainFormClosing;
    }

    private void InstallKeyboardHook()
    {
        try
        {
            _keyboardHook = new KeyboardHook();
            _keyboardHook.UpdateConfiguration(_settings);
            _keyboardHook.HotkeyPressed += KeyboardHookOnHotkeyPressed;
            _keyboardHook.Start();
        }
        catch (Exception exception)
        {
            _keyboardHook?.Dispose();
            _keyboardHook = null;
            MessageBox.Show(
                this,
                $"Глобальные хоткеи не запущены. Кнопки в окне продолжат работать.\n\n{exception.Message}",
                "WinClicker",
                MessageBoxButtons.OK,
                MessageBoxIcon.Warning);
        }
    }

    private void ApplySettingsToInterface()
    {
        _settings.Normalize();
        _intervalInput.Value = _settings.IntervalMs;
        _leftButton.Checked = _settings.ClickButton == ClickButton.Left;
        _rightButton.Checked = _settings.ClickButton == ClickButton.Right;
        _ignoreExtraModifiers.Checked = _settings.IgnoreExtraModifiers;
        _suppressHotkeys.Checked = _settings.SuppressHotkeys;
        _minimizeToTray.Checked = _settings.MinimizeToTray;
        UpdateHotkeyLabels();
        UpdateCpsLabel();
        UpdateModeLabel();
    }

    private void ToggleClicking()
    {
        if (_clickEngine.IsRunning)
        {
            _clickEngine.Stop();
        }
        else
        {
            _clickEngine.Start(_settings.IntervalMs, _settings.ClickButton);
        }

        UpdateStatus();
    }

    private void SwitchMouseButton()
    {
        _settings.ClickButton = _settings.ClickButton == ClickButton.Left
            ? ClickButton.Right
            : ClickButton.Left;
        _loading = true;
        _leftButton.Checked = _settings.ClickButton == ClickButton.Left;
        _rightButton.Checked = _settings.ClickButton == ClickButton.Right;
        _loading = false;
        _clickEngine.UpdateButton(_settings.ClickButton);
        UpdateModeLabel();
        SaveSettings();
    }

    private void KeyboardHookOnHotkeyPressed(object? sender, HotkeyAction action)
    {
        if (_closing || !IsHandleCreated)
        {
            return;
        }

        try
        {
            BeginInvoke(new Action(() =>
            {
                if (_closing)
                {
                    return;
                }

                if (action == HotkeyAction.ToggleClicker)
                {
                    ToggleClicking();
                }
                else
                {
                    SwitchMouseButton();
                }
            }));
        }
        catch (InvalidOperationException)
        {
            // Окно уже завершает работу.
        }
    }

    private void IntervalChanged()
    {
        if (_loading)
        {
            return;
        }

        _settings.IntervalMs = (int)_intervalInput.Value;
        _clickEngine.UpdateInterval(_settings.IntervalMs);
        UpdateCpsLabel();
        SaveSettings();
    }

    private void MouseButtonChanged()
    {
        if (_loading)
        {
            return;
        }

        _settings.ClickButton = _rightButton.Checked ? ClickButton.Right : ClickButton.Left;
        _clickEngine.UpdateButton(_settings.ClickButton);
        UpdateModeLabel();
        SaveSettings();
    }

    private void HookOptionChanged()
    {
        if (_loading)
        {
            return;
        }

        _settings.IgnoreExtraModifiers = _ignoreExtraModifiers.Checked;
        _settings.SuppressHotkeys = _suppressHotkeys.Checked;
        UpdateHookConfiguration();
        SaveSettings();
    }

    private void MinimizeOptionChanged()
    {
        if (_loading)
        {
            return;
        }

        _settings.MinimizeToTray = _minimizeToTray.Checked;
        SaveSettings();
    }

    private void EditHotkey(HotkeyAction action)
    {
        var current = action == HotkeyAction.ToggleClicker
            ? _settings.ToggleHotkey
            : _settings.SwitchButtonHotkey;
        var actionName = action == HotkeyAction.ToggleClicker
            ? "Включить / выключить кликер"
            : "Сменить левую / правую кнопку";

        if (_keyboardHook is not null)
        {
            _keyboardHook.Suspended = true;
        }

        try
        {
            using var dialog = new HotkeyCaptureDialog(actionName, current);
            if (dialog.ShowDialog(this) != DialogResult.OK)
            {
                return;
            }

            var candidate = dialog.SelectedHotkey;
            var other = action == HotkeyAction.ToggleClicker
                ? _settings.SwitchButtonHotkey
                : _settings.ToggleHotkey;
            if (!candidate.IsDisabled && candidate.Equals(other))
            {
                MessageBox.Show(
                    this,
                    "Эта комбинация уже назначена другому действию.",
                    "WinClicker",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
                return;
            }

            if (action == HotkeyAction.ToggleClicker)
            {
                _settings.ToggleHotkey = candidate;
            }
            else
            {
                _settings.SwitchButtonHotkey = candidate;
            }

            UpdateHotkeyLabels();
            UpdateHookConfiguration();
            UpdateStatus();
            SaveSettings();
        }
        finally
        {
            if (_keyboardHook is not null)
            {
                _keyboardHook.Suspended = false;
            }
        }
    }

    private void UpdateHookConfiguration()
    {
        _keyboardHook?.UpdateConfiguration(_settings);
    }

    private void UpdateStatus()
    {
        var running = _clickEngine.IsRunning;
        _statusLabel.Text = running ? "●  РАБОТАЕТ" : "●  ОСТАНОВЛЕН";
        _statusLabel.ForeColor = running ? Running : Stopped;
        _startStopButton.Text = running ? "Остановить" : "Запустить";
        _startStopButton.BackColor = running ? Stopped : Accent;
        _trayIcon.Text = running ? "WinClicker — работает" : "WinClicker — остановлен";
    }

    private void UpdateModeLabel()
    {
        _modeLabel.Text = _settings.ClickButton == ClickButton.Left
            ? "Текущая кнопка: левая"
            : "Текущая кнопка: правая";
    }

    private void UpdateCpsLabel()
    {
        var clicksPerSecond = 1000d / Math.Max(1, _settings.IntervalMs);
        _cpsLabel.Text = clicksPerSecond >= 100
            ? $"≈ {clicksPerSecond:0} кликов/с"
            : $"≈ {clicksPerSecond:0.#} кликов/с";
    }

    private void UpdateHotkeyLabels()
    {
        _toggleHotkeyLabel.Text = _settings.ToggleHotkey.ToDisplayString();
        _switchHotkeyLabel.Text = _settings.SwitchButtonHotkey.ToDisplayString();
    }

    private void MinimizeIfNeeded()
    {
        if (_closing || WindowState != FormWindowState.Minimized || !_settings.MinimizeToTray)
        {
            return;
        }

        Hide();
        _trayIcon.Visible = true;
        if (!_trayHintShown)
        {
            _trayHintShown = true;
            _trayIcon.ShowBalloonTip(1800, "WinClicker", "Приложение продолжает работать в трее.", ToolTipIcon.Info);
        }
    }

    private void RestoreFromTray()
    {
        Show();
        WindowState = FormWindowState.Normal;
        Activate();
        _trayIcon.Visible = false;
    }

    private void MainFormClosing(object? sender, FormClosingEventArgs e)
    {
        _closing = true;
        _clickEngine.Dispose();
        _keyboardHook?.Dispose();
        _trayIcon.Visible = false;
        _trayIcon.Dispose();
        SaveSettings();
    }

    private void SaveSettings()
    {
        _settingsStore.Save(_settings);
    }

    private static Panel CreateCard(Point location, Size size)
    {
        return new Panel
        {
            Location = location,
            Size = size,
            BackColor = Card
        };
    }

    private static Label CreateSectionTitle(string text, Point location)
    {
        return CreateLabel(text, location, new Size(260, 24), 9F, Accent, true);
    }

    private static Label CreateLabel(string text, Point location, Size size, float fontSize, Color color, bool semibold = false)
    {
        return new Label
        {
            Text = text,
            Location = location,
            Size = size,
            ForeColor = color,
            Font = new Font(semibold ? "Segoe UI Semibold" : "Segoe UI", fontSize),
            TextAlign = ContentAlignment.MiddleLeft
        };
    }

    private static Label CreateHotkeyValue(Point location)
    {
        return new Label
        {
            Location = location,
            Size = new Size(205, 34),
            BackColor = CardLight,
            ForeColor = TextPrimary,
            Font = new Font("Segoe UI Semibold", 9.5F),
            TextAlign = ContentAlignment.MiddleCenter,
            AutoEllipsis = true
        };
    }

    private static Button CreateButton(string text, Point location, Size size, Color color, float fontSize)
    {
        return new Button
        {
            Text = text,
            Location = location,
            Size = size,
            BackColor = color,
            ForeColor = TextPrimary,
            Font = new Font("Segoe UI Semibold", fontSize),
            FlatStyle = FlatStyle.Flat,
            Cursor = Cursors.Hand,
            FlatAppearance = { BorderSize = 0 }
        };
    }

    private static Button CreateButton(string text, Point location, Size size, Color color)
    {
        return CreateButton(text, location, size, color, 10F);
    }

    private static RadioButton CreateRadioButton(string text, Point location)
    {
        return new RadioButton
        {
            Text = text,
            Location = location,
            Size = new Size(95, 28),
            ForeColor = TextPrimary,
            BackColor = Card,
            Cursor = Cursors.Hand
        };
    }

    private static CheckBox CreateCheckBox(string text, Point location, Size size)
    {
        return new CheckBox
        {
            Text = text,
            Location = location,
            Size = size,
            ForeColor = TextMuted,
            BackColor = Color.Transparent,
            Cursor = Cursors.Hand
        };
    }
}
