# Changelog

## 2.1.0 — Core

- интерфейс полностью перестроен в новой дизайн-системе;
- устранено наслаивание текста навигации при hover/repaint;
- стандартные белые ComboBox/NumericUpDown заменены собственными тёмными контролами;
- добавлены плавные hover, press, toggle, segmented и page-transition анимации;
- удалены Ultra Mode, Burst Mode, Random Interval, Double/Triple Click и Benchmark;
- оставлена единая интервальная настройка `1–1000 ms`;
- добавлены два независимых click worker: LMB и RMB;
- добавлены отдельные Toggle/Hold/Press хоткеи для каждого worker;
- Mouse 4 Hold → LMB и Mouse 5 Hold → RMB стали настройками по умолчанию;
- LMB и RMB могут отправляться одновременно;
- Panic F12 останавливает оба канала и снимает состояния кнопок;
- оверлей стал click-through/no-activate и следует за монитором foreground-игры;
- оверлей периодически восстанавливает `HWND_TOPMOST` для Minecraft fullscreen;
- добавлена автоматическая миграция хоткеев из схемы настроек 2.0;
- встроенный `--self-test` обновлён под схему 3.

## 2.0.0

- Burst, Random Interval, Ultra 2.0, Benchmark, Panic Key и игровой Overlay;
- глобальные Toggle/Hold/Press хоткеи.

## 1.1.0

- ранний Ultra-профиль и базовый глобальный хоткей.
