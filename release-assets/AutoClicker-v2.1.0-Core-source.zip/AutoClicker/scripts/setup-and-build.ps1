﻿param(
    [switch]$SkipInstall
)

$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"

$projectRoot = Split-Path -Parent $PSScriptRoot
$projectFile = Join-Path $projectRoot "src\WinClicker\WinClicker.csproj"
$distRoot = Join-Path $projectRoot "dist"
$packageDir = Join-Path $distRoot "AutoClicker-v2.1.0-Win11-x64"
$packageZip = Join-Path $distRoot "AutoClicker-v2.1.0-Win11-x64.zip"

function Find-DotNet8 {
    $candidates = @()
    $command = Get-Command dotnet -ErrorAction SilentlyContinue
    if ($null -ne $command) {
        $candidates += $command.Source
    }

    $candidates += (Join-Path $env:ProgramFiles "dotnet\dotnet.exe")
    if (${env:ProgramFiles(x86)}) {
        $candidates += (Join-Path ${env:ProgramFiles(x86)} "dotnet\dotnet.exe")
    }

    foreach ($candidate in ($candidates | Select-Object -Unique)) {
        if (-not (Test-Path $candidate)) {
            continue
        }

        $versionText = (& $candidate --version 2>$null)
        if ($LASTEXITCODE -eq 0 -and $versionText -match '^(\d+)\.') {
            if ([int]$Matches[1] -ge 8) {
                return $candidate
            }
        }
    }

    return $null
}

Write-Host ""
Write-Host " AUTO CLICKER 2.1.0 CORE — подготовка сборки" -ForegroundColor Red
Write-Host ""

if (-not (Test-Path $projectFile -PathType Leaf)) {
    throw "Файл проекта не найден: $projectFile. Полностью распакуйте ZIP-архив перед запуском."
}

$dotnet = Find-DotNet8
if ($null -eq $dotnet -and -not $SkipInstall) {
    $winget = Get-Command winget -ErrorAction SilentlyContinue
    if ($null -eq $winget) {
        throw ".NET 8 SDK не найден, а winget недоступен. Установите .NET 8 SDK с https://dotnet.microsoft.com/download/dotnet/8.0 и повторите запуск."
    }

    Write-Host "[1/5] .NET 8 SDK не найден. Устанавливаю через winget..." -ForegroundColor Yellow
    & $winget.Source install --id Microsoft.DotNet.SDK.8 --exact --source winget --accept-package-agreements --accept-source-agreements
    if ($LASTEXITCODE -ne 0) {
        throw "winget не смог установить .NET 8 SDK (код $LASTEXITCODE)."
    }

    $dotnet = Find-DotNet8
}
elseif ($null -eq $dotnet) {
    throw ".NET 8 SDK не найден. Запустите install-and-build.bat или установите SDK вручную."
}
else {
    Write-Host "[1/5] .NET 8 SDK найден: $(& $dotnet --version)" -ForegroundColor Green
}

if ($null -eq $dotnet) {
    throw ".NET 8 SDK установлен, но dotnet.exe не найден. Перезапустите Windows и снова откройте install-and-build.bat."
}

Write-Host "[2/5] Восстанавливаю компоненты проекта..." -ForegroundColor Cyan
& $dotnet restore $projectFile --nologo
if ($LASTEXITCODE -ne 0) {
    throw "dotnet restore завершился с кодом $LASTEXITCODE."
}

if (Test-Path $packageDir) {
    Remove-Item $packageDir -Recurse -Force
}
if (Test-Path $packageZip) {
    Remove-Item $packageZip -Force
}
New-Item -ItemType Directory -Path $packageDir -Force | Out-Null

Write-Host "[3/5] Собираю автономный Win11 x64 EXE..." -ForegroundColor Cyan
& $dotnet publish $projectFile `
    --configuration Release `
    --runtime win-x64 `
    --self-contained true `
    --output $packageDir `
    --nologo `
    -p:PublishSingleFile=true `
    -p:EnableCompressionInSingleFile=true `
    -p:IncludeNativeLibrariesForSelfExtract=true `
    -p:DebugType=None `
    -p:DebugSymbols=false
if ($LASTEXITCODE -ne 0) {
    throw "dotnet publish завершился с кодом $LASTEXITCODE."
}

Copy-Item (Join-Path $projectRoot "README.md") (Join-Path $packageDir "README.md") -Force
Copy-Item (Join-Path $projectRoot "CHANGELOG.md") (Join-Path $packageDir "CHANGELOG.md") -Force
Copy-Item (Join-Path $projectRoot "docs\TESTING.md") (Join-Path $packageDir "TESTING.md") -Force
Copy-Item (Join-Path $projectRoot "docs\DESIGN_SYSTEM.md") (Join-Path $packageDir "DESIGN_SYSTEM.md") -Force
Copy-Item (Join-Path $PSScriptRoot "START.bat") (Join-Path $packageDir "START.bat") -Force

Write-Host "[4/5] Запускаю встроенные тесты..." -ForegroundColor Cyan
$testProcess = Start-Process `
    -FilePath (Join-Path $packageDir "AutoClicker.exe") `
    -ArgumentList "--self-test" `
    -Wait `
    -PassThru
if ($testProcess.ExitCode -ne 0) {
    throw "Встроенные тесты не пройдены (код $($testProcess.ExitCode))."
}
Write-Host "      Тесты пройдены." -ForegroundColor Green

Write-Host "[5/5] Упаковываю портативную версию..." -ForegroundColor Cyan
Compress-Archive -Path (Join-Path $packageDir "*") -DestinationPath $packageZip -CompressionLevel Optimal

Write-Host ""
Write-Host " СБОРКА ГОТОВА" -ForegroundColor Green
Write-Host " EXE:    $(Join-Path $packageDir 'AutoClicker.exe')"
Write-Host " Архив:  $packageZip"
Write-Host ""

Write-Host "Запускаю AUTO CLICKER..." -ForegroundColor Green
Start-Process -FilePath (Join-Path $packageDir "AutoClicker.exe")
