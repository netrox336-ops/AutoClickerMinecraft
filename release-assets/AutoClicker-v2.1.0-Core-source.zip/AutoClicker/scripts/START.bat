@echo off
start "" "%~dp0AutoClicker.exe"
