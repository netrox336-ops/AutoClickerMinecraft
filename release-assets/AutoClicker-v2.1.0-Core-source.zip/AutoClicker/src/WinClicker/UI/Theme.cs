using System.Drawing.Drawing2D;

namespace WinClicker.UI;

internal static class Theme
{
    internal static readonly Color Background = Color.FromArgb(10, 12, 16);
    internal static readonly Color Sidebar = Color.FromArgb(7, 9, 12);
    internal static readonly Color Surface = Color.FromArgb(16, 19, 25);
    internal static readonly Color SurfaceRaised = Color.FromArgb(22, 26, 34);
    internal static readonly Color SurfaceHover = Color.FromArgb(29, 34, 43);
    internal static readonly Color Border = Color.FromArgb(43, 49, 61);
    internal static readonly Color BorderSoft = Color.FromArgb(29, 34, 43);
    internal static readonly Color Accent = Color.FromArgb(255, 54, 48);
    internal static readonly Color AccentBright = Color.FromArgb(255, 90, 72);
    internal static readonly Color AccentDark = Color.FromArgb(178, 28, 30);
    internal static readonly Color AccentMuted = Color.FromArgb(66, 24, 29);
    internal static readonly Color TextPrimary = Color.FromArgb(246, 247, 249);
    internal static readonly Color TextSecondary = Color.FromArgb(181, 187, 199);
    internal static readonly Color TextMuted = Color.FromArgb(111, 120, 137);
    internal static readonly Color Success = Color.FromArgb(56, 221, 137);
    internal static readonly Color SuccessMuted = Color.FromArgb(20, 62, 45);
    internal static readonly Color Warning = Color.FromArgb(255, 190, 82);

    internal static Font Font(float size, bool semibold = false)
        => new("Segoe UI Variable Text", size, semibold ? FontStyle.Bold : FontStyle.Regular, GraphicsUnit.Point);

    internal static GraphicsPath RoundedRectangle(Rectangle bounds, int radius)
    {
        var diameter = Math.Max(2, Math.Min(radius * 2, Math.Min(bounds.Width, bounds.Height)));
        var arc = new Rectangle(bounds.Location, new Size(diameter, diameter));
        var path = new GraphicsPath();
        path.AddArc(arc, 180, 90);
        arc.X = bounds.Right - diameter;
        path.AddArc(arc, 270, 90);
        arc.Y = bounds.Bottom - diameter;
        path.AddArc(arc, 0, 90);
        arc.X = bounds.Left;
        path.AddArc(arc, 90, 90);
        path.CloseFigure();
        return path;
    }

    internal static Color Blend(Color from, Color to, float amount)
    {
        amount = Math.Clamp(amount, 0F, 1F);
        return Color.FromArgb(
            (int)(from.A + (to.A - from.A) * amount),
            (int)(from.R + (to.R - from.R) * amount),
            (int)(from.G + (to.G - from.G) * amount),
            (int)(from.B + (to.B - from.B) * amount));
    }
}
