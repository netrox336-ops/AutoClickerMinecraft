using WinClicker.Models;
using WinClicker.Services;

namespace WinClicker.UI;

internal sealed partial class MainForm
{
    private void BuildLayout()
    {
        var sidebar = new Panel
        {
            Location = Point.Empty,
            Size = new Size(202, 700),
            BackColor = Theme.Sidebar
        };
        sidebar.Controls.Add(new Panel
        {
            Location = new Point(201, 0),
            Size = new Size(1, 700),
            BackColor = Theme.BorderSoft
        });

        var logo = new LogoMark { Location = new Point(22, 18) };
        var brand = CreateLabel("AUTO CLICKER", new Point(76, 17), new Size(115, 27), 11.2F, Theme.TextPrimary, true);
        var brandCaption = CreateLabel("CORE  •  PRECISE", new Point(77, 42), new Size(112, 18), 7.2F, Theme.TextMuted);
        sidebar.Controls.AddRange(new Control[] { logo, brand, brandCaption });

        AddNavigationButton(sidebar, "Управление", "УПРАВЛЕНИЕ", AppIcon.Home, 105);
        AddNavigationButton(sidebar, "Хоткеи", "ХОТКЕИ", AppIcon.Hotkeys, 155);
        AddNavigationButton(sidebar, "Оверлей", "ОВЕРЛЕЙ", AppIcon.Overlay, 205);

        var panicButton = CreateButton("EMERGENCY STOP", new Point(15, 612), new Size(172, 44), ButtonStyle.Danger, AppIcon.Panic);
        panicButton.Click += (_, _) => PanicStop();
        var version = CreateLabel("v2.1.0  •  WIN 11 x64", new Point(23, 668), new Size(164, 18), 7.2F, Theme.TextMuted);
        sidebar.Controls.AddRange(new Control[] { panicButton, version });

        var titleBar = new Panel
        {
            Location = new Point(202, 0),
            Size = new Size(898, 62),
            BackColor = Theme.Background
        };
        titleBar.Controls.Add(new Panel
        {
            Location = new Point(0, 61),
            Size = new Size(898, 1),
            BackColor = Theme.BorderSoft
        });
        _pageTitle = CreateLabel("УПРАВЛЕНИЕ", new Point(29, 16), new Size(420, 30), 13F, Theme.TextPrimary, true);
        _topStatusLabel = CreateLabel("●  READY", new Point(655, 19), new Size(105, 24), 8F, Theme.Success, true);
        _topStatusLabel.TextAlign = ContentAlignment.MiddleRight;
        var minimize = CreateButton(string.Empty, new Point(776, 13), new Size(46, 36), ButtonStyle.Ghost, AppIcon.Minus);
        minimize.Click += (_, _) => WindowState = FormWindowState.Minimized;
        var close = CreateButton(string.Empty, new Point(832, 13), new Size(46, 36), ButtonStyle.Danger, AppIcon.Close);
        close.Click += (_, _) => Close();
        titleBar.Controls.AddRange(new Control[] { _pageTitle, _topStatusLabel, minimize, close });
        titleBar.MouseDown += DragWindow;
        _pageTitle.MouseDown += DragWindow;

        _pageHost = new Panel
        {
            Location = new Point(202, 62),
            Size = new Size(898, 638),
            BackColor = Theme.Background
        };
        RegisterPage("Управление", BuildControlPage());
        RegisterPage("Хоткеи", BuildHotkeysPage());
        RegisterPage("Оверлей", BuildOverlayPage());

        Controls.AddRange(new Control[] { sidebar, titleBar, _pageHost });
        sidebar.BringToFront();
        titleBar.BringToFront();
        ShowPage("Управление", animate: false);
    }

    private Panel BuildControlPage()
    {
        var page = CreatePage();
        AddPageIntro(page, "КЛИКЕР", "Один интервал. Два независимых канала. Ничего лишнего.");

        var intervalCard = CreateCard(new Point(32, 78), new Size(834, 158));
        intervalCard.Controls.Add(CreateCardTitle("ИНТЕРВАЛ МЕЖДУ КЛИКАМИ", new Point(22, 16)));
        intervalCard.Controls.Add(CreateLabel("Применяется к LMB и RMB сразу", new Point(22, 38), new Size(320, 20), 8F, Theme.TextMuted));
        _intervalValueLabel = CreateLabel("50 ms", new Point(650, 12), new Size(160, 38), 20F, Theme.TextPrimary, true);
        _intervalValueLabel.TextAlign = ContentAlignment.MiddleRight;
        _intervalSlider = new ValueSlider
        {
            Location = new Point(22, 58),
            Size = new Size(790, 34),
            Minimum = 1,
            Maximum = 1000,
            Logarithmic = true
        };
        _intervalSlider.ValueChanged += (_, _) => IntervalChanged(_intervalSlider.Value);
        intervalCard.Controls.AddRange(new Control[] { _intervalValueLabel, _intervalSlider });

        var presets = new[] { 1, 5, 10, 25, 50, 100, 250, 500 };
        for (var index = 0; index < presets.Length; index++)
        {
            var value = presets[index];
            var preset = CreateButton($"{value} ms", new Point(22 + index * 97, 105), new Size(87, 34), ButtonStyle.Ghost);
            preset.Font = Theme.Font(8F, true);
            preset.Click += (_, _) => IntervalChanged(value);
            _intervalPresetButtons[value] = preset;
            intervalCard.Controls.Add(preset);
        }

        var leftCard = BuildChannelCard(ClickButton.Left, new Point(32, 252));
        var rightCard = BuildChannelCard(ClickButton.Right, new Point(457, 252));

        var statsCard = CreateCard(new Point(32, 510), new Size(834, 92));
        statsCard.Controls.Add(CreateCardTitle("СЕССИЯ", new Point(22, 13)));
        _totalClicksLabel = CreateLabel("0 кликов", new Point(22, 35), new Size(300, 36), 17F, Theme.TextPrimary, true);
        _combinedRateLabel = CreateLabel("0 CPS", new Point(350, 35), new Size(220, 36), 13F, Theme.TextSecondary, true);
        _combinedRateLabel.TextAlign = ContentAlignment.MiddleCenter;
        var reset = CreateButton("Сбросить", new Point(684, 25), new Size(126, 42), ButtonStyle.Ghost, AppIcon.Reset);
        reset.Click += (_, _) => ResetStatistics();
        statsCard.Controls.AddRange(new Control[] { _totalClicksLabel, _combinedRateLabel, reset });

        page.Controls.AddRange(new Control[] { intervalCard, leftCard, rightCard, statsCard });
        return page;
    }

    private SurfaceCard BuildChannelCard(ClickButton button, Point location)
    {
        var isLeft = button == ClickButton.Left;
        var card = CreateCard(location, new Size(409, 240));
        var iconBox = new SurfaceCard
        {
            Location = new Point(20, 18),
            Size = new Size(45, 45),
            Radius = 12,
            BackColor = Theme.AccentMuted,
            BorderColor = Theme.AccentDark
        };
        iconBox.Paint += (_, e) => VectorIcons.Draw(e.Graphics,
            isLeft ? AppIcon.MouseLeft : AppIcon.MouseRight,
            new Rectangle(13, 11, 20, 23),
            Theme.AccentBright,
            1.8F);
        card.Controls.Add(iconBox);
        card.Controls.Add(CreateLabel(isLeft ? "ЛЕВАЯ КНОПКА" : "ПРАВАЯ КНОПКА", new Point(78, 17), new Size(200, 24), 10F, Theme.TextPrimary, true));
        card.Controls.Add(CreateLabel(isLeft ? "LMB channel" : "RMB channel", new Point(79, 40), new Size(180, 20), 7.8F, Theme.TextMuted));
        var status = CreateLabel("●  OFF", new Point(287, 22), new Size(101, 24), 8F, Theme.TextMuted, true);
        status.TextAlign = ContentAlignment.MiddleRight;
        card.Controls.Add(status);

        card.Controls.Add(CreateLabel("ХОТКЕЙ", new Point(21, 79), new Size(90, 18), 7.3F, Theme.TextMuted, true));
        var hotkey = CreateLabel("Mouse 4", new Point(21, 97), new Size(210, 28), 13F, Theme.TextPrimary, true);
        var mode = CreateLabel("HOLD", new Point(268, 98), new Size(118, 25), 8F, Theme.AccentBright, true);
        mode.TextAlign = ContentAlignment.MiddleRight;
        var action = CreateButton("Запустить", new Point(20, 143), new Size(369, 48), ButtonStyle.Primary, AppIcon.Cursor);
        action.Click += (_, _) => ToggleChannel(button);
        var rate = CreateLabel("0 CPS", new Point(22, 201), new Size(170, 22), 8F, Theme.TextSecondary, true);
        var hint = CreateLabel("можно одновременно", new Point(202, 201), new Size(185, 22), 7.5F, Theme.TextMuted);
        hint.TextAlign = ContentAlignment.MiddleRight;
        card.Controls.AddRange(new Control[] { hotkey, mode, action, rate, hint });

        if (isLeft)
        {
            _leftStatusLabel = status;
            _leftHotkeyHomeLabel = hotkey;
            _leftModeHomeLabel = mode;
            _leftActionButton = action;
            _leftRateLabel = rate;
        }
        else
        {
            _rightStatusLabel = status;
            _rightHotkeyHomeLabel = hotkey;
            _rightModeHomeLabel = mode;
            _rightActionButton = action;
            _rightRateLabel = rate;
        }

        return card;
    }

    private Panel BuildHotkeysPage()
    {
        var page = CreatePage();
        AddPageIntro(page, "ГОРЯЧИЕ КЛАВИШИ", "LMB и RMB назначаются отдельно и больше не требуют переключения режима.");

        var left = BuildHotkeyCard(
            ClickButton.Left,
            new Point(32, 82),
            "ЛЕВЫЙ КЛИК  •  LMB",
            "Например Mouse 4 в режиме Hold");
        var right = BuildHotkeyCard(
            ClickButton.Right,
            new Point(32, 224),
            "ПРАВЫЙ КЛИК  •  RMB",
            "Например Mouse 5 в режиме Hold");

        var panic = CreateCard(new Point(32, 366), new Size(834, 104));
        panic.BorderColor = Color.FromArgb(90, Theme.AccentDark);
        panic.Controls.Add(CreateLabel("PANIC KEY", new Point(22, 16), new Size(170, 22), 9F, Theme.AccentBright, true));
        panic.Controls.Add(CreateLabel("Мгновенно останавливает оба канала и отпускает кнопки мыши", new Point(22, 40), new Size(475, 34), 8F, Theme.TextSecondary));
        _panicHotkeyLabel = CreateLabel("F12", new Point(515, 31), new Size(130, 34), 12F, Theme.TextPrimary, true);
        _panicHotkeyLabel.TextAlign = ContentAlignment.MiddleCenter;
        var changePanic = CreateButton("Изменить", new Point(663, 29), new Size(148, 40), ButtonStyle.Danger);
        changePanic.Click += (_, _) => CaptureHotkey(HotkeyAction.Panic);
        panic.Controls.AddRange(new Control[] { _panicHotkeyLabel, changePanic });

        var behavior = CreateCard(new Point(32, 488), new Size(834, 132));
        behavior.Controls.Add(CreateCardTitle("ПОВЕДЕНИЕ", new Point(22, 14)));
        AddToggleRow(behavior, "Работать при зажатых W / Space / Shift", "Лишние модификаторы не блокируют хоткей", 42, out _ignoreModifiersToggle);
        AddToggleRow(behavior, "Не передавать хоткей в игру", "Mouse 4/5 используется только кликером", 74, out _suppressHotkeysToggle);
        AddToggleRow(behavior, "Сворачивать в трей", "Хоткеи продолжают работать в фоне", 106, out _minimizeToTrayToggle);

        page.Controls.AddRange(new Control[] { left, right, panic, behavior });
        return page;
    }

    private SurfaceCard BuildHotkeyCard(ClickButton button, Point location, string title, string description)
    {
        var card = CreateCard(location, new Size(834, 124));
        card.Controls.Add(CreateLabel(title, new Point(22, 17), new Size(280, 22), 9.5F, Theme.TextPrimary, true));
        card.Controls.Add(CreateLabel(description, new Point(22, 42), new Size(300, 20), 8F, Theme.TextMuted));
        card.Controls.Add(CreateLabel("Toggle — вкл/выкл  •  Hold — пока держите  •  Press — один клик", new Point(22, 76), new Size(405, 24), 7.7F, Theme.TextSecondary));

        var hotkeyLabel = CreateLabel("Mouse 4", new Point(438, 20), new Size(132, 38), 11F, Theme.TextPrimary, true);
        hotkeyLabel.TextAlign = ContentAlignment.MiddleCenter;
        var change = CreateButton("Изменить", new Point(580, 20), new Size(118, 38), ButtonStyle.Secondary);
        change.Click += (_, _) => CaptureHotkey(button == ClickButton.Left ? HotkeyAction.LeftClicker : HotkeyAction.RightClicker);
        var mode = new SegmentedControl
        {
            Location = new Point(438, 69),
            Size = new Size(373, 38),
            Options = new[] { "TOGGLE", "HOLD", "PRESS" }
        };
        mode.SelectedIndexChanged += (_, _) => HotkeyModeChanged(button, mode.SelectedIndex);
        card.Controls.AddRange(new Control[] { hotkeyLabel, change, mode });

        if (button == ClickButton.Left)
        {
            _leftHotkeySettingsLabel = hotkeyLabel;
            _leftModeControl = mode;
        }
        else
        {
            _rightHotkeySettingsLabel = hotkeyLabel;
            _rightModeControl = mode;
        }
        return card;
    }

    private Panel BuildOverlayPage()
    {
        var page = CreatePage();
        AddPageIntro(page, "ИГРОВОЙ ОВЕРЛЕЙ", "Компактный индикатор без захвата фокуса и лишней информации.");

        var previewCard = CreateCard(new Point(32, 82), new Size(834, 196));
        previewCard.Controls.Add(CreateCardTitle("ПРЕДПРОСМОТР", new Point(22, 16)));
        var stage = new SurfaceCard
        {
            Location = new Point(22, 49),
            Size = new Size(790, 125),
            Radius = 14,
            BackColor = Theme.Background,
            BorderColor = Theme.BorderSoft
        };
        var preview = new SurfaceCard
        {
            Location = new Point(241, 26),
            Size = new Size(308, 73),
            Radius = 15,
            BackColor = Theme.SurfaceRaised,
            BorderColor = Theme.AccentDark
        };
        _overlayPreviewDot = CreateLabel("●", new Point(18, 19), new Size(20, 25), 11F, Theme.Accent, true);
        _overlayPreviewTitle = CreateLabel("AUTO CLICKER", new Point(47, 10), new Size(220, 25), 9.3F, Theme.TextPrimary, true);
        _overlayPreviewDetails = CreateLabel("OFF  •  интервал 50 ms", new Point(47, 36), new Size(232, 22), 8F, Theme.TextSecondary);
        preview.Controls.AddRange(new Control[] { _overlayPreviewDot, _overlayPreviewTitle, _overlayPreviewDetails });
        stage.Controls.Add(preview);
        previewCard.Controls.Add(stage);

        var settings = CreateCard(new Point(32, 296), new Size(834, 194));
        settings.Controls.Add(CreateCardTitle("НАСТРОЙКИ", new Point(22, 15)));
        settings.Controls.Add(CreateLabel("Показывать поверх игры", new Point(22, 48), new Size(260, 24), 9F, Theme.TextPrimary, true));
        _overlayEnabledToggle = new AnimatedToggle { Location = new Point(292, 47) };
        _overlayEnabledToggle.CheckedChanged += (_, _) => OverlaySettingsChanged();
        settings.Controls.Add(_overlayEnabledToggle);
        settings.Controls.Add(CreateLabel("ПРОЗРАЧНОСТЬ", new Point(22, 91), new Size(170, 18), 7.3F, Theme.TextMuted, true));
        _overlayOpacityLabel = CreateLabel("82%", new Point(290, 87), new Size(56, 24), 8.5F, Theme.TextSecondary, true);
        _overlayOpacityLabel.TextAlign = ContentAlignment.MiddleRight;
        _overlayOpacitySlider = new ValueSlider
        {
            Location = new Point(20, 112),
            Size = new Size(330, 32),
            Minimum = 35,
            Maximum = 100,
            Logarithmic = false
        };
        _overlayOpacitySlider.ValueChanged += (_, _) => OverlaySettingsChanged();
        settings.Controls.AddRange(new Control[] { _overlayOpacityLabel, _overlayOpacitySlider });
        settings.Controls.Add(CreateLabel("УГОЛ ЭКРАНА", new Point(392, 48), new Size(180, 18), 7.3F, Theme.TextMuted, true));
        _overlayCornerControl = new SegmentedControl
        {
            Location = new Point(392, 72),
            Size = new Size(419, 44),
            Options = new[] { "↖", "↗", "↙", "↘" }
        };
        _overlayCornerControl.SelectedIndexChanged += (_, _) => OverlaySettingsChanged();
        settings.Controls.Add(_overlayCornerControl);
        settings.Controls.Add(CreateLabel("Следует за монитором активной игры", new Point(393, 127), new Size(390, 22), 8F, Theme.TextSecondary));

        var compatibility = CreateCard(new Point(32, 508), new Size(834, 96));
        compatibility.BorderColor = Color.FromArgb(70, Theme.Success);
        compatibility.Controls.Add(CreateLabel("FULLSCREEN READY", new Point(22, 16), new Size(190, 22), 8.5F, Theme.Success, true));
        compatibility.Controls.Add(CreateLabel(
            "Оверлей — отдельное click-through окно. Он отслеживает экран Minecraft и восстанавливает TOPMOST без перехвата управления.",
            new Point(22, 40),
            new Size(780, 38),
            8F,
            Theme.TextSecondary));

        page.Controls.AddRange(new Control[] { previewCard, settings, compatibility });
        return page;
    }

    private void AddToggleRow(SurfaceCard card, string title, string subtitle, int y, out AnimatedToggle toggle)
    {
        card.Controls.Add(CreateLabel(title, new Point(22, y - 4), new Size(360, 21), 8.5F, Theme.TextPrimary, true));
        card.Controls.Add(CreateLabel(subtitle, new Point(397, y - 4), new Size(335, 21), 7.6F, Theme.TextMuted));
        toggle = new AnimatedToggle { Location = new Point(765, y - 5) };
        toggle.CheckedChanged += (_, _) => BehaviorSettingsChanged();
        card.Controls.Add(toggle);
    }

    private void AddNavigationButton(Panel sidebar, string pageName, string text, AppIcon icon, int y)
    {
        var button = CreateButton(text, new Point(14, y), new Size(174, 42), ButtonStyle.Navigation, icon);
        button.Click += (_, _) => ShowPage(pageName);
        _navButtons[pageName] = button;
        sidebar.Controls.Add(button);
    }

    private void RegisterPage(string name, Panel page)
    {
        page.Visible = false;
        page.Location = Point.Empty;
        _pages[name] = page;
        _pageHost.Controls.Add(page);
    }

    private static Panel CreatePage()
    {
        return new Panel
        {
            Size = new Size(898, 638),
            BackColor = Theme.Background
        };
    }

    private static SurfaceCard CreateCard(Point location, Size size)
    {
        return new SurfaceCard
        {
            Location = location,
            Size = size,
            BackColor = Theme.Surface,
            BorderColor = Theme.BorderSoft,
            Radius = 16
        };
    }

    private static AnimatedButton CreateButton(
        string text,
        Point location,
        Size size,
        ButtonStyle style,
        AppIcon icon = AppIcon.None)
    {
        return new AnimatedButton
        {
            Text = text,
            Location = location,
            Size = size,
            Style = style,
            Icon = icon,
            Radius = 10
        };
    }

    private static Label CreateLabel(
        string text,
        Point location,
        Size size,
        float fontSize,
        Color color,
        bool semibold = false)
    {
        return new Label
        {
            Text = text,
            Location = location,
            Size = size,
            Font = Theme.Font(fontSize, semibold),
            ForeColor = color,
            BackColor = Color.Transparent,
            TextAlign = ContentAlignment.MiddleLeft
        };
    }

    private static Label CreateCardTitle(string text, Point location)
        => CreateLabel(text, location, new Size(360, 22), 8.2F, Theme.TextSecondary, true);

    private static void AddPageIntro(Panel page, string title, string subtitle)
    {
        page.Controls.Add(CreateLabel(title, new Point(32, 17), new Size(480, 27), 10F, Theme.TextPrimary, true));
        page.Controls.Add(CreateLabel(subtitle, new Point(32, 42), new Size(750, 22), 8.2F, Theme.TextMuted));
    }
}
