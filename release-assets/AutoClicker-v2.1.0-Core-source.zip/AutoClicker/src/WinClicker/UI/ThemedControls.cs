using System.Drawing.Drawing2D;

namespace WinClicker.UI;

internal enum AppIcon
{
    None,
    Home,
    Hotkeys,
    Overlay,
    Panic,
    Minus,
    Close,
    Cursor,
    MouseLeft,
    MouseRight,
    Reset
}

internal static class VectorIcons
{
    internal static void Draw(Graphics graphics, AppIcon icon, Rectangle bounds, Color color, float width = 1.8F)
    {
        graphics.SmoothingMode = SmoothingMode.AntiAlias;
        using var pen = new Pen(color, width) { StartCap = LineCap.Round, EndCap = LineCap.Round, LineJoin = LineJoin.Round };
        var cx = bounds.Left + bounds.Width / 2F;
        var cy = bounds.Top + bounds.Height / 2F;
        var left = bounds.Left + 2F;
        var right = bounds.Right - 2F;
        var top = bounds.Top + 2F;
        var bottom = bounds.Bottom - 2F;
        switch (icon)
        {
            case AppIcon.Home:
                graphics.DrawLines(pen, new[] { new PointF(left, cy), new PointF(cx, top), new PointF(right, cy) });
                graphics.DrawLines(pen, new[] { new PointF(left + 2, cy - 1), new PointF(left + 2, bottom), new PointF(right - 2, bottom), new PointF(right - 2, cy - 1) });
                break;
            case AppIcon.Hotkeys:
                graphics.DrawRoundedRectangle(pen, new RectangleF(left, top + 2, bounds.Width - 4, bounds.Height - 6), 3);
                using (var keyBrush = new SolidBrush(color))
                {
                    for (var x = 0; x < 3; x++)
                    {
                        for (var y = 0; y < 2; y++)
                        {
                            graphics.FillRectangle(keyBrush, left + 3 + x * 4.5F, top + 5 + y * 4.5F, 2.2F, 2.2F);
                        }
                    }
                }
                graphics.DrawLine(pen, left + 3, bottom - 3, right - 3, bottom - 3);
                break;
            case AppIcon.Overlay:
                graphics.DrawRoundedRectangle(pen, new RectangleF(left, top, bounds.Width - 4, bounds.Height - 4), 3);
                graphics.DrawLine(pen, left + 3, bottom - 4, right - 3, bottom - 4);
                using (var overlayBrush = new SolidBrush(color)) graphics.FillEllipse(overlayBrush, left + 3, top + 3, 3, 3);
                break;
            case AppIcon.Panic:
                graphics.DrawPolygon(pen, new[] { new PointF(cx, top), new PointF(right, bottom), new PointF(left, bottom) });
                graphics.DrawLine(pen, cx, top + 5, cx, cy + 3);
                using (var panicBrush = new SolidBrush(color)) graphics.FillEllipse(panicBrush, cx - 1, bottom - 4, 2, 2);
                break;
            case AppIcon.Minus:
                graphics.DrawLine(pen, left + 2, cy, right - 2, cy);
                break;
            case AppIcon.Close:
                graphics.DrawLine(pen, left + 2, top + 2, right - 2, bottom - 2);
                graphics.DrawLine(pen, right - 2, top + 2, left + 2, bottom - 2);
                break;
            case AppIcon.Cursor:
                var cursor = new[]
                {
                    new PointF(left + 2, top),
                    new PointF(right - 1, cy + 2),
                    new PointF(cx + 1, cy + 3),
                    new PointF(cx + 4, bottom),
                    new PointF(cx + 1, bottom + 1),
                    new PointF(cx - 2, cy + 5),
                    new PointF(left + 2, bottom - 2)
                };
                using (var brush = new SolidBrush(color)) graphics.FillPolygon(brush, cursor);
                break;
            case AppIcon.MouseLeft:
            case AppIcon.MouseRight:
                var mouse = new RectangleF(left + 2, top, bounds.Width - 8, bounds.Height - 2);
                graphics.DrawRoundedRectangle(pen, mouse, mouse.Width / 2F);
                graphics.DrawLine(pen, mouse.Left, mouse.Top + 7, mouse.Right, mouse.Top + 7);
                graphics.DrawLine(pen, cx - 1, mouse.Top, cx - 1, mouse.Top + 7);
                using (var brush = new SolidBrush(color))
                {
                    var activeX = icon == AppIcon.MouseLeft ? mouse.Left + 2 : cx + 1;
                    graphics.FillRectangle(brush, activeX, mouse.Top + 2, mouse.Width / 2F - 3, 3);
                }
                break;
            case AppIcon.Reset:
                graphics.DrawArc(pen, left + 1, top + 1, bounds.Width - 4, bounds.Height - 4, -45, 285);
                graphics.DrawLines(pen, new[] { new PointF(left + 1, cy - 4), new PointF(left + 1, top + 1), new PointF(left + 6, top + 2) });
                break;
        }
    }

    private static void DrawRoundedRectangle(this Graphics graphics, Pen pen, RectangleF bounds, float radius)
    {
        using var path = new GraphicsPath();
        var diameter = radius * 2;
        path.AddArc(bounds.Left, bounds.Top, diameter, diameter, 180, 90);
        path.AddArc(bounds.Right - diameter, bounds.Top, diameter, diameter, 270, 90);
        path.AddArc(bounds.Right - diameter, bounds.Bottom - diameter, diameter, diameter, 0, 90);
        path.AddArc(bounds.Left, bounds.Bottom - diameter, diameter, diameter, 90, 90);
        path.CloseFigure();
        graphics.DrawPath(pen, path);
    }
}

internal sealed class SurfaceCard : Panel
{
    internal SurfaceCard()
    {
        SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.UserPaint, true);
        BackColor = Theme.Surface;
        BorderColor = Theme.BorderSoft;
        Radius = 16;
    }

    internal Color BorderColor { get; set; }
    internal int Radius { get; set; }

    protected override void OnResize(EventArgs eventargs)
    {
        base.OnResize(eventargs);
        if (Width <= 2 || Height <= 2) return;
        using var path = Theme.RoundedRectangle(new Rectangle(0, 0, Width, Height), Radius);
        Region?.Dispose();
        Region = new Region(path);
    }

    protected override void OnPaintBackground(PaintEventArgs e)
    {
        e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
        e.Graphics.Clear(Parent?.BackColor ?? Theme.Background);
        using var path = Theme.RoundedRectangle(new Rectangle(0, 0, Width - 1, Height - 1), Radius);
        using var fill = new SolidBrush(BackColor);
        e.Graphics.FillPath(fill, path);
    }

    protected override void OnPaint(PaintEventArgs e)
    {
        e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
        using var path = Theme.RoundedRectangle(new Rectangle(0, 0, Width - 1, Height - 1), Radius);
        using var border = new Pen(BorderColor);
        e.Graphics.DrawPath(border, path);
        base.OnPaint(e);
    }
}

internal enum ButtonStyle
{
    Primary,
    Secondary,
    Ghost,
    Danger,
    Navigation
}

internal sealed class AnimatedButton : Control
{
    private readonly System.Windows.Forms.Timer _animationTimer;
    private float _hover;
    private float _hoverTarget;
    private bool _pressed;
    private bool _selected;

    internal AnimatedButton()
    {
        SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.UserPaint | ControlStyles.Selectable, true);
        Cursor = Cursors.Hand;
        TabStop = true;
        Font = Theme.Font(9F, true);
        ForeColor = Theme.TextPrimary;
        Size = new Size(150, 42);
        Radius = 10;
        Style = ButtonStyle.Secondary;
        _animationTimer = new System.Windows.Forms.Timer { Interval = 15 };
        _animationTimer.Tick += (_, _) => Animate();
    }

    internal ButtonStyle Style { get; set; }
    internal AppIcon Icon { get; set; }
    internal int Radius { get; set; }
    internal bool Selected
    {
        get => _selected;
        set
        {
            if (_selected == value) return;
            _selected = value;
            Invalidate();
        }
    }

    protected override void OnMouseEnter(EventArgs e)
    {
        base.OnMouseEnter(e);
        _hoverTarget = 1F;
        _animationTimer.Start();
    }

    protected override void OnMouseLeave(EventArgs e)
    {
        base.OnMouseLeave(e);
        _hoverTarget = 0F;
        _pressed = false;
        _animationTimer.Start();
    }

    protected override void OnMouseDown(MouseEventArgs e)
    {
        base.OnMouseDown(e);
        if (e.Button != MouseButtons.Left) return;
        Focus();
        _pressed = true;
        Invalidate();
    }

    protected override void OnMouseUp(MouseEventArgs e)
    {
        base.OnMouseUp(e);
        if (e.Button != MouseButtons.Left) return;
        _pressed = false;
        Invalidate();
    }

    protected override void OnKeyDown(KeyEventArgs e)
    {
        base.OnKeyDown(e);
        if (e.KeyCode is Keys.Enter or Keys.Space)
        {
            _pressed = true;
            Invalidate();
            e.Handled = true;
        }
    }

    protected override void OnKeyUp(KeyEventArgs e)
    {
        base.OnKeyUp(e);
        if (_pressed && (e.KeyCode is Keys.Enter or Keys.Space))
        {
            _pressed = false;
            Invalidate();
            OnClick(EventArgs.Empty);
            e.Handled = true;
        }
    }

    protected override void OnEnabledChanged(EventArgs e)
    {
        base.OnEnabledChanged(e);
        Invalidate();
    }

    protected override void OnPaint(PaintEventArgs e)
    {
        e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
        e.Graphics.Clear(Parent?.BackColor ?? Theme.Background);
        var bounds = new Rectangle(0, 0, Width - 1, Height - 1);
        using var path = Theme.RoundedRectangle(bounds, Radius);
        var (baseColor, hoverColor, borderColor, textColor) = ResolvePalette();
        var background = Theme.Blend(baseColor, hoverColor, _hover);
        if (_pressed) background = Theme.Blend(background, Color.Black, 0.18F);

        if (Style == ButtonStyle.Primary && Enabled)
        {
            using var gradient = new LinearGradientBrush(bounds, Theme.Blend(background, Theme.AccentBright, 0.22F), background, 25F);
            e.Graphics.FillPath(gradient, path);
        }
        else
        {
            using var fill = new SolidBrush(background);
            e.Graphics.FillPath(fill, path);
        }

        using (var border = new Pen(borderColor)) e.Graphics.DrawPath(border, path);
        if (Focused && TabStop)
        {
            using var focusPath = Theme.RoundedRectangle(Rectangle.Inflate(bounds, -3, -3), Math.Max(4, Radius - 3));
            using var focusPen = new Pen(Color.FromArgb(110, Theme.Accent));
            e.Graphics.DrawPath(focusPen, focusPath);
        }

        var textBounds = bounds;
        var flags = TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.EndEllipsis | TextFormatFlags.SingleLine;
        if (Style == ButtonStyle.Navigation)
        {
            textBounds = new Rectangle(49, 0, Math.Max(1, Width - 57), Height);
            flags = TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.EndEllipsis | TextFormatFlags.SingleLine;
            if (Selected)
            {
                using var indicator = new SolidBrush(Theme.Accent);
                e.Graphics.FillRectangle(indicator, 0, 11, 3, Math.Max(12, Height - 22));
            }
        }
        else if (Icon != AppIcon.None)
        {
            var textWidth = TextRenderer.MeasureText(Text, Font).Width;
            var totalWidth = textWidth + 24;
            var iconX = Math.Max(10, (Width - totalWidth) / 2);
            VectorIcons.Draw(e.Graphics, Icon, new Rectangle(iconX, (Height - 16) / 2, 16, 16), textColor, 1.7F);
            textBounds = new Rectangle(iconX + 23, 0, Math.Max(1, Width - iconX - 27), Height);
            flags = TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.EndEllipsis | TextFormatFlags.SingleLine;
        }

        if (Style == ButtonStyle.Navigation && Icon != AppIcon.None)
        {
            VectorIcons.Draw(e.Graphics, Icon, new Rectangle(21, (Height - 17) / 2, 17, 17), textColor, 1.7F);
        }

        TextRenderer.DrawText(e.Graphics, Text, Font, textBounds, textColor, flags);
    }

    private (Color Base, Color Hover, Color Border, Color Text) ResolvePalette()
    {
        if (!Enabled)
        {
            return (Theme.Surface, Theme.Surface, Theme.BorderSoft, Theme.TextMuted);
        }

        return Style switch
        {
            ButtonStyle.Primary => (Theme.Accent, Theme.AccentBright, Theme.Accent, Color.White),
            ButtonStyle.Danger => (Theme.Background, Theme.AccentMuted, Theme.AccentDark, Theme.AccentBright),
            ButtonStyle.Ghost => (Parent?.BackColor ?? Theme.Background, Theme.SurfaceHover, Color.Transparent, Theme.TextSecondary),
            ButtonStyle.Navigation =>
                (Selected ? Theme.AccentMuted : Theme.Sidebar,
                 Selected ? Theme.Blend(Theme.AccentMuted, Theme.SurfaceHover, 0.4F) : Theme.Surface,
                 Selected ? Theme.AccentDark : Color.Transparent,
                 Selected ? Theme.TextPrimary : Theme.TextSecondary),
            _ => (Theme.SurfaceRaised, Theme.SurfaceHover, Theme.Border, Theme.TextPrimary)
        };
    }

    private void Animate()
    {
        _hover += (_hoverTarget - _hover) * 0.28F;
        if (Math.Abs(_hoverTarget - _hover) < 0.015F)
        {
            _hover = _hoverTarget;
            _animationTimer.Stop();
        }

        Invalidate();
    }

    protected override void Dispose(bool disposing)
    {
        if (disposing) _animationTimer.Dispose();
        base.Dispose(disposing);
    }
}

internal sealed class AnimatedToggle : Control
{
    private readonly System.Windows.Forms.Timer _timer;
    private float _position;
    private bool _checked;

    internal AnimatedToggle()
    {
        SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.UserPaint | ControlStyles.Selectable, true);
        Cursor = Cursors.Hand;
        TabStop = true;
        Size = new Size(48, 26);
        _timer = new System.Windows.Forms.Timer { Interval = 15 };
        _timer.Tick += (_, _) => Animate();
    }

    internal event EventHandler? CheckedChanged;

    internal bool Checked
    {
        get => _checked;
        set
        {
            if (_checked == value) return;
            _checked = value;
            _timer.Start();
            CheckedChanged?.Invoke(this, EventArgs.Empty);
            Invalidate();
        }
    }

    protected override void OnClick(EventArgs e)
    {
        Checked = !Checked;
        base.OnClick(e);
    }

    protected override void OnKeyDown(KeyEventArgs e)
    {
        base.OnKeyDown(e);
        if (e.KeyCode is Keys.Space or Keys.Enter)
        {
            Checked = !Checked;
            e.Handled = true;
        }
    }

    protected override void OnPaint(PaintEventArgs e)
    {
        e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
        e.Graphics.Clear(Parent?.BackColor ?? Theme.Surface);
        var track = new Rectangle(1, 2, Width - 3, Height - 4);
        using var trackPath = Theme.RoundedRectangle(track, track.Height / 2);
        using var trackBrush = new SolidBrush(Theme.Blend(Theme.SurfaceHover, Theme.Accent, _position));
        e.Graphics.FillPath(trackBrush, trackPath);
        using var border = new Pen(Theme.Blend(Theme.Border, Theme.Accent, _position));
        e.Graphics.DrawPath(border, trackPath);
        var knob = track.Height - 6;
        var knobX = track.Left + 3 + (track.Width - knob - 6) * _position;
        using var shadow = new SolidBrush(Color.FromArgb(80, 0, 0, 0));
        e.Graphics.FillEllipse(shadow, knobX + 1, track.Top + 4, knob, knob);
        using var fill = new SolidBrush(Color.White);
        e.Graphics.FillEllipse(fill, knobX, track.Top + 3, knob, knob);
    }

    private void Animate()
    {
        var target = Checked ? 1F : 0F;
        _position += (target - _position) * 0.32F;
        if (Math.Abs(target - _position) < 0.015F)
        {
            _position = target;
            _timer.Stop();
        }
        Invalidate();
    }

    protected override void Dispose(bool disposing)
    {
        if (disposing) _timer.Dispose();
        base.Dispose(disposing);
    }
}

internal sealed class SegmentedControl : Control
{
    private readonly System.Windows.Forms.Timer _timer;
    private string[] _options = Array.Empty<string>();
    private int _selectedIndex;
    private float _indicatorIndex;

    internal SegmentedControl()
    {
        SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.UserPaint | ControlStyles.Selectable, true);
        Cursor = Cursors.Hand;
        TabStop = true;
        Font = Theme.Font(8.5F, true);
        Size = new Size(300, 40);
        _timer = new System.Windows.Forms.Timer { Interval = 15 };
        _timer.Tick += (_, _) => Animate();
    }

    internal event EventHandler? SelectedIndexChanged;

    internal string[] Options
    {
        get => _options;
        set
        {
            _options = value ?? Array.Empty<string>();
            _selectedIndex = Math.Clamp(_selectedIndex, 0, Math.Max(0, _options.Length - 1));
            _indicatorIndex = _selectedIndex;
            Invalidate();
        }
    }

    internal int SelectedIndex
    {
        get => _selectedIndex;
        set
        {
            var normalized = Math.Clamp(value, 0, Math.Max(0, _options.Length - 1));
            if (_selectedIndex == normalized) return;
            _selectedIndex = normalized;
            _timer.Start();
            SelectedIndexChanged?.Invoke(this, EventArgs.Empty);
            Invalidate();
        }
    }

    protected override void OnMouseDown(MouseEventArgs e)
    {
        base.OnMouseDown(e);
        if (e.Button != MouseButtons.Left || _options.Length == 0) return;
        Focus();
        SelectedIndex = Math.Clamp(e.X * _options.Length / Math.Max(1, Width), 0, _options.Length - 1);
    }

    protected override void OnKeyDown(KeyEventArgs e)
    {
        base.OnKeyDown(e);
        if (e.KeyCode is Keys.Left or Keys.Up)
        {
            SelectedIndex--;
            e.Handled = true;
        }
        else if (e.KeyCode is Keys.Right or Keys.Down)
        {
            SelectedIndex++;
            e.Handled = true;
        }
    }

    protected override void OnPaint(PaintEventArgs e)
    {
        e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
        e.Graphics.Clear(Parent?.BackColor ?? Theme.Surface);
        var bounds = new Rectangle(0, 0, Width - 1, Height - 1);
        using var path = Theme.RoundedRectangle(bounds, 10);
        using var background = new SolidBrush(Theme.Background);
        using var border = new Pen(Theme.BorderSoft);
        e.Graphics.FillPath(background, path);
        e.Graphics.DrawPath(border, path);
        if (_options.Length == 0) return;

        var segmentWidth = Width / (float)_options.Length;
        var indicator = new RectangleF(_indicatorIndex * segmentWidth + 3, 3, segmentWidth - 6, Height - 7);
        using var indicatorPath = Theme.RoundedRectangle(Rectangle.Round(indicator), 8);
        using var indicatorFill = new SolidBrush(Theme.SurfaceHover);
        e.Graphics.FillPath(indicatorFill, indicatorPath);
        using var indicatorBorder = new Pen(Color.FromArgb(80, Theme.Accent));
        e.Graphics.DrawPath(indicatorBorder, indicatorPath);

        for (var index = 0; index < _options.Length; index++)
        {
            var textBounds = new Rectangle((int)(index * segmentWidth), 0, (int)Math.Ceiling(segmentWidth), Height);
            var color = index == SelectedIndex ? Theme.TextPrimary : Theme.TextMuted;
            TextRenderer.DrawText(e.Graphics, _options[index], Font, textBounds, color,
                TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.EndEllipsis | TextFormatFlags.SingleLine);
        }
    }

    private void Animate()
    {
        _indicatorIndex += (SelectedIndex - _indicatorIndex) * 0.32F;
        if (Math.Abs(SelectedIndex - _indicatorIndex) < 0.012F)
        {
            _indicatorIndex = SelectedIndex;
            _timer.Stop();
        }
        Invalidate();
    }

    protected override void Dispose(bool disposing)
    {
        if (disposing) _timer.Dispose();
        base.Dispose(disposing);
    }
}

internal sealed class ValueSlider : Control
{
    private int _minimum = 1;
    private int _maximum = 1000;
    private int _value = 50;
    private bool _dragging;

    internal ValueSlider()
    {
        SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.UserPaint | ControlStyles.Selectable, true);
        Cursor = Cursors.Hand;
        TabStop = true;
        Size = new Size(500, 32);
    }

    internal event EventHandler? ValueChanged;
    internal int Minimum { get => _minimum; set { _minimum = value; Value = _value; } }
    internal int Maximum { get => _maximum; set { _maximum = Math.Max(_minimum + 1, value); Value = _value; } }
    internal bool Logarithmic { get; set; } = true;

    internal int Value
    {
        get => _value;
        set
        {
            var normalized = Math.Clamp(value, Minimum, Maximum);
            if (_value == normalized) return;
            _value = normalized;
            ValueChanged?.Invoke(this, EventArgs.Empty);
            Invalidate();
        }
    }

    protected override void OnMouseDown(MouseEventArgs e)
    {
        base.OnMouseDown(e);
        if (e.Button != MouseButtons.Left) return;
        _dragging = true;
        Capture = true;
        Focus();
        SetFromX(e.X);
    }

    protected override void OnMouseMove(MouseEventArgs e)
    {
        base.OnMouseMove(e);
        if (_dragging) SetFromX(e.X);
    }

    protected override void OnMouseUp(MouseEventArgs e)
    {
        base.OnMouseUp(e);
        _dragging = false;
        Capture = false;
    }

    protected override void OnKeyDown(KeyEventArgs e)
    {
        base.OnKeyDown(e);
        var step = e.Shift ? 10 : 1;
        if (e.KeyCode is Keys.Left or Keys.Down)
        {
            Value -= step;
            e.Handled = true;
        }
        else if (e.KeyCode is Keys.Right or Keys.Up)
        {
            Value += step;
            e.Handled = true;
        }
    }

    protected override void OnPaint(PaintEventArgs e)
    {
        e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
        e.Graphics.Clear(Parent?.BackColor ?? Theme.Surface);
        var track = new Rectangle(8, Height / 2 - 2, Math.Max(1, Width - 16), 4);
        using var trackPath = Theme.RoundedRectangle(track, 2);
        using var baseFill = new SolidBrush(Theme.BorderSoft);
        e.Graphics.FillPath(baseFill, trackPath);
        var progress = GetProgress();
        var progressBounds = new Rectangle(track.X, track.Y, Math.Max(4, (int)(track.Width * progress)), track.Height);
        using var progressPath = Theme.RoundedRectangle(progressBounds, 2);
        using var progressFill = new LinearGradientBrush(progressBounds, Theme.AccentDark, Theme.AccentBright, 0F);
        e.Graphics.FillPath(progressFill, progressPath);
        var knobX = track.Left + (int)(track.Width * progress);
        using var glow = new SolidBrush(Color.FromArgb(55, Theme.Accent));
        e.Graphics.FillEllipse(glow, knobX - 10, Height / 2 - 10, 20, 20);
        using var knob = new SolidBrush(Color.White);
        e.Graphics.FillEllipse(knob, knobX - 5, Height / 2 - 5, 10, 10);
    }

    private void SetFromX(int x)
    {
        var progress = Math.Clamp((x - 8F) / Math.Max(1F, Width - 16F), 0F, 1F);
        if (Logarithmic)
        {
            var minLog = Math.Log(Minimum);
            var maxLog = Math.Log(Maximum);
            Value = (int)Math.Round(Math.Exp(minLog + (maxLog - minLog) * progress));
        }
        else
        {
            Value = Minimum + (int)Math.Round((Maximum - Minimum) * progress);
        }
    }

    private float GetProgress()
    {
        if (!Logarithmic) return (Value - Minimum) / (float)(Maximum - Minimum);
        return (float)((Math.Log(Value) - Math.Log(Minimum)) / (Math.Log(Maximum) - Math.Log(Minimum)));
    }
}

internal sealed class LogoMark : Control
{
    private readonly System.Windows.Forms.Timer _timer;
    private float _pulse;

    internal LogoMark()
    {
        SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.UserPaint, true);
        Size = new Size(44, 44);
        _timer = new System.Windows.Forms.Timer { Interval = 33 };
        _timer.Tick += (_, _) => { _pulse += 0.045F; Invalidate(); };
        _timer.Start();
    }

    protected override void OnPaint(PaintEventArgs e)
    {
        e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
        e.Graphics.Clear(Parent?.BackColor ?? Theme.Sidebar);
        var bounds = new Rectangle(1, 1, Width - 3, Height - 3);
        using var path = Theme.RoundedRectangle(bounds, 12);
        using var gradient = new LinearGradientBrush(bounds, Theme.AccentMuted, Color.FromArgb(20, Theme.Accent), 45F);
        using var border = new Pen(Theme.AccentDark, 1.2F);
        e.Graphics.FillPath(gradient, path);
        e.Graphics.DrawPath(border, path);
        var center = new PointF(21F, 19F);
        var rayAlpha = 150 + (int)(Math.Sin(_pulse) * 45);
        using var rayPen = new Pen(Color.FromArgb(rayAlpha, Theme.AccentBright), 1.8F) { StartCap = LineCap.Round, EndCap = LineCap.Round };
        for (var index = 0; index < 8; index++)
        {
            var angle = index * Math.PI / 4D;
            e.Graphics.DrawLine(rayPen,
                center.X + (float)Math.Cos(angle) * 7F,
                center.Y + (float)Math.Sin(angle) * 7F,
                center.X + (float)Math.Cos(angle) * 11F,
                center.Y + (float)Math.Sin(angle) * 11F);
        }
        VectorIcons.Draw(e.Graphics, AppIcon.Cursor, new Rectangle(17, 15, 17, 21), Color.White, 1.6F);
    }

    protected override void Dispose(bool disposing)
    {
        if (disposing) _timer.Dispose();
        base.Dispose(disposing);
    }
}
