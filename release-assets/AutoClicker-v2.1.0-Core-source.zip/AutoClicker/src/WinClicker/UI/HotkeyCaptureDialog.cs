using WinClicker.Models;

namespace WinClicker.UI;

internal sealed class HotkeyCaptureDialog : Form
{
    private readonly Label _capturedLabel;

    internal HotkeyCaptureDialog(string actionName, HotkeyBinding current)
    {
        SelectedHotkey = current.Clone();
        Text = "Назначить хоткей";
        ClientSize = new Size(480, 260);
        MinimumSize = MaximumSize = Size;
        StartPosition = FormStartPosition.CenterParent;
        FormBorderStyle = FormBorderStyle.None;
        ShowInTaskbar = false;
        KeyPreview = true;
        BackColor = Theme.Background;
        ForeColor = Theme.TextPrimary;
        Font = Theme.Font(9F);
        DoubleBuffered = true;

        var title = CreateLabel(actionName, new Point(26, 21), new Size(420, 27), 13F, Theme.TextPrimary, true);
        var hint = CreateLabel(
            "Нажмите клавишу или Mouse 3 / Mouse 4 / Mouse 5\nEsc — отмена   •   Delete — очистить",
            new Point(27, 54),
            new Size(425, 44),
            8.5F,
            Theme.TextSecondary);
        var captureCard = new SurfaceCard
        {
            Location = new Point(26, 111),
            Size = new Size(428, 64),
            BackColor = Theme.SurfaceRaised,
            BorderColor = Theme.AccentDark,
            Radius = 13
        };
        _capturedLabel = CreateLabel(current.ToDisplayString(), new Point(12, 8), new Size(404, 48), 13F, Theme.AccentBright, true);
        _capturedLabel.TextAlign = ContentAlignment.MiddleCenter;
        captureCard.Controls.Add(_capturedLabel);

        var clear = CreateButton("Очистить", new Point(130, 201), new Size(98, 38), ButtonStyle.Ghost);
        clear.Click += (_, _) => Finish(HotkeyBinding.Disabled());
        var cancel = CreateButton("Отмена", new Point(238, 201), new Size(98, 38), ButtonStyle.Secondary);
        cancel.Click += (_, _) => { DialogResult = DialogResult.Cancel; Close(); };
        var keep = CreateButton("Оставить", new Point(346, 201), new Size(108, 38), ButtonStyle.Primary);
        keep.Click += (_, _) => Finish(SelectedHotkey);

        Controls.AddRange(new Control[] { title, hint, captureCard, clear, cancel, keep });
        MouseDown += DragWindow;
        title.MouseDown += DragWindow;
        Shown += (_, _) => Activate();
    }

    internal HotkeyBinding SelectedHotkey { get; private set; }

    internal void AcceptBinding(HotkeyBinding binding)
    {
        if (IsDisposed) return;
        if (InvokeRequired)
        {
            BeginInvoke(new Action(() => AcceptBinding(binding)));
            return;
        }

        Finish(binding);
    }

    protected override void OnShown(EventArgs e)
    {
        base.OnShown(e);
        using var path = Theme.RoundedRectangle(new Rectangle(0, 0, Width, Height), 18);
        Region?.Dispose();
        Region = new Region(path);
    }

    protected override void OnPaint(PaintEventArgs e)
    {
        base.OnPaint(e);
        using var border = new Pen(Theme.Border);
        using var path = Theme.RoundedRectangle(new Rectangle(0, 0, Width - 1, Height - 1), 18);
        e.Graphics.DrawPath(border, path);
        using var accent = new SolidBrush(Theme.Accent);
        e.Graphics.FillRectangle(accent, 25, 0, 92, 2);
    }

    protected override void OnKeyDown(KeyEventArgs e)
    {
        base.OnKeyDown(e);
        if (e.KeyCode == Keys.Escape && e.Modifiers == Keys.None)
        {
            DialogResult = DialogResult.Cancel;
            Close();
            return;
        }

        if (e.KeyCode == Keys.Delete && e.Modifiers == Keys.None)
        {
            Finish(HotkeyBinding.Disabled());
            return;
        }

        if (HotkeyBinding.IsModifierKey(e.KeyCode))
        {
            _capturedLabel.Text = "Добавьте обычную клавишу…";
            e.Handled = true;
            e.SuppressKeyPress = true;
            return;
        }

        var binding = HotkeyBinding.FromKey(
            e.KeyCode,
            e.Control,
            e.Alt,
            e.Shift,
            NativeMethods.IsKeyDown(NativeMethods.VkLWin) || NativeMethods.IsKeyDown(NativeMethods.VkRWin));
        e.Handled = true;
        e.SuppressKeyPress = true;
        Finish(binding);
    }

    private void Finish(HotkeyBinding binding)
    {
        SelectedHotkey = binding.Clone();
        _capturedLabel.Text = SelectedHotkey.ToDisplayString();
        DialogResult = DialogResult.OK;
        Close();
    }

    private void DragWindow(object? sender, MouseEventArgs e)
    {
        if (e.Button != MouseButtons.Left) return;
        NativeMethods.ReleaseCapture();
        NativeMethods.SendMessage(Handle, NativeMethods.WmNclbuttonDown, new IntPtr(NativeMethods.HtCaption), IntPtr.Zero);
    }

    private static Label CreateLabel(string text, Point location, Size size, float fontSize, Color color, bool semibold = false)
    {
        return new Label
        {
            Text = text,
            Location = location,
            Size = size,
            Font = Theme.Font(fontSize, semibold),
            ForeColor = color,
            BackColor = Color.Transparent,
            TextAlign = ContentAlignment.MiddleLeft
        };
    }

    private static AnimatedButton CreateButton(string text, Point location, Size size, ButtonStyle style)
    {
        return new AnimatedButton
        {
            Text = text,
            Location = location,
            Size = size,
            Style = style,
            Radius = 9
        };
    }
}
