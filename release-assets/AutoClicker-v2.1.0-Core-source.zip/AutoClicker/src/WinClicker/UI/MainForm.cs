using System.Diagnostics;
using WinClicker.Models;
using WinClicker.Services;

namespace WinClicker.UI;

internal sealed partial class MainForm : Form
{
    private readonly SettingsStore _settingsStore = new();
    private readonly ClickEngine _clickEngine = new();
    private readonly OverlayForm _overlay = new();
    private readonly AppSettings _settings;
    private readonly Dictionary<string, Panel> _pages = new();
    private readonly Dictionary<string, AnimatedButton> _navButtons = new();
    private readonly Dictionary<int, AnimatedButton> _intervalPresetButtons = new();

    private Panel _pageHost = null!;
    private Label _pageTitle = null!;
    private Label _topStatusLabel = null!;
    private Label _intervalValueLabel = null!;
    private ValueSlider _intervalSlider = null!;
    private Label _leftStatusLabel = null!;
    private Label _rightStatusLabel = null!;
    private Label _leftHotkeyHomeLabel = null!;
    private Label _rightHotkeyHomeLabel = null!;
    private Label _leftModeHomeLabel = null!;
    private Label _rightModeHomeLabel = null!;
    private AnimatedButton _leftActionButton = null!;
    private AnimatedButton _rightActionButton = null!;
    private Label _leftRateLabel = null!;
    private Label _rightRateLabel = null!;
    private Label _totalClicksLabel = null!;
    private Label _combinedRateLabel = null!;
    private Label _leftHotkeySettingsLabel = null!;
    private Label _rightHotkeySettingsLabel = null!;
    private Label _panicHotkeyLabel = null!;
    private SegmentedControl _leftModeControl = null!;
    private SegmentedControl _rightModeControl = null!;
    private AnimatedToggle _ignoreModifiersToggle = null!;
    private AnimatedToggle _suppressHotkeysToggle = null!;
    private AnimatedToggle _minimizeToTrayToggle = null!;
    private AnimatedToggle _overlayEnabledToggle = null!;
    private ValueSlider _overlayOpacitySlider = null!;
    private Label _overlayOpacityLabel = null!;
    private SegmentedControl _overlayCornerControl = null!;
    private Label _overlayPreviewDot = null!;
    private Label _overlayPreviewTitle = null!;
    private Label _overlayPreviewDetails = null!;

    private readonly System.Windows.Forms.Timer _statsTimer;
    private readonly System.Windows.Forms.Timer _pageTransitionTimer;
    private readonly System.Windows.Forms.Timer _saveTimer = new() { Interval = 350 };
    private NotifyIcon _trayIcon = null!;
    private GlobalInputHook? _inputHook;
    private Panel? _currentPage;
    private Panel? _transitionPage;
    private bool _loading = true;
    private bool _closing;
    private bool _trayHintShown;
    private long _lastLeftClicks;
    private long _lastRightClicks;
    private long _lastStatsTimestamp;
    private double _leftCps;
    private double _rightCps;
    private DateTime _panicMessageUntilUtc;

    internal MainForm()
    {
        _settings = _settingsStore.Load();
        _settings.Normalize();

        Text = "AUTO CLICKER";
        ClientSize = new Size(1100, 700);
        MinimumSize = MaximumSize = Size;
        StartPosition = FormStartPosition.CenterScreen;
        FormBorderStyle = FormBorderStyle.None;
        MaximizeBox = false;
        BackColor = Theme.Background;
        ForeColor = Theme.TextPrimary;
        Font = Theme.Font(9F);
        AutoScaleMode = AutoScaleMode.Dpi;
        DoubleBuffered = true;
        KeyPreview = true;

        BuildLayout();
        BuildTray();
        ApplySettingsToInterface();
        _clickEngine.IntervalMs = _settings.IntervalMs;
        _clickEngine.ChannelStopped += ClickEngineOnChannelStopped;
        _loading = false;
        UpdateAllVisuals();

        _statsTimer = new System.Windows.Forms.Timer { Interval = 250 };
        _statsTimer.Tick += (_, _) => UpdateStatistics();
        _lastStatsTimestamp = Stopwatch.GetTimestamp();
        _statsTimer.Start();

        _pageTransitionTimer = new System.Windows.Forms.Timer { Interval = 15 };
        _pageTransitionTimer.Tick += (_, _) => AnimatePageTransition();
        _saveTimer.Tick += (_, _) =>
        {
            _saveTimer.Stop();
            _settingsStore.Save(_settings);
        };

        Shown += (_, _) =>
        {
            InstallInputHook();
            _overlay.Configure(_settings);
            UpdateOverlay();
        };
        Resize += (_, _) => MinimizeIfNeeded();
        FormClosing += MainFormClosing;
    }

    protected override void OnPaint(PaintEventArgs e)
    {
        base.OnPaint(e);
        using var border = new Pen(Theme.BorderSoft);
        e.Graphics.DrawRectangle(border, 0, 0, Width - 1, Height - 1);
    }

    private void InstallInputHook()
    {
        try
        {
            _inputHook = new GlobalInputHook();
            _inputHook.UpdateConfiguration(_settings);
            _inputHook.HotkeyChanged += InputHookOnHotkeyChanged;
            _inputHook.Start();
        }
        catch (Exception exception)
        {
            _inputHook?.Dispose();
            _inputHook = null;
            MessageBox.Show(
                this,
                $"Глобальные хоткеи не запущены. Управление из окна продолжит работать.\n\n{exception.Message}",
                "AUTO CLICKER",
                MessageBoxButtons.OK,
                MessageBoxIcon.Warning);
        }
    }

    private void ApplySettingsToInterface()
    {
        _loading = true;
        _settings.Normalize();
        _intervalSlider.Value = _settings.IntervalMs;
        _leftModeControl.SelectedIndex = (int)_settings.LeftHotkeyMode;
        _rightModeControl.SelectedIndex = (int)_settings.RightHotkeyMode;
        _ignoreModifiersToggle.Checked = _settings.IgnoreExtraModifiers;
        _suppressHotkeysToggle.Checked = _settings.SuppressHotkeys;
        _minimizeToTrayToggle.Checked = _settings.MinimizeToTray;
        _overlayEnabledToggle.Checked = _settings.OverlayEnabled;
        _overlayOpacitySlider.Value = _settings.OverlayOpacityPercent;
        _overlayCornerControl.SelectedIndex = (int)_settings.OverlayCorner;
        _loading = false;
        UpdateHotkeyVisuals();
        UpdateIntervalVisuals();
    }

    private void IntervalChanged(int intervalMs)
    {
        intervalMs = Math.Clamp(intervalMs, 1, 1000);
        if (_intervalSlider.Value != intervalMs)
        {
            _intervalSlider.Value = intervalMs;
            return;
        }

        _settings.IntervalMs = intervalMs;
        _clickEngine.IntervalMs = intervalMs;
        UpdateIntervalVisuals();
        SaveSettings();
    }

    private void UpdateIntervalVisuals()
    {
        _intervalValueLabel.Text = $"{_settings.IntervalMs} ms";
        foreach (var pair in _intervalPresetButtons)
        {
            pair.Value.Style = pair.Key == _settings.IntervalMs ? ButtonStyle.Secondary : ButtonStyle.Ghost;
            pair.Value.Invalidate();
        }

        UpdateOverlayPreview();
    }

    private void ToggleChannel(ClickButton button)
    {
        _clickEngine.Toggle(button);
        UpdateAllVisuals();
    }

    private void HandleHotkey(ClickButton button, HotkeyTriggerMode mode, HotkeySignal signal)
    {
        switch (mode)
        {
            case HotkeyTriggerMode.Toggle when signal == HotkeySignal.Pressed:
                _clickEngine.Toggle(button);
                break;
            case HotkeyTriggerMode.Hold when signal == HotkeySignal.Pressed:
                _clickEngine.Start(button);
                break;
            case HotkeyTriggerMode.Hold when signal == HotkeySignal.Released:
                _clickEngine.Stop(button);
                break;
            case HotkeyTriggerMode.Press when signal == HotkeySignal.Pressed:
                _clickEngine.TriggerOnce(button);
                break;
        }

        UpdateAllVisuals();
    }

    private void InputHookOnHotkeyChanged(object? sender, GlobalHotkeyEventArgs e)
    {
        if (IsDisposed || _closing) return;
        if (InvokeRequired)
        {
            BeginInvoke(new Action(() => InputHookOnHotkeyChanged(sender, e)));
            return;
        }

        if (e.Action == HotkeyAction.Panic)
        {
            if (e.Signal == HotkeySignal.Pressed) PanicStop();
            return;
        }

        if (e.Action == HotkeyAction.LeftClicker)
        {
            HandleHotkey(ClickButton.Left, _settings.LeftHotkeyMode, e.Signal);
        }
        else if (e.Action == HotkeyAction.RightClicker)
        {
            HandleHotkey(ClickButton.Right, _settings.RightHotkeyMode, e.Signal);
        }
    }

    private void PanicStop()
    {
        _clickEngine.PanicStop();
        _panicMessageUntilUtc = DateTime.UtcNow.AddSeconds(1.5D);
        UpdateAllVisuals();
    }

    private void CaptureHotkey(HotkeyAction action)
    {
        _clickEngine.PanicStop();
        UpdateAllVisuals();
        var current = action switch
        {
            HotkeyAction.LeftClicker => _settings.LeftHotkey,
            HotkeyAction.RightClicker => _settings.RightHotkey,
            _ => _settings.PanicHotkey
        };
        var title = action switch
        {
            HotkeyAction.LeftClicker => "Хоткей для левого клика",
            HotkeyAction.RightClicker => "Хоткей для правого клика",
            _ => "Emergency Stop"
        };

        using var dialog = new HotkeyCaptureDialog(title, current);
        EventHandler<HotkeyBinding>? captureHandler = null;
        if (_inputHook is not null)
        {
            _inputHook.Suspended = true;
            captureHandler = (_, binding) => dialog.AcceptBinding(binding);
            _inputHook.MouseBindingCaptured += captureHandler;
        }

        try
        {
            if (dialog.ShowDialog(this) != DialogResult.OK) return;
            var selected = dialog.SelectedHotkey.Clone();
            switch (action)
            {
                case HotkeyAction.LeftClicker:
                    _settings.LeftHotkey = selected;
                    break;
                case HotkeyAction.RightClicker:
                    _settings.RightHotkey = selected;
                    break;
                case HotkeyAction.Panic:
                    _settings.PanicHotkey = selected;
                    break;
            }

            _settings.Normalize();
            _inputHook?.UpdateConfiguration(_settings);
            UpdateHotkeyVisuals();
            SaveSettings();
        }
        finally
        {
            if (_inputHook is not null)
            {
                if (captureHandler is not null) _inputHook.MouseBindingCaptured -= captureHandler;
                _inputHook.Suspended = false;
                _inputHook.UpdateConfiguration(_settings);
            }
        }
    }

    private void HotkeyModeChanged(ClickButton button, int selectedIndex)
    {
        if (_loading) return;
        var mode = (HotkeyTriggerMode)Math.Clamp(selectedIndex, 0, 2);
        if (button == ClickButton.Left)
        {
            _settings.LeftHotkeyMode = mode;
        }
        else
        {
            _settings.RightHotkeyMode = mode;
        }

        _clickEngine.Stop(button);
        UpdateHotkeyVisuals();
        SaveSettings();
    }

    private void BehaviorSettingsChanged()
    {
        if (_loading) return;
        _settings.IgnoreExtraModifiers = _ignoreModifiersToggle.Checked;
        _settings.SuppressHotkeys = _suppressHotkeysToggle.Checked;
        _settings.MinimizeToTray = _minimizeToTrayToggle.Checked;
        _inputHook?.UpdateConfiguration(_settings);
        SaveSettings();
    }

    private void OverlaySettingsChanged()
    {
        if (_loading) return;
        _settings.OverlayEnabled = _overlayEnabledToggle.Checked;
        _settings.OverlayOpacityPercent = _overlayOpacitySlider.Value;
        _settings.OverlayCorner = (OverlayCorner)Math.Clamp(_overlayCornerControl.SelectedIndex, 0, 3);
        _settings.Normalize();
        _overlayOpacityLabel.Text = $"{_settings.OverlayOpacityPercent}%";
        _overlay.Configure(_settings);
        UpdateOverlayPreview();
        SaveSettings();
    }

    private void UpdateHotkeyVisuals()
    {
        var left = _settings.LeftHotkey.ToDisplayString();
        var right = _settings.RightHotkey.ToDisplayString();
        _leftHotkeyHomeLabel.Text = left;
        _rightHotkeyHomeLabel.Text = right;
        _leftHotkeySettingsLabel.Text = left;
        _rightHotkeySettingsLabel.Text = right;
        _panicHotkeyLabel.Text = _settings.PanicHotkey.ToDisplayString();
        _leftModeHomeLabel.Text = ModeName(_settings.LeftHotkeyMode);
        _rightModeHomeLabel.Text = ModeName(_settings.RightHotkeyMode);
    }

    private void UpdateAllVisuals()
    {
        var leftRunning = _clickEngine.IsRunning(ClickButton.Left);
        var rightRunning = _clickEngine.IsRunning(ClickButton.Right);
        UpdateChannelVisuals(ClickButton.Left, leftRunning);
        UpdateChannelVisuals(ClickButton.Right, rightRunning);

        if (DateTime.UtcNow < _panicMessageUntilUtc)
        {
            _topStatusLabel.Text = "●  STOPPED";
            _topStatusLabel.ForeColor = Theme.AccentBright;
        }
        else if (leftRunning || rightRunning)
        {
            _topStatusLabel.Text = "●  RUNNING";
            _topStatusLabel.ForeColor = Theme.Success;
        }
        else
        {
            _topStatusLabel.Text = "●  READY";
            _topStatusLabel.ForeColor = Theme.Success;
        }

        UpdateOverlayPreview();
        UpdateOverlay();
    }

    private void UpdateChannelVisuals(ClickButton button, bool running)
    {
        var status = button == ClickButton.Left ? _leftStatusLabel : _rightStatusLabel;
        var action = button == ClickButton.Left ? _leftActionButton : _rightActionButton;
        status.Text = running ? "●  ACTIVE" : "●  OFF";
        status.ForeColor = running ? Theme.Success : Theme.TextMuted;
        action.Text = running ? "Остановить" : "Запустить";
        action.Style = running ? ButtonStyle.Danger : ButtonStyle.Primary;
        action.Invalidate();
    }

    private void UpdateStatistics()
    {
        var now = Stopwatch.GetTimestamp();
        var elapsed = (now - _lastStatsTimestamp) / (double)Stopwatch.Frequency;
        if (elapsed <= 0D) return;

        var leftClicks = _clickEngine.GetDeliveredClicks(ClickButton.Left);
        var rightClicks = _clickEngine.GetDeliveredClicks(ClickButton.Right);
        var rawLeft = Math.Max(0D, (leftClicks - _lastLeftClicks) / elapsed);
        var rawRight = Math.Max(0D, (rightClicks - _lastRightClicks) / elapsed);
        _leftCps = SmoothRate(_leftCps, rawLeft, _clickEngine.IsRunning(ClickButton.Left));
        _rightCps = SmoothRate(_rightCps, rawRight, _clickEngine.IsRunning(ClickButton.Right));
        _lastLeftClicks = leftClicks;
        _lastRightClicks = rightClicks;
        _lastStatsTimestamp = now;

        _leftRateLabel.Text = $"{_leftCps:N0} CPS";
        _rightRateLabel.Text = $"{_rightCps:N0} CPS";
        _totalClicksLabel.Text = $"{leftClicks + rightClicks:N0} кликов";
        _combinedRateLabel.Text = $"{_leftCps + _rightCps:N0} CPS";
        UpdateAllVisuals();
    }

    private static double SmoothRate(double previous, double current, bool running)
    {
        var next = running ? previous * 0.55D + current * 0.45D : previous * 0.42D;
        return next < 0.4D ? 0D : next;
    }

    private void ResetStatistics()
    {
        _clickEngine.ResetStatistics();
        _lastLeftClicks = 0;
        _lastRightClicks = 0;
        _leftCps = 0D;
        _rightCps = 0D;
        UpdateStatistics();
    }

    private void UpdateOverlay()
    {
        if (_closing || _overlay.IsDisposed) return;
        _overlay.UpdateState(
            _clickEngine.IsRunning(ClickButton.Left),
            _clickEngine.IsRunning(ClickButton.Right),
            _leftCps,
            _rightCps,
            _settings.IntervalMs);
    }

    private void UpdateOverlayPreview()
    {
        if (_overlayPreviewDetails is null) return;
        var leftRunning = _clickEngine.IsRunning(ClickButton.Left);
        var rightRunning = _clickEngine.IsRunning(ClickButton.Right);
        _overlayPreviewDot.ForeColor = leftRunning || rightRunning ? Theme.Accent : Theme.TextMuted;
        if (leftRunning && rightRunning)
        {
            _overlayPreviewDetails.Text = $"LMB  {_leftCps:N0} CPS   •   RMB  {_rightCps:N0} CPS";
        }
        else if (leftRunning)
        {
            _overlayPreviewDetails.Text = $"LMB  •  {_leftCps:N0} CPS  •  {_settings.IntervalMs} ms";
        }
        else if (rightRunning)
        {
            _overlayPreviewDetails.Text = $"RMB  •  {_rightCps:N0} CPS  •  {_settings.IntervalMs} ms";
        }
        else
        {
            _overlayPreviewDetails.Text = $"OFF  •  интервал {_settings.IntervalMs} ms";
        }
    }

    private void ClickEngineOnChannelStopped(object? sender, ClickChannelEventArgs e)
    {
        if (IsDisposed || _closing) return;
        try
        {
            BeginInvoke(new Action(UpdateAllVisuals));
        }
        catch (InvalidOperationException)
        {
            // The form closed while a worker was completing.
        }
    }

    private void ShowPage(string name, bool animate = true)
    {
        if (!_pages.TryGetValue(name, out var page)) return;
        foreach (var pair in _navButtons)
        {
            pair.Value.Selected = pair.Key == name;
        }
        _pageTitle.Text = name.ToUpperInvariant();

        if (ReferenceEquals(_currentPage, page)) return;
        _pageTransitionTimer?.Stop();
        page.Visible = true;
        page.BringToFront();
        if (!animate || _currentPage is null)
        {
            foreach (var other in _pages.Values) other.Visible = ReferenceEquals(other, page);
            page.Location = Point.Empty;
            _currentPage = page;
            return;
        }

        page.Location = new Point(18, 0);
        _transitionPage = page;
        _pageTransitionTimer.Start();
    }

    private void AnimatePageTransition()
    {
        if (_transitionPage is null)
        {
            _pageTransitionTimer.Stop();
            return;
        }

        var nextX = (int)Math.Round(_transitionPage.Left * 0.64D);
        _transitionPage.Left = nextX;
        if (nextX > 0) return;
        _transitionPage.Location = Point.Empty;
        foreach (var page in _pages.Values) page.Visible = ReferenceEquals(page, _transitionPage);
        _currentPage = _transitionPage;
        _transitionPage = null;
        _pageTransitionTimer.Stop();
    }

    private void BuildTray()
    {
        var menu = new ContextMenuStrip
        {
            BackColor = Theme.SurfaceRaised,
            ForeColor = Theme.TextPrimary,
            Font = Theme.Font(9F)
        };
        var open = new ToolStripMenuItem("Открыть Auto Clicker");
        open.Click += (_, _) => RestoreFromTray();
        var panic = new ToolStripMenuItem("Emergency Stop") { ForeColor = Theme.AccentBright };
        panic.Click += (_, _) => PanicStop();
        var exit = new ToolStripMenuItem("Выход");
        exit.Click += (_, _) => Close();
        menu.Items.AddRange(new ToolStripItem[] { open, panic, new ToolStripSeparator(), exit });

        _trayIcon = new NotifyIcon
        {
            Text = "AUTO CLICKER",
            Icon = SystemIcons.Application,
            ContextMenuStrip = menu,
            Visible = true
        };
        _trayIcon.DoubleClick += (_, _) => RestoreFromTray();
    }

    private void MinimizeIfNeeded()
    {
        if (WindowState != FormWindowState.Minimized || !_settings.MinimizeToTray) return;
        Hide();
        if (_trayHintShown) return;
        _trayHintShown = true;
        _trayIcon.ShowBalloonTip(1800, "AUTO CLICKER", "Приложение продолжает работать в трее.", ToolTipIcon.Info);
    }

    private void RestoreFromTray()
    {
        Show();
        WindowState = FormWindowState.Normal;
        Activate();
    }

    private void SaveSettings()
    {
        if (_loading) return;
        _saveTimer.Stop();
        _saveTimer.Start();
    }

    private void MainFormClosing(object? sender, FormClosingEventArgs e)
    {
        if (_closing) return;
        _closing = true;
        _statsTimer.Stop();
        _pageTransitionTimer.Stop();
        _saveTimer.Stop();
        _settingsStore.Save(_settings);
        _inputHook?.Dispose();
        _clickEngine.Dispose();
        _overlay.Hide();
        _overlay.Dispose();
        _trayIcon.Visible = false;
        _trayIcon.Dispose();
        _saveTimer.Dispose();
    }

    private void DragWindow(object? sender, MouseEventArgs e)
    {
        if (e.Button != MouseButtons.Left) return;
        NativeMethods.ReleaseCapture();
        NativeMethods.SendMessage(Handle, NativeMethods.WmNclbuttonDown, new IntPtr(NativeMethods.HtCaption), IntPtr.Zero);
    }

    private static string ModeName(HotkeyTriggerMode mode)
        => mode switch
        {
            HotkeyTriggerMode.Toggle => "TOGGLE",
            HotkeyTriggerMode.Press => "PRESS",
            _ => "HOLD"
        };
}
