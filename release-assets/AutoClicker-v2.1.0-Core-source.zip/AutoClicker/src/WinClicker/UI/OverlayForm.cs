using System.Diagnostics;
using System.Drawing.Drawing2D;
using WinClicker.Models;

namespace WinClicker.UI;

internal sealed class OverlayForm : Form
{
    private readonly System.Windows.Forms.Timer _animationTimer;
    private readonly uint _processId;
    private bool _leftRunning;
    private bool _rightRunning;
    private double _leftCps;
    private double _rightCps;
    private int _intervalMs = 50;
    private int _tick;
    private float _pulse;
    private bool _enabled;
    private OverlayCorner _corner = OverlayCorner.TopRight;
    private Screen? _anchorScreen;

    internal OverlayForm()
    {
        _processId = unchecked((uint)Process.GetCurrentProcess().Id);
        FormBorderStyle = FormBorderStyle.None;
        StartPosition = FormStartPosition.Manual;
        ShowInTaskbar = false;
        TopMost = true;
        BackColor = Theme.Surface;
        ClientSize = new Size(292, 72);
        DoubleBuffered = true;
        Font = Theme.Font(9F);

        _animationTimer = new System.Windows.Forms.Timer { Interval = 33 };
        _animationTimer.Tick += (_, _) =>
        {
            _pulse += 0.12F;
            if (++_tick % 8 == 0)
            {
                MaintainFullscreenPosition();
            }
            Invalidate();
        };
    }

    protected override bool ShowWithoutActivation => true;

    protected override CreateParams CreateParams
    {
        get
        {
            const int wsExTopmost = 0x00000008;
            const int wsExTransparent = 0x00000020;
            const int wsExToolWindow = 0x00000080;
            const int wsExLayered = 0x00080000;
            const int wsExNoActivate = 0x08000000;
            var parameters = base.CreateParams;
            parameters.ExStyle |= wsExTopmost | wsExTransparent | wsExToolWindow | wsExLayered | wsExNoActivate;
            return parameters;
        }
    }

    internal void Configure(AppSettings settings)
    {
        _enabled = settings.OverlayEnabled;
        _corner = settings.OverlayCorner;
        Opacity = Math.Clamp(settings.OverlayOpacityPercent / 100D, 0.35D, 1D);
        if (_enabled)
        {
            _animationTimer.Start();
            MaintainFullscreenPosition(forceScreenRefresh: true);
            if (!Visible)
            {
                Show();
            }
            MaintainFullscreenPosition();
        }
        else if (Visible)
        {
            _animationTimer.Stop();
            Hide();
        }
        else
        {
            _animationTimer.Stop();
        }
    }

    internal void UpdateState(
        bool leftRunning,
        bool rightRunning,
        double leftClicksPerSecond,
        double rightClicksPerSecond,
        int intervalMs)
    {
        _leftRunning = leftRunning;
        _rightRunning = rightRunning;
        _leftCps = Math.Max(0D, leftClicksPerSecond);
        _rightCps = Math.Max(0D, rightClicksPerSecond);
        _intervalMs = Math.Clamp(intervalMs, 1, 1000);
        Invalidate();
    }

    internal void MaintainFullscreenPosition(bool forceScreenRefresh = false)
    {
        if (IsDisposed || !_enabled)
        {
            return;
        }

        var foreground = NativeMethods.GetForegroundWindow();
        if (foreground != IntPtr.Zero)
        {
            NativeMethods.GetWindowThreadProcessId(foreground, out var foregroundProcessId);
            if (forceScreenRefresh || foregroundProcessId != _processId)
            {
                _anchorScreen = Screen.FromHandle(foreground);
            }
        }

        _anchorScreen ??= Screen.FromPoint(Cursor.Position);
        var area = _anchorScreen.Bounds;
        const int margin = 20;
        var x = _corner is OverlayCorner.TopRight or OverlayCorner.BottomRight
            ? area.Right - Width - margin
            : area.Left + margin;
        var y = _corner is OverlayCorner.BottomLeft or OverlayCorner.BottomRight
            ? area.Bottom - Height - margin
            : area.Top + margin;

        if (!IsHandleCreated)
        {
            Location = new Point(x, y);
            return;
        }

        NativeMethods.SetWindowPos(
            Handle,
            NativeMethods.HwndTopmost,
            x,
            y,
            Width,
            Height,
            NativeMethods.SwpNoActivate | NativeMethods.SwpShowWindow);
    }

    protected override void OnResize(EventArgs e)
    {
        base.OnResize(e);
        if (Width <= 2 || Height <= 2) return;
        using var path = Theme.RoundedRectangle(new Rectangle(0, 0, Width, Height), 16);
        Region?.Dispose();
        Region = new Region(path);
    }

    protected override void WndProc(ref Message message)
    {
        if (message.Msg == NativeMethods.WmNcHitTest)
        {
            message.Result = new IntPtr(NativeMethods.HtTransparent);
            return;
        }

        base.WndProc(ref message);
    }

    protected override void OnPaint(PaintEventArgs e)
    {
        e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
        e.Graphics.Clear(Theme.Background);
        var bounds = new Rectangle(0, 0, Width - 1, Height - 1);
        using var path = Theme.RoundedRectangle(bounds, 16);
        using var background = new LinearGradientBrush(bounds, Theme.SurfaceRaised, Theme.Surface, 12F);
        e.Graphics.FillPath(background, path);

        var running = _leftRunning || _rightRunning;
        var borderColor = running ? Color.FromArgb(150, Theme.AccentDark) : Theme.Border;
        using (var border = new Pen(borderColor)) e.Graphics.DrawPath(border, path);

        using var accentLine = new LinearGradientBrush(
            new Rectangle(0, 0, Width, 3),
            running ? Theme.Accent : Theme.Border,
            Color.Transparent,
            0F);
        e.Graphics.FillRectangle(accentLine, 18, 0, running ? 118 : 58, 2);

        var pulseAmount = running ? (float)((Math.Sin(_pulse) + 1D) / 2D) : 0F;
        var dotColor = running ? Theme.Accent : Theme.TextMuted;
        if (running)
        {
            using var glow = new SolidBrush(Color.FromArgb(25 + (int)(35 * pulseAmount), dotColor));
            e.Graphics.FillEllipse(glow, 13, 19, 22, 22);
        }
        using (var dot = new SolidBrush(dotColor)) e.Graphics.FillEllipse(dot, 20, 26, 8, 8);

        using var titleFont = Theme.Font(9.3F, true);
        using var detailsFont = Theme.Font(8F);
        TextRenderer.DrawText(
            e.Graphics,
            "AUTO CLICKER",
            titleFont,
            new Rectangle(44, 12, 220, 24),
            running ? Theme.TextPrimary : Theme.TextSecondary,
            TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.SingleLine);
        TextRenderer.DrawText(
            e.Graphics,
            BuildDetails(),
            detailsFont,
            new Rectangle(44, 38, 230, 20),
            running ? Theme.TextSecondary : Theme.TextMuted,
            TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.EndEllipsis | TextFormatFlags.SingleLine);
    }

    private string BuildDetails()
    {
        if (_leftRunning && _rightRunning)
        {
            return $"LMB  {_leftCps:N0} CPS   •   RMB  {_rightCps:N0} CPS";
        }

        if (_leftRunning)
        {
            return $"LMB  •  {_leftCps:N0} CPS  •  {_intervalMs} ms";
        }

        if (_rightRunning)
        {
            return $"RMB  •  {_rightCps:N0} CPS  •  {_intervalMs} ms";
        }

        return $"OFF  •  интервал {_intervalMs} ms";
    }

    protected override void Dispose(bool disposing)
    {
        if (disposing) _animationTimer.Dispose();
        base.Dispose(disposing);
    }
}
