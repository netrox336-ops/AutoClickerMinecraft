using System.Text.Json.Serialization;
using System.Windows.Forms;

namespace WinClicker.Models;

internal enum ClickButton
{
    Left = 0,
    Right = 1
}

internal enum HotkeyTriggerMode
{
    Toggle = 0,
    Hold = 1,
    Press = 2
}

internal enum OverlayCorner
{
    TopLeft = 0,
    TopRight = 1,
    BottomLeft = 2,
    BottomRight = 3
}

internal enum HotkeyMouseButton
{
    None = 0,
    Middle = 1,
    Mouse4 = 2,
    Mouse5 = 3
}

internal sealed class HotkeyBinding : IEquatable<HotkeyBinding>
{
    public int VirtualKey { get; set; }
    public HotkeyMouseButton MouseButton { get; set; }
    public bool Control { get; set; }
    public bool Alt { get; set; }
    public bool Shift { get; set; }
    public bool Win { get; set; }

    [JsonIgnore]
    public bool IsMouse => MouseButton != HotkeyMouseButton.None;

    [JsonIgnore]
    public bool IsDisabled => !IsMouse && VirtualKey <= 0;

    [JsonIgnore]
    public int ModifierCount => (Control ? 1 : 0) + (Alt ? 1 : 0) + (Shift ? 1 : 0) + (Win ? 1 : 0);

    public static HotkeyBinding Disabled() => new();

    public static HotkeyBinding FromKey(
        Keys key,
        bool control = false,
        bool alt = false,
        bool shift = false,
        bool win = false)
    {
        return new HotkeyBinding
        {
            VirtualKey = (int)key,
            MouseButton = HotkeyMouseButton.None,
            Control = control,
            Alt = alt,
            Shift = shift,
            Win = win
        };
    }

    public static HotkeyBinding FromMouse(
        HotkeyMouseButton button,
        bool control = false,
        bool alt = false,
        bool shift = false,
        bool win = false)
    {
        return new HotkeyBinding
        {
            MouseButton = button,
            Control = control,
            Alt = alt,
            Shift = shift,
            Win = win
        };
    }

    public HotkeyBinding Clone()
    {
        return new HotkeyBinding
        {
            VirtualKey = VirtualKey,
            MouseButton = MouseButton,
            Control = Control,
            Alt = Alt,
            Shift = Shift,
            Win = Win
        };
    }

    public void Normalize()
    {
        if (MouseButton != HotkeyMouseButton.None)
        {
            if (!Enum.IsDefined(MouseButton))
            {
                Reset();
                return;
            }

            VirtualKey = 0;
            return;
        }

        if (VirtualKey is < 1 or > 255 || IsModifierKey((Keys)VirtualKey))
        {
            Reset();
        }
    }

    public bool MatchesKeyboard(
        int virtualKey,
        bool control,
        bool alt,
        bool shift,
        bool win,
        bool ignoreExtraModifiers)
    {
        return !IsMouse
            && !IsDisabled
            && VirtualKey == virtualKey
            && ModifiersMatch(control, alt, shift, win, ignoreExtraModifiers);
    }

    public bool MatchesMouse(
        HotkeyMouseButton button,
        bool control,
        bool alt,
        bool shift,
        bool win,
        bool ignoreExtraModifiers)
    {
        return IsMouse
            && MouseButton == button
            && ModifiersMatch(control, alt, shift, win, ignoreExtraModifiers);
    }

    public string ToDisplayString()
    {
        if (IsDisabled)
        {
            return "Не назначено";
        }

        var parts = new List<string>(5);
        if (Control) parts.Add("Ctrl");
        if (Alt) parts.Add("Alt");
        if (Shift) parts.Add("Shift");
        if (Win) parts.Add("Win");
        parts.Add(IsMouse ? GetMouseButtonName(MouseButton) : GetKeyName((Keys)VirtualKey));
        return string.Join(" + ", parts);
    }

    public bool Equals(HotkeyBinding? other)
    {
        return other is not null
            && VirtualKey == other.VirtualKey
            && MouseButton == other.MouseButton
            && Control == other.Control
            && Alt == other.Alt
            && Shift == other.Shift
            && Win == other.Win;
    }

    public override bool Equals(object? obj) => Equals(obj as HotkeyBinding);

    public override int GetHashCode() => HashCode.Combine(VirtualKey, MouseButton, Control, Alt, Shift, Win);

    public static bool IsModifierKey(Keys key)
    {
        return key is Keys.ControlKey or Keys.LControlKey or Keys.RControlKey
            or Keys.Menu or Keys.LMenu or Keys.RMenu
            or Keys.ShiftKey or Keys.LShiftKey or Keys.RShiftKey
            or Keys.LWin or Keys.RWin;
    }

    private bool ModifiersMatch(bool control, bool alt, bool shift, bool win, bool ignoreExtraModifiers)
    {
        if (ignoreExtraModifiers)
        {
            return (!Control || control)
                && (!Alt || alt)
                && (!Shift || shift)
                && (!Win || win);
        }

        return Control == control && Alt == alt && Shift == shift && Win == win;
    }

    private void Reset()
    {
        VirtualKey = 0;
        MouseButton = HotkeyMouseButton.None;
        Control = false;
        Alt = false;
        Shift = false;
        Win = false;
    }

    private static string GetMouseButtonName(HotkeyMouseButton button)
    {
        return button switch
        {
            HotkeyMouseButton.Middle => "Mouse 3",
            HotkeyMouseButton.Mouse4 => "Mouse 4",
            HotkeyMouseButton.Mouse5 => "Mouse 5",
            _ => "Mouse"
        };
    }

    private static string GetKeyName(Keys key)
    {
        var virtualKey = (int)key;
        if (virtualKey >= (int)Keys.D0 && virtualKey <= (int)Keys.D9)
        {
            return ((char)('0' + virtualKey - (int)Keys.D0)).ToString();
        }

        if (virtualKey >= (int)Keys.A && virtualKey <= (int)Keys.Z)
        {
            return key.ToString();
        }

        if (virtualKey >= (int)Keys.NumPad0 && virtualKey <= (int)Keys.NumPad9)
        {
            return $"Num {virtualKey - (int)Keys.NumPad0}";
        }

        return key switch
        {
            Keys.Space => "Space",
            Keys.Enter => "Enter",
            Keys.Escape => "Esc",
            Keys.Back => "Backspace",
            Keys.Delete => "Delete",
            Keys.Insert => "Insert",
            Keys.PageUp => "Page Up",
            Keys.PageDown => "Page Down",
            Keys.Left => "Left",
            Keys.Right => "Right",
            Keys.Up => "Up",
            Keys.Down => "Down",
            _ => key.ToString()
        };
    }
}

internal sealed class AppSettings
{
    public int SchemaVersion { get; set; } = 3;
    public int IntervalMs { get; set; } = 50;

    public HotkeyBinding LeftHotkey { get; set; } = HotkeyBinding.FromMouse(HotkeyMouseButton.Mouse4);
    public HotkeyTriggerMode LeftHotkeyMode { get; set; } = HotkeyTriggerMode.Hold;
    public HotkeyBinding RightHotkey { get; set; } = HotkeyBinding.FromMouse(HotkeyMouseButton.Mouse5);
    public HotkeyTriggerMode RightHotkeyMode { get; set; } = HotkeyTriggerMode.Hold;
    public HotkeyBinding PanicHotkey { get; set; } = HotkeyBinding.FromKey(Keys.F12);

    public bool IgnoreExtraModifiers { get; set; } = true;
    public bool SuppressHotkeys { get; set; } = true;
    public bool MinimizeToTray { get; set; } = true;

    public bool OverlayEnabled { get; set; }
    public OverlayCorner OverlayCorner { get; set; } = global::WinClicker.Models.OverlayCorner.TopRight;
    public int OverlayOpacityPercent { get; set; } = 82;

    public void Normalize()
    {
        SchemaVersion = 3;
        IntervalMs = Math.Clamp(IntervalMs, 1, 1000);
        OverlayOpacityPercent = Math.Clamp(OverlayOpacityPercent, 35, 100);

        if (!Enum.IsDefined(LeftHotkeyMode)) LeftHotkeyMode = HotkeyTriggerMode.Hold;
        if (!Enum.IsDefined(RightHotkeyMode)) RightHotkeyMode = HotkeyTriggerMode.Hold;
        if (!Enum.IsDefined(OverlayCorner)) OverlayCorner = global::WinClicker.Models.OverlayCorner.TopRight;

        LeftHotkey ??= HotkeyBinding.FromMouse(HotkeyMouseButton.Mouse4);
        RightHotkey ??= HotkeyBinding.FromMouse(HotkeyMouseButton.Mouse5);
        PanicHotkey ??= HotkeyBinding.FromKey(Keys.F12);
        LeftHotkey.Normalize();
        RightHotkey.Normalize();
        PanicHotkey.Normalize();

        if (PanicHotkey.IsDisabled)
        {
            PanicHotkey = HotkeyBinding.FromKey(Keys.F12);
        }

        if (!LeftHotkey.IsDisabled && LeftHotkey.Equals(PanicHotkey))
        {
            LeftHotkey = FirstAvailable(
                new[]
                {
                    HotkeyBinding.FromMouse(HotkeyMouseButton.Mouse4),
                    HotkeyBinding.FromKey(Keys.F6),
                    HotkeyBinding.FromKey(Keys.F8)
                },
                PanicHotkey);
        }

        if (!RightHotkey.IsDisabled
            && (RightHotkey.Equals(PanicHotkey)
                || (!LeftHotkey.IsDisabled && RightHotkey.Equals(LeftHotkey))))
        {
            RightHotkey = FirstAvailable(
                new[]
                {
                    HotkeyBinding.FromMouse(HotkeyMouseButton.Mouse5),
                    HotkeyBinding.FromKey(Keys.F7),
                    HotkeyBinding.FromKey(Keys.F9)
                },
                PanicHotkey,
                LeftHotkey);
        }
    }

    private static HotkeyBinding FirstAvailable(
        IEnumerable<HotkeyBinding> candidates,
        params HotkeyBinding[] unavailable)
    {
        return candidates.First(candidate => unavailable.All(value => !candidate.Equals(value)));
    }
}
