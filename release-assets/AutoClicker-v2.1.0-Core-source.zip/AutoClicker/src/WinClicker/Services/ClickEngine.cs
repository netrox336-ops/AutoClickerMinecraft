using System.Diagnostics;
using System.Runtime.InteropServices;
using WinClicker.Models;

namespace WinClicker.Services;

internal sealed class ClickChannelEventArgs : EventArgs
{
    internal ClickChannelEventArgs(ClickButton button) => Button = button;
    internal ClickButton Button { get; }
}

internal sealed class ClickEngine : IDisposable
{
    private sealed class Channel
    {
        internal readonly object Gate = new();
        internal readonly ClickButton Button;
        internal Thread? Worker;
        internal ManualResetEvent? StopSignal;
        internal int Generation;
        internal long DeliveredClicks;

        internal Channel(ClickButton button) => Button = button;
    }

    private readonly Channel _left = new(ClickButton.Left);
    private readonly Channel _right = new(ClickButton.Right);
    private readonly NativeMethods.Input[] _leftClick = BuildClickInputs(ClickButton.Left);
    private readonly NativeMethods.Input[] _rightClick = BuildClickInputs(ClickButton.Right);
    private int _intervalMs = 50;
    private bool _disposed;

    internal event EventHandler<ClickChannelEventArgs>? ChannelStopped;

    internal int IntervalMs
    {
        get => Volatile.Read(ref _intervalMs);
        set => Volatile.Write(ref _intervalMs, Math.Clamp(value, 1, 1000));
    }

    internal bool IsRunning(ClickButton button)
    {
        var channel = GetChannel(button);
        lock (channel.Gate)
        {
            return channel.Worker is { IsAlive: true };
        }
    }

    internal long GetDeliveredClicks(ClickButton button)
        => Interlocked.Read(ref GetChannel(button).DeliveredClicks);

    internal long TotalDeliveredClicks
        => GetDeliveredClicks(ClickButton.Left) + GetDeliveredClicks(ClickButton.Right);

    internal bool Start(ClickButton button)
    {
        ObjectDisposedException.ThrowIf(_disposed, this);
        var channel = GetChannel(button);
        lock (channel.Gate)
        {
            if (channel.Worker is { IsAlive: true })
            {
                return false;
            }

            channel.StopSignal?.Dispose();
            channel.StopSignal = new ManualResetEvent(false);
            var signal = channel.StopSignal;
            var generation = unchecked(++channel.Generation);
            channel.Worker = new Thread(() => WorkerLoop(channel, signal, generation))
            {
                IsBackground = true,
                Name = button == ClickButton.Left
                    ? "AutoClicker.LMB"
                    : "AutoClicker.RMB",
                Priority = ThreadPriority.AboveNormal
            };
            channel.Worker.Start();
            return true;
        }
    }

    internal void Stop(ClickButton button)
    {
        StopChannel(GetChannel(button), joinMilliseconds: 900);
    }

    internal void Toggle(ClickButton button)
    {
        if (IsRunning(button))
        {
            Stop(button);
        }
        else
        {
            Start(button);
        }
    }

    internal void TriggerOnce(ClickButton button)
    {
        ObjectDisposedException.ThrowIf(_disposed, this);
        SendClick(GetChannel(button));
    }

    internal void PanicStop()
    {
        SignalChannel(_left);
        SignalChannel(_right);
        ReleasePressedButtons();
    }

    internal void ResetStatistics()
    {
        Interlocked.Exchange(ref _left.DeliveredClicks, 0);
        Interlocked.Exchange(ref _right.DeliveredClicks, 0);
    }

    private void WorkerLoop(Channel channel, ManualResetEvent stopSignal, int generation)
    {
        NativeMethods.timeBeginPeriod(1);
        try
        {
            while (!stopSignal.WaitOne(0) && generation == Volatile.Read(ref channel.Generation))
            {
                SendClick(channel);
                if (WaitInterval(stopSignal, IntervalMs))
                {
                    break;
                }
            }
        }
        finally
        {
            NativeMethods.timeEndPeriod(1);
            lock (channel.Gate)
            {
                if (ReferenceEquals(channel.StopSignal, stopSignal))
                {
                    channel.Worker = null;
                }
            }

            try
            {
                ChannelStopped?.Invoke(this, new ClickChannelEventArgs(channel.Button));
            }
            catch
            {
                // UI subscribers must not be able to break worker cleanup.
            }
        }
    }

    private void SendClick(Channel channel)
    {
        if (!OperatingSystem.IsWindows())
        {
            return;
        }

        var inputs = channel.Button == ClickButton.Left ? _leftClick : _rightClick;
        var deliveredEvents = NativeMethods.SendInput(
            (uint)inputs.Length,
            inputs,
            Marshal.SizeOf<NativeMethods.Input>());
        if (deliveredEvents >= 2)
        {
            Interlocked.Increment(ref channel.DeliveredClicks);
        }
    }

    private static bool WaitInterval(WaitHandle stopSignal, int milliseconds)
    {
        milliseconds = Math.Clamp(milliseconds, 1, 1000);
        if (milliseconds <= 2)
        {
            return stopSignal.WaitOne(milliseconds);
        }

        var coarseWait = milliseconds - 1;
        if (stopSignal.WaitOne(coarseWait))
        {
            return true;
        }

        var target = Stopwatch.GetTimestamp() + Stopwatch.Frequency / 1000;
        while (Stopwatch.GetTimestamp() < target)
        {
            if (stopSignal.WaitOne(0))
            {
                return true;
            }

            Thread.SpinWait(32);
        }

        return false;
    }

    private static NativeMethods.Input[] BuildClickInputs(ClickButton button)
    {
        var downFlag = button == ClickButton.Left
            ? NativeMethods.MouseeventfLeftdown
            : NativeMethods.MouseeventfRightdown;
        var upFlag = button == ClickButton.Left
            ? NativeMethods.MouseeventfLeftup
            : NativeMethods.MouseeventfRightup;
        return new[] { CreateMouseInput(downFlag), CreateMouseInput(upFlag) };
    }

    private static NativeMethods.Input CreateMouseInput(uint flags, uint mouseData = 0)
    {
        return new NativeMethods.Input
        {
            type = NativeMethods.InputMouse,
            data = new NativeMethods.InputUnion
            {
                mouse = new NativeMethods.MouseInput
                {
                    mouseData = mouseData,
                    dwFlags = flags
                }
            }
        };
    }

    internal static void ReleasePressedButtons()
    {
        if (!OperatingSystem.IsWindows())
        {
            return;
        }

        var inputs = new[]
        {
            CreateMouseInput(NativeMethods.MouseeventfLeftup),
            CreateMouseInput(NativeMethods.MouseeventfRightup),
            CreateMouseInput(NativeMethods.MouseeventfMiddleup),
            CreateMouseInput(NativeMethods.MouseeventfXup, NativeMethods.XButton1),
            CreateMouseInput(NativeMethods.MouseeventfXup, NativeMethods.XButton2)
        };
        NativeMethods.SendInput((uint)inputs.Length, inputs, Marshal.SizeOf<NativeMethods.Input>());
    }

    private Channel GetChannel(ClickButton button) => button == ClickButton.Left ? _left : _right;

    private static void SignalChannel(Channel channel)
    {
        lock (channel.Gate)
        {
            unchecked
            {
                channel.Generation++;
            }

            channel.StopSignal?.Set();
        }
    }

    private static void StopChannel(Channel channel, int joinMilliseconds)
    {
        Thread? worker;
        lock (channel.Gate)
        {
            unchecked
            {
                channel.Generation++;
            }

            channel.StopSignal?.Set();
            worker = channel.Worker;
        }

        if (worker is { IsAlive: true } && worker != Thread.CurrentThread)
        {
            worker.Join(joinMilliseconds);
        }
    }

    public void Dispose()
    {
        if (_disposed)
        {
            return;
        }

        SignalChannel(_left);
        SignalChannel(_right);
        StopChannel(_left, 700);
        StopChannel(_right, 700);
        _left.StopSignal?.Dispose();
        _right.StopSignal?.Dispose();
        ReleasePressedButtons();
        _disposed = true;
        GC.SuppressFinalize(this);
    }
}
