using System.ComponentModel;
using System.Runtime.InteropServices;
using WinClicker.Models;

namespace WinClicker.Services;

internal enum HotkeyAction
{
    LeftClicker,
    RightClicker,
    Panic
}

internal enum HotkeySignal
{
    Pressed,
    Released
}

internal sealed class GlobalHotkeyEventArgs : EventArgs
{
    internal GlobalHotkeyEventArgs(HotkeyAction action, HotkeySignal signal)
    {
        Action = action;
        Signal = signal;
    }

    internal HotkeyAction Action { get; }
    internal HotkeySignal Signal { get; }
}

internal sealed record HookConfiguration(
    HotkeyBinding Left,
    HotkeyBinding Right,
    HotkeyBinding Panic,
    bool IgnoreExtraModifiers,
    bool SuppressHotkeys);

internal sealed class GlobalInputHook : IDisposable
{
    private readonly NativeMethods.LowLevelKeyboardProc _keyboardCallback;
    private readonly NativeMethods.LowLevelMouseProc _mouseCallback;
    private readonly HashSet<int> _pressedKeys = new();
    private readonly HashSet<int> _suppressedKeys = new();
    private readonly Dictionary<int, HotkeyAction> _activeKeyboardActions = new();
    private readonly HashSet<HotkeyMouseButton> _pressedMouseButtons = new();
    private readonly HashSet<HotkeyMouseButton> _suppressedMouseButtons = new();
    private readonly Dictionary<HotkeyMouseButton, HotkeyAction> _activeMouseActions = new();
    private readonly HashSet<HotkeyMouseButton> _captureSuppressedMouseButtons = new();
    private IntPtr _keyboardHookHandle;
    private IntPtr _mouseHookHandle;
    private HookConfiguration _configuration = new(
        HotkeyBinding.FromMouse(HotkeyMouseButton.Mouse4),
        HotkeyBinding.FromMouse(HotkeyMouseButton.Mouse5),
        HotkeyBinding.FromKey(Keys.F12),
        true,
        true);
    private bool _suspended;
    private bool _disposed;

    internal GlobalInputHook()
    {
        _keyboardCallback = KeyboardHookCallback;
        _mouseCallback = MouseHookCallback;
    }

    internal event EventHandler<GlobalHotkeyEventArgs>? HotkeyChanged;
    internal event EventHandler<HotkeyBinding>? MouseBindingCaptured;

    internal bool Suspended
    {
        get => _suspended;
        set
        {
            if (value)
            {
                _captureSuppressedMouseButtons.Clear();
            }
            _suspended = value;
            _pressedKeys.Clear();
            _suppressedKeys.Clear();
            _activeKeyboardActions.Clear();
            _pressedMouseButtons.Clear();
            _suppressedMouseButtons.Clear();
            _activeMouseActions.Clear();
        }
    }

    internal void Start()
    {
        ObjectDisposedException.ThrowIf(_disposed, this);
        if (_keyboardHookHandle != IntPtr.Zero || _mouseHookHandle != IntPtr.Zero)
        {
            return;
        }

        var moduleHandle = NativeMethods.GetModuleHandle(null);
        _keyboardHookHandle = NativeMethods.SetWindowsKeyboardHookEx(
            NativeMethods.WhKeyboardLl,
            _keyboardCallback,
            moduleHandle,
            0);
        if (_keyboardHookHandle == IntPtr.Zero)
        {
            throw new Win32Exception(Marshal.GetLastWin32Error(), "Не удалось подключить глобальные клавиатурные хоткеи.");
        }

        _mouseHookHandle = NativeMethods.SetWindowsMouseHookEx(
            NativeMethods.WhMouseLl,
            _mouseCallback,
            moduleHandle,
            0);
        if (_mouseHookHandle == IntPtr.Zero)
        {
            var error = Marshal.GetLastWin32Error();
            NativeMethods.UnhookWindowsHookEx(_keyboardHookHandle);
            _keyboardHookHandle = IntPtr.Zero;
            throw new Win32Exception(error, "Не удалось подключить глобальные хоткеи мыши.");
        }
    }

    internal void UpdateConfiguration(AppSettings settings)
    {
        _configuration = new HookConfiguration(
            settings.LeftHotkey.Clone(),
            settings.RightHotkey.Clone(),
            settings.PanicHotkey.Clone(),
            settings.IgnoreExtraModifiers,
            settings.SuppressHotkeys);
    }

    private IntPtr KeyboardHookCallback(int nCode, IntPtr wParam, IntPtr lParam)
    {
        if (nCode < 0)
        {
            return NextKeyboard(nCode, wParam, lParam);
        }

        var message = unchecked((int)wParam.ToInt64());
        var isDown = message is NativeMethods.WmKeyDown or NativeMethods.WmSysKeyDown;
        var isUp = message is NativeMethods.WmKeyUp or NativeMethods.WmSysKeyUp;
        if (!isDown && !isUp)
        {
            return NextKeyboard(nCode, wParam, lParam);
        }

        var data = Marshal.PtrToStructure<NativeMethods.KbdLlHookStruct>(lParam);
        var virtualKey = unchecked((int)data.vkCode);
        if (isUp)
        {
            _pressedKeys.Remove(virtualKey);
            if (_activeKeyboardActions.Remove(virtualKey, out var releasedAction) && !_suspended)
            {
                RaiseHotkey(releasedAction, HotkeySignal.Released);
            }

            return _suppressedKeys.Remove(virtualKey)
                ? new IntPtr(1)
                : NextKeyboard(nCode, wParam, lParam);
        }

        if (_suspended)
        {
            return NextKeyboard(nCode, wParam, lParam);
        }

        if (!_pressedKeys.Add(virtualKey))
        {
            return _suppressedKeys.Contains(virtualKey)
                ? new IntPtr(1)
                : NextKeyboard(nCode, wParam, lParam);
        }

        GetModifiers(out var control, out var alt, out var shift, out var win);
        var action = SelectKeyboardAction(_configuration, virtualKey, control, alt, shift, win);
        if (action is null)
        {
            return NextKeyboard(nCode, wParam, lParam);
        }

        _activeKeyboardActions[virtualKey] = action.Value;
        RaiseHotkey(action.Value, HotkeySignal.Pressed);
        if (!_configuration.SuppressHotkeys)
        {
            return NextKeyboard(nCode, wParam, lParam);
        }

        _suppressedKeys.Add(virtualKey);
        return new IntPtr(1);
    }

    private IntPtr MouseHookCallback(int nCode, IntPtr wParam, IntPtr lParam)
    {
        if (nCode < 0)
        {
            return NextMouse(nCode, wParam, lParam);
        }

        var message = unchecked((int)wParam.ToInt64());
        var data = Marshal.PtrToStructure<NativeMethods.MsLlHookStruct>(lParam);
        if ((data.flags & NativeMethods.LlMhfInjected) != 0
            || !TryGetMouseButton(message, data.mouseData, out var button, out var isDown, out var isUp))
        {
            return NextMouse(nCode, wParam, lParam);
        }

        if (isUp)
        {
            _pressedMouseButtons.Remove(button);
            if (_activeMouseActions.Remove(button, out var releasedAction) && !_suspended)
            {
                RaiseHotkey(releasedAction, HotkeySignal.Released);
            }

            return _captureSuppressedMouseButtons.Remove(button) || _suppressedMouseButtons.Remove(button)
                ? new IntPtr(1)
                : NextMouse(nCode, wParam, lParam);
        }

        if (!isDown || !_pressedMouseButtons.Add(button))
        {
            return _suppressedMouseButtons.Contains(button)
                ? new IntPtr(1)
                : NextMouse(nCode, wParam, lParam);
        }

        GetModifiers(out var control, out var alt, out var shift, out var win);
        if (_suspended)
        {
            _captureSuppressedMouseButtons.Add(button);
            try
            {
                MouseBindingCaptured?.Invoke(this, HotkeyBinding.FromMouse(button, control, alt, shift, win));
            }
            catch
            {
                // A capture dialog must not be able to break the global hook chain.
            }

            return new IntPtr(1);
        }

        var action = SelectMouseAction(_configuration, button, control, alt, shift, win);
        if (action is null)
        {
            return NextMouse(nCode, wParam, lParam);
        }

        _activeMouseActions[button] = action.Value;
        RaiseHotkey(action.Value, HotkeySignal.Pressed);
        if (!_configuration.SuppressHotkeys)
        {
            return NextMouse(nCode, wParam, lParam);
        }

        _suppressedMouseButtons.Add(button);
        return new IntPtr(1);
    }

    private void RaiseHotkey(HotkeyAction action, HotkeySignal signal)
    {
        try
        {
            HotkeyChanged?.Invoke(this, new GlobalHotkeyEventArgs(action, signal));
        }
        catch
        {
            // Subscribers execute outside hook reliability guarantees.
        }
    }

    private static HotkeyAction? SelectKeyboardAction(
        HookConfiguration configuration,
        int virtualKey,
        bool control,
        bool alt,
        bool shift,
        bool win)
    {
        HotkeyAction? bestAction = null;
        var bestModifierCount = -1;
        Consider(configuration.Panic.MatchesKeyboard(virtualKey, control, alt, shift, win, configuration.IgnoreExtraModifiers),
            configuration.Panic, HotkeyAction.Panic, ref bestAction, ref bestModifierCount);
        Consider(configuration.Left.MatchesKeyboard(virtualKey, control, alt, shift, win, configuration.IgnoreExtraModifiers),
            configuration.Left, HotkeyAction.LeftClicker, ref bestAction, ref bestModifierCount);
        Consider(configuration.Right.MatchesKeyboard(virtualKey, control, alt, shift, win, configuration.IgnoreExtraModifiers),
            configuration.Right, HotkeyAction.RightClicker, ref bestAction, ref bestModifierCount);
        return bestAction;
    }

    private static HotkeyAction? SelectMouseAction(
        HookConfiguration configuration,
        HotkeyMouseButton button,
        bool control,
        bool alt,
        bool shift,
        bool win)
    {
        HotkeyAction? bestAction = null;
        var bestModifierCount = -1;
        Consider(configuration.Panic.MatchesMouse(button, control, alt, shift, win, configuration.IgnoreExtraModifiers),
            configuration.Panic, HotkeyAction.Panic, ref bestAction, ref bestModifierCount);
        Consider(configuration.Left.MatchesMouse(button, control, alt, shift, win, configuration.IgnoreExtraModifiers),
            configuration.Left, HotkeyAction.LeftClicker, ref bestAction, ref bestModifierCount);
        Consider(configuration.Right.MatchesMouse(button, control, alt, shift, win, configuration.IgnoreExtraModifiers),
            configuration.Right, HotkeyAction.RightClicker, ref bestAction, ref bestModifierCount);
        return bestAction;
    }

    private static void Consider(
        bool matches,
        HotkeyBinding binding,
        HotkeyAction action,
        ref HotkeyAction? bestAction,
        ref int bestModifierCount)
    {
        if (!matches || binding.ModifierCount <= bestModifierCount)
        {
            return;
        }

        bestAction = action;
        bestModifierCount = binding.ModifierCount;
    }

    private static void GetModifiers(out bool control, out bool alt, out bool shift, out bool win)
    {
        control = NativeMethods.IsKeyDown(NativeMethods.VkControl);
        alt = NativeMethods.IsKeyDown(NativeMethods.VkMenu);
        shift = NativeMethods.IsKeyDown(NativeMethods.VkShift);
        win = NativeMethods.IsKeyDown(NativeMethods.VkLWin) || NativeMethods.IsKeyDown(NativeMethods.VkRWin);
    }

    private static bool TryGetMouseButton(
        int message,
        uint mouseData,
        out HotkeyMouseButton button,
        out bool isDown,
        out bool isUp)
    {
        button = HotkeyMouseButton.None;
        isDown = false;
        isUp = false;
        switch (message)
        {
            case NativeMethods.WmMButtonDown:
                button = HotkeyMouseButton.Middle;
                isDown = true;
                return true;
            case NativeMethods.WmMButtonUp:
                button = HotkeyMouseButton.Middle;
                isUp = true;
                return true;
            case NativeMethods.WmXButtonDown:
            case NativeMethods.WmXButtonUp:
                var xButton = (mouseData >> 16) & 0xFFFF;
                button = xButton == NativeMethods.XButton1
                    ? HotkeyMouseButton.Mouse4
                    : xButton == NativeMethods.XButton2
                        ? HotkeyMouseButton.Mouse5
                        : HotkeyMouseButton.None;
                isDown = message == NativeMethods.WmXButtonDown;
                isUp = message == NativeMethods.WmXButtonUp;
                return button != HotkeyMouseButton.None;
            default:
                return false;
        }
    }

    private IntPtr NextKeyboard(int nCode, IntPtr wParam, IntPtr lParam)
        => NativeMethods.CallNextHookEx(_keyboardHookHandle, nCode, wParam, lParam);

    private IntPtr NextMouse(int nCode, IntPtr wParam, IntPtr lParam)
        => NativeMethods.CallNextHookEx(_mouseHookHandle, nCode, wParam, lParam);

    public void Dispose()
    {
        if (_disposed)
        {
            return;
        }

        if (_keyboardHookHandle != IntPtr.Zero)
        {
            NativeMethods.UnhookWindowsHookEx(_keyboardHookHandle);
            _keyboardHookHandle = IntPtr.Zero;
        }

        if (_mouseHookHandle != IntPtr.Zero)
        {
            NativeMethods.UnhookWindowsHookEx(_mouseHookHandle);
            _mouseHookHandle = IntPtr.Zero;
        }

        _disposed = true;
        GC.SuppressFinalize(this);
    }
}
