using System.Windows.Forms;
using WinClicker.Models;

namespace WinClicker.Services;

internal static class SelfTestRunner
{
    internal static int Run()
    {
        try
        {
            TestHotkeyMatching();
            TestIndependentDefaults();
            TestSettingsNormalization();
            return 0;
        }
        catch
        {
            return 1;
        }
    }

    private static void TestHotkeyMatching()
    {
        var plainF6 = HotkeyBinding.FromKey(Keys.F6);
        Assert(plainF6.MatchesKeyboard((int)Keys.F6, false, false, true, false, true),
            "Совместимый режим должен принимать лишний Shift.");
        Assert(!plainF6.MatchesKeyboard((int)Keys.F6, false, false, true, false, false),
            "Строгий режим не должен принимать лишний Shift.");

        var mouse4 = HotkeyBinding.FromMouse(HotkeyMouseButton.Mouse4);
        Assert(mouse4.MatchesMouse(HotkeyMouseButton.Mouse4, false, false, false, false, true),
            "Mouse 4 должен совпадать со своим физическим событием.");
        Assert(!mouse4.MatchesMouse(HotkeyMouseButton.Mouse5, false, false, false, false, true),
            "Mouse 4 и Mouse 5 должны оставаться независимыми.");
    }

    private static void TestIndependentDefaults()
    {
        var settings = new AppSettings();
        settings.Normalize();
        Assert(settings.LeftHotkey.MouseButton == HotkeyMouseButton.Mouse4,
            "LMB по умолчанию должен использовать Mouse 4.");
        Assert(settings.RightHotkey.MouseButton == HotkeyMouseButton.Mouse5,
            "RMB по умолчанию должен использовать Mouse 5.");
        Assert(settings.LeftHotkeyMode == HotkeyTriggerMode.Hold
            && settings.RightHotkeyMode == HotkeyTriggerMode.Hold,
            "Оба независимых канала должны начинать в режиме Hold.");
    }

    private static void TestSettingsNormalization()
    {
        var settings = new AppSettings
        {
            IntervalMs = 5000,
            OverlayOpacityPercent = 5,
            LeftHotkey = HotkeyBinding.FromKey(Keys.F12),
            RightHotkey = HotkeyBinding.FromKey(Keys.F12),
            PanicHotkey = HotkeyBinding.FromKey(Keys.F12)
        };
        settings.Normalize();
        Assert(settings.SchemaVersion == 3, "Настройки должны обновляться до схемы 3.");
        Assert(settings.IntervalMs == 1000, "Интервал должен ограничиваться 1000 мс.");
        Assert(settings.OverlayOpacityPercent == 35, "Оверлей не должен становиться полностью невидимым.");
        Assert(!settings.PanicHotkey.IsDisabled, "Panic Key нельзя отключить.");
        Assert(!settings.LeftHotkey.Equals(settings.PanicHotkey), "LMB не должен конфликтовать с Panic.");
        Assert(!settings.RightHotkey.Equals(settings.PanicHotkey), "RMB не должен конфликтовать с Panic.");
        Assert(!settings.LeftHotkey.Equals(settings.RightHotkey), "LMB и RMB должны иметь разные хоткеи.");
    }

    private static void Assert(bool condition, string message)
    {
        if (!condition) throw new InvalidOperationException(message);
    }
}
