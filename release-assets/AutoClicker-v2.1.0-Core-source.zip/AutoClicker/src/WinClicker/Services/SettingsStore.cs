using System.Text.Json;
using WinClicker.Models;

namespace WinClicker.Services;

internal sealed class SettingsStore
{
    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        WriteIndented = true,
        PropertyNameCaseInsensitive = true
    };

    private readonly string _settingsPath;
    private readonly string _legacySettingsPath;

    internal SettingsStore()
    {
        var localAppData = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
        _settingsPath = Path.Combine(localAppData, "AutoClicker", "settings.json");
        _legacySettingsPath = Path.Combine(localAppData, "WinClicker", "settings.json");
    }

    internal AppSettings Load()
    {
        try
        {
            var sourcePath = File.Exists(_settingsPath)
                ? _settingsPath
                : File.Exists(_legacySettingsPath)
                    ? _legacySettingsPath
                    : null;
            if (sourcePath is null)
            {
                return new AppSettings();
            }

            var json = File.ReadAllText(sourcePath);
            var settings = JsonSerializer.Deserialize<AppSettings>(json, JsonOptions) ?? new AppSettings();
            using var document = JsonDocument.Parse(json);
            MigrateV2(document.RootElement, settings);
            settings.Normalize();
            return settings;
        }
        catch (JsonException)
        {
            return new AppSettings();
        }
        catch (IOException)
        {
            return new AppSettings();
        }
        catch (UnauthorizedAccessException)
        {
            return new AppSettings();
        }
    }

    internal bool Save(AppSettings settings)
    {
        try
        {
            settings.Normalize();
            var directory = Path.GetDirectoryName(_settingsPath)!;
            Directory.CreateDirectory(directory);
            var temporaryPath = _settingsPath + ".tmp";
            File.WriteAllText(temporaryPath, JsonSerializer.Serialize(settings, JsonOptions));
            File.Move(temporaryPath, _settingsPath, true);
            return true;
        }
        catch (IOException)
        {
            return false;
        }
        catch (UnauthorizedAccessException)
        {
            return false;
        }
    }

    private static void MigrateV2(JsonElement root, AppSettings settings)
    {
        TryGetInt(root, "SchemaVersion", out var schemaVersion);
        if (schemaVersion >= 3)
        {
            return;
        }

        if (root.TryGetProperty("ToggleHotkey", out var leftElement))
        {
            settings.LeftHotkey = leftElement.Deserialize<HotkeyBinding>(JsonOptions) ?? settings.LeftHotkey;
        }

        if (root.TryGetProperty("SwitchButtonHotkey", out var rightElement))
        {
            settings.RightHotkey = rightElement.Deserialize<HotkeyBinding>(JsonOptions) ?? settings.RightHotkey;
        }

        if (TryGetInt(root, "ToggleHotkeyMode", out var leftMode)
            && Enum.IsDefined((HotkeyTriggerMode)leftMode))
        {
            settings.LeftHotkeyMode = (HotkeyTriggerMode)leftMode;
        }

        if (TryGetInt(root, "SwitchButtonHotkeyMode", out var rightMode)
            && Enum.IsDefined((HotkeyTriggerMode)rightMode))
        {
            settings.RightHotkeyMode = (HotkeyTriggerMode)rightMode;
        }
    }

    private static bool TryGetInt(JsonElement root, string propertyName, out int value)
    {
        value = 0;
        return root.TryGetProperty(propertyName, out var element) && element.TryGetInt32(out value);
    }
}
