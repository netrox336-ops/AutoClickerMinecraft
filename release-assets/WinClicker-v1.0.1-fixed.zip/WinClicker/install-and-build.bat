@echo off
setlocal
title WinClicker Setup

set "PROJECT_DIR=%~dp0"
set "BUILD_SCRIPT=%PROJECT_DIR%scripts\setup-and-build.ps1"

if exist "%BUILD_SCRIPT%" goto run_build

echo.
echo [ERROR] Required build files were not found.
echo.
echo Do not run this BAT directly from inside the ZIP archive.
echo First click "Extract all", then open the extracted WinClicker folder.
echo.
echo Missing file:
echo "%BUILD_SCRIPT%"
echo.
pause
exit /b 2

:run_build
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%BUILD_SCRIPT%"
set "BUILD_EXIT_CODE=%ERRORLEVEL%"
if "%BUILD_EXIT_CODE%"=="0" goto build_ok

echo.
echo [ERROR] WinClicker build failed. See the message above.
pause
exit /b %BUILD_EXIT_CODE%

:build_ok
echo.
echo WinClicker was built and started successfully.
echo Press any key to close this window.
pause >nul
exit /b 0
