using System.Diagnostics;
using WinClicker.Models;
using WinClicker.Services;

namespace WinClicker.UI;

internal sealed class MainForm : Form
{
    private static readonly Color Background = Color.FromArgb(11, 18, 32);
    private static readonly Color Card = Color.FromArgb(24, 34, 52);
    private static readonly Color CardLight = Color.FromArgb(34, 46, 67);
    private static readonly Color TextPrimary = Color.FromArgb(243, 244, 246);
    private static readonly Color TextMuted = Color.FromArgb(156, 163, 175);
    private static readonly Color Accent = Color.FromArgb(59, 130, 246);
    private static readonly Color Running = Color.FromArgb(34, 197, 94);
    private static readonly Color Stopped = Color.FromArgb(239, 68, 68);
    private static readonly Color Ultra = Color.FromArgb(249, 115, 22);
    private static readonly int[] UltraBatchValues = { 1, 4, 8, 16, 32 };

    private readonly SettingsStore _settingsStore = new();
    private readonly ClickEngine _clickEngine = new();
    private readonly AppSettings _settings;
    private readonly Label _statusLabel;
    private readonly Label _modeLabel;
    private readonly Label _speedLabel;
    private readonly Label _clickCountLabel;
    private readonly Label _toggleHotkeyLabel;
    private readonly Label _switchHotkeyLabel;
    private readonly Label _ultraHotkeyLabel;
    private readonly NumericUpDown _intervalInput;
    private readonly RadioButton _leftButton;
    private readonly RadioButton _rightButton;
    private readonly ComboBox _patternInput;
    private readonly CheckBox _ultraToggle;
    private readonly ComboBox _ultraBatchInput;
    private readonly NumericUpDown _startDelayInput;
    private readonly NumericUpDown _clickLimitInput;
    private readonly CheckBox _ignoreExtraModifiers;
    private readonly CheckBox _suppressHotkeys;
    private readonly CheckBox _minimizeToTray;
    private readonly Button _startStopButton;
    private readonly NotifyIcon _trayIcon;
    private readonly System.Windows.Forms.Timer _statsTimer;
    private GlobalInputHook? _inputHook;
    private bool _loading = true;
    private bool _closing;
    private bool _trayHintShown;
    private long _lastClicks;
    private long _lastStatsTimestamp;

    internal MainForm()
    {
        _settings = _settingsStore.Load();

        Text = "WinClicker Ultra";
        ClientSize = new Size(640, 700);
        StartPosition = FormStartPosition.CenterScreen;
        FormBorderStyle = FormBorderStyle.FixedSingle;
        MaximizeBox = false;
        BackColor = Background;
        ForeColor = TextPrimary;
        Font = new Font("Segoe UI", 10F);
        AutoScaleMode = AutoScaleMode.Dpi;

        var title = new Label
        {
            Text = "WinClicker Ultra",
            Font = new Font("Segoe UI Semibold", 22F),
            AutoSize = true,
            Location = new Point(24, 13),
            ForeColor = TextPrimary
        };
        var subtitle = new Label
        {
            Text = "Глобальный high-speed автокликер для Windows 11",
            Font = new Font("Segoe UI", 9.5F),
            AutoSize = true,
            Location = new Point(27, 52),
            ForeColor = TextMuted
        };

        var statusCard = CreateCard(new Point(20, 82), new Size(600, 108));
        _statusLabel = CreateLabel("●  ОСТАНОВЛЕН", new Point(20, 13), new Size(260, 30), 15F, Stopped, true);
        _modeLabel = CreateLabel("ЛЕВАЯ • SINGLE • 50 мс", new Point(22, 48), new Size(355, 24), 9.5F, TextMuted);
        _speedLabel = CreateLabel("0 кликов/с", new Point(22, 75), new Size(170, 22), 9F, TextMuted);
        _clickCountLabel = CreateLabel("Сессия: 0", new Point(190, 75), new Size(185, 22), 9F, TextMuted);
        _startStopButton = CreateButton("Запустить", new Point(414, 23), new Size(162, 62), Accent, 12F);
        _startStopButton.Click += (_, _) => ToggleClicking();
        statusCard.Controls.AddRange(new Control[]
        {
            _statusLabel, _modeLabel, _speedLabel, _clickCountLabel, _startStopButton
        });

        var tabs = new TabControl
        {
            Location = new Point(20, 202),
            Size = new Size(600, 414),
            Font = new Font("Segoe UI Semibold", 10F),
            Padding = new Point(18, 7)
        };

        var clickerTab = CreateTabPage("Кликер");
        clickerTab.Controls.Add(CreateSectionTitle("ОСНОВНЫЕ ПАРАМЕТРЫ", new Point(18, 17)));
        clickerTab.Controls.Add(CreateLabel("Интервал", new Point(20, 54), new Size(90, 28), 10F, TextPrimary));
        _intervalInput = CreateNumericInput(new Point(112, 52), new Size(105, 31), 1, 1000);
        _intervalInput.ValueChanged += (_, _) => ClickSettingsChanged();
        clickerTab.Controls.Add(_intervalInput);
        clickerTab.Controls.Add(CreateLabel("мс", new Point(224, 54), new Size(35, 28), 10F, TextMuted));

        clickerTab.Controls.Add(CreateLabel("Кнопка", new Point(315, 54), new Size(80, 28), 10F, TextPrimary));
        _leftButton = CreateRadioButton("Левая", new Point(394, 53));
        _rightButton = CreateRadioButton("Правая", new Point(481, 53));
        _leftButton.CheckedChanged += (_, _) => ClickSettingsChanged();
        _rightButton.CheckedChanged += (_, _) => ClickSettingsChanged();
        clickerTab.Controls.AddRange(new Control[] { _leftButton, _rightButton });

        clickerTab.Controls.Add(CreateLabel("Режим клика", new Point(20, 103), new Size(110, 28), 10F, TextPrimary));
        _patternInput = CreateComboBox(new Point(132, 101), new Size(145, 31));
        _patternInput.Items.AddRange(new object[] { "Single click", "Double click", "Triple click" });
        _patternInput.SelectedIndexChanged += (_, _) => ClickSettingsChanged();
        clickerTab.Controls.Add(_patternInput);

        _ultraToggle = CreateCheckBox(
            "ULTRA MODE — без задержки (<1 мс)",
            new Point(20, 151),
            new Size(315, 31));
        _ultraToggle.Font = new Font("Segoe UI Semibold", 10.5F);
        _ultraToggle.ForeColor = Ultra;
        _ultraToggle.CheckedChanged += (_, _) => ClickSettingsChanged();
        clickerTab.Controls.Add(_ultraToggle);

        clickerTab.Controls.Add(CreateLabel("Мощность", new Point(361, 152), new Size(90, 28), 10F, TextPrimary));
        _ultraBatchInput = CreateComboBox(new Point(454, 150), new Size(105, 31));
        _ultraBatchInput.Items.AddRange(new object[] { "×1", "×4", "×8", "×16", "×32 MAX" });
        _ultraBatchInput.SelectedIndexChanged += (_, _) => ClickSettingsChanged();
        clickerTab.Controls.Add(_ultraBatchInput);

        var separator = new Panel
        {
            Location = new Point(20, 201),
            Size = new Size(540, 1),
            BackColor = CardLight
        };
        clickerTab.Controls.Add(separator);
        clickerTab.Controls.Add(CreateSectionTitle("ДОПОЛНИТЕЛЬНО", new Point(18, 216)));

        clickerTab.Controls.Add(CreateLabel("Задержка старта", new Point(20, 253), new Size(125, 28), 10F, TextPrimary));
        _startDelayInput = CreateNumericInput(new Point(147, 251), new Size(105, 31), 0, 5000);
        _startDelayInput.ValueChanged += (_, _) => ClickSettingsChanged();
        clickerTab.Controls.Add(_startDelayInput);
        clickerTab.Controls.Add(CreateLabel("мс", new Point(258, 253), new Size(34, 28), 10F, TextMuted));

        clickerTab.Controls.Add(CreateLabel("Лимит кликов", new Point(315, 253), new Size(110, 28), 10F, TextPrimary));
        _clickLimitInput = CreateNumericInput(new Point(428, 251), new Size(132, 31), 0, 1_000_000);
        _clickLimitInput.Increment = 100;
        _clickLimitInput.ThousandsSeparator = true;
        _clickLimitInput.ValueChanged += (_, _) => ClickSettingsChanged();
        clickerTab.Controls.Add(_clickLimitInput);

        var clickerHint = CreateLabel(
            "Лимит 0 = без ограничений. Ultra отправляет заранее собранные пакеты ввода; ×32 — максимальная скорость.",
            new Point(20, 303),
            new Size(540, 45),
            8.8F,
            TextMuted);
        clickerHint.AutoEllipsis = false;
        clickerTab.Controls.Add(clickerHint);

        var hotkeysTab = CreateTabPage("Хоткеи");
        hotkeysTab.Controls.Add(CreateSectionTitle("КЛАВИАТУРА И КНОПКИ МЫШИ", new Point(18, 17)));
        hotkeysTab.Controls.Add(CreateLabel("Включить / выключить", new Point(20, 55), new Size(180, 32), 10F, TextPrimary));
        _toggleHotkeyLabel = CreateHotkeyValue(new Point(205, 54));
        var editToggleButton = CreateButton("Изменить", new Point(447, 53), new Size(112, 34), CardLight, 9.5F);
        editToggleButton.Click += (_, _) => EditHotkey(HotkeyAction.ToggleClicker);
        hotkeysTab.Controls.AddRange(new Control[] { _toggleHotkeyLabel, editToggleButton });

        hotkeysTab.Controls.Add(CreateLabel("Левая / правая", new Point(20, 103), new Size(180, 32), 10F, TextPrimary));
        _switchHotkeyLabel = CreateHotkeyValue(new Point(205, 102));
        var editSwitchButton = CreateButton("Изменить", new Point(447, 101), new Size(112, 34), CardLight, 9.5F);
        editSwitchButton.Click += (_, _) => EditHotkey(HotkeyAction.SwitchButton);
        hotkeysTab.Controls.AddRange(new Control[] { _switchHotkeyLabel, editSwitchButton });

        hotkeysTab.Controls.Add(CreateLabel("Включить Ultra", new Point(20, 151), new Size(180, 32), 10F, TextPrimary));
        _ultraHotkeyLabel = CreateHotkeyValue(new Point(205, 150));
        var editUltraButton = CreateButton("Изменить", new Point(447, 149), new Size(112, 34), CardLight, 9.5F);
        editUltraButton.Click += (_, _) => EditHotkey(HotkeyAction.ToggleUltraMode);
        hotkeysTab.Controls.AddRange(new Control[] { _ultraHotkeyLabel, editUltraButton });

        var mouseHint = CreateLabel(
            "При назначении просто нажмите Mouse 3, Mouse 4 или Mouse 5. Поддерживаются сочетания, например Ctrl + Mouse 4.",
            new Point(20, 199),
            new Size(540, 44),
            8.8F,
            TextMuted);
        hotkeysTab.Controls.Add(mouseHint);

        _ignoreExtraModifiers = CreateCheckBox(
            "Разрешать хоткей при других зажатых клавишах",
            new Point(20, 252),
            new Size(370, 28));
        _ignoreExtraModifiers.CheckedChanged += (_, _) => HookOptionChanged();
        _suppressHotkeys = CreateCheckBox(
            "Не передавать клавишу или кнопку хоткея в игру",
            new Point(20, 291),
            new Size(390, 28));
        _suppressHotkeys.CheckedChanged += (_, _) => HookOptionChanged();
        hotkeysTab.Controls.AddRange(new Control[] { _ignoreExtraModifiers, _suppressHotkeys });

        tabs.TabPages.Add(clickerTab);
        tabs.TabPages.Add(hotkeysTab);

        _minimizeToTray = CreateCheckBox(
            "Сворачивать в системный трей",
            new Point(25, 627),
            new Size(285, 27));
        _minimizeToTray.CheckedChanged += (_, _) => MinimizeOptionChanged();
        var footer = new Label
        {
            Text = "WinClicker Ultra 1.1.0  •  настройки сохраняются автоматически",
            AutoSize = true,
            Location = new Point(26, 666),
            ForeColor = TextMuted,
            Font = new Font("Segoe UI", 8.5F)
        };

        Controls.AddRange(new Control[] { title, subtitle, statusCard, tabs, _minimizeToTray, footer });

        var trayMenu = new ContextMenuStrip();
        trayMenu.Items.Add("Показать", null, (_, _) => RestoreFromTray());
        trayMenu.Items.Add("Включить / выключить", null, (_, _) => ToggleClicking());
        trayMenu.Items.Add("Переключить Ultra", null, (_, _) => ToggleUltraMode());
        trayMenu.Items.Add(new ToolStripSeparator());
        trayMenu.Items.Add("Выход", null, (_, _) => Close());
        _trayIcon = new NotifyIcon
        {
            Text = "WinClicker Ultra",
            Icon = SystemIcons.Application,
            Visible = false,
            ContextMenuStrip = trayMenu
        };
        _trayIcon.DoubleClick += (_, _) => RestoreFromTray();

        _statsTimer = new System.Windows.Forms.Timer { Interval = 250 };
        _statsTimer.Tick += (_, _) => UpdateStatistics();
        _lastStatsTimestamp = Stopwatch.GetTimestamp();

        ApplySettingsToInterface();
        _clickEngine.ApplySettings(_settings);
        _loading = false;
        UpdateModeLabel();
        UpdateStatus();
        UpdateSettingsAvailability();
        _statsTimer.Start();

        Shown += (_, _) => InstallInputHook();
        Resize += (_, _) => MinimizeIfNeeded();
        FormClosing += MainFormClosing;
        MinimumSize = MaximumSize = Size;
    }

    private void InstallInputHook()
    {
        try
        {
            _inputHook = new GlobalInputHook();
            _inputHook.UpdateConfiguration(_settings);
            _inputHook.HotkeyPressed += InputHookOnHotkeyPressed;
            _inputHook.Start();
        }
        catch (Exception exception)
        {
            _inputHook?.Dispose();
            _inputHook = null;
            MessageBox.Show(
                this,
                $"Глобальные хоткеи не запущены. Кнопки в окне продолжат работать.\n\n{exception.Message}",
                "WinClicker Ultra",
                MessageBoxButtons.OK,
                MessageBoxIcon.Warning);
        }
    }

    private void ApplySettingsToInterface()
    {
        _settings.Normalize();
        _intervalInput.Value = _settings.IntervalMs;
        _leftButton.Checked = _settings.ClickButton == ClickButton.Left;
        _rightButton.Checked = _settings.ClickButton == ClickButton.Right;
        _patternInput.SelectedIndex = Math.Clamp((int)_settings.Pattern - 1, 0, 2);
        _ultraToggle.Checked = _settings.UltraMode;
        var batchIndex = Array.IndexOf(UltraBatchValues, _settings.UltraBatchSize);
        _ultraBatchInput.SelectedIndex = Math.Max(0, batchIndex);
        _startDelayInput.Value = _settings.StartDelayMs;
        _clickLimitInput.Value = _settings.ClickLimit;
        _ignoreExtraModifiers.Checked = _settings.IgnoreExtraModifiers;
        _suppressHotkeys.Checked = _settings.SuppressHotkeys;
        _minimizeToTray.Checked = _settings.MinimizeToTray;
        UpdateHotkeyLabels();
    }

    private void ToggleClicking()
    {
        if (_clickEngine.IsRunning)
        {
            _clickEngine.Stop();
        }
        else
        {
            _clickEngine.Start(_settings);
            _lastClicks = 0;
            _lastStatsTimestamp = Stopwatch.GetTimestamp();
        }

        UpdateStatus();
    }

    private void SwitchMouseButton()
    {
        _settings.ClickButton = _settings.ClickButton == ClickButton.Left
            ? ClickButton.Right
            : ClickButton.Left;
        _loading = true;
        _leftButton.Checked = _settings.ClickButton == ClickButton.Left;
        _rightButton.Checked = _settings.ClickButton == ClickButton.Right;
        _loading = false;
        ApplyEngineSettings();
    }

    private void ToggleUltraMode()
    {
        _settings.UltraMode = !_settings.UltraMode;
        _loading = true;
        _ultraToggle.Checked = _settings.UltraMode;
        _loading = false;
        ApplyEngineSettings();
    }

    private void InputHookOnHotkeyPressed(object? sender, HotkeyAction action)
    {
        if (_closing || !IsHandleCreated)
        {
            return;
        }

        try
        {
            BeginInvoke(new Action(() =>
            {
                if (_closing)
                {
                    return;
                }

                switch (action)
                {
                    case HotkeyAction.ToggleClicker:
                        ToggleClicking();
                        break;
                    case HotkeyAction.SwitchButton:
                        SwitchMouseButton();
                        break;
                    case HotkeyAction.ToggleUltraMode:
                        ToggleUltraMode();
                        break;
                }
            }));
        }
        catch (InvalidOperationException)
        {
            // Окно уже завершает работу.
        }
    }

    private void ClickSettingsChanged()
    {
        if (_loading)
        {
            return;
        }

        _settings.IntervalMs = (int)_intervalInput.Value;
        _settings.ClickButton = _rightButton.Checked ? ClickButton.Right : ClickButton.Left;
        _settings.Pattern = (ClickPattern)Math.Clamp(_patternInput.SelectedIndex + 1, 1, 3);
        _settings.UltraMode = _ultraToggle.Checked;
        if (_ultraBatchInput.SelectedIndex >= 0)
        {
            _settings.UltraBatchSize = UltraBatchValues[_ultraBatchInput.SelectedIndex];
        }

        _settings.StartDelayMs = (int)_startDelayInput.Value;
        _settings.ClickLimit = (int)_clickLimitInput.Value;
        ApplyEngineSettings();
    }

    private void ApplyEngineSettings()
    {
        _clickEngine.ApplySettings(_settings);
        UpdateModeLabel();
        UpdateSettingsAvailability();
        SaveSettings();
    }

    private void HookOptionChanged()
    {
        if (_loading)
        {
            return;
        }

        _settings.IgnoreExtraModifiers = _ignoreExtraModifiers.Checked;
        _settings.SuppressHotkeys = _suppressHotkeys.Checked;
        UpdateHookConfiguration();
        SaveSettings();
    }

    private void MinimizeOptionChanged()
    {
        if (_loading)
        {
            return;
        }

        _settings.MinimizeToTray = _minimizeToTray.Checked;
        SaveSettings();
    }

    private void EditHotkey(HotkeyAction action)
    {
        var current = GetHotkey(action);
        var actionName = action switch
        {
            HotkeyAction.ToggleClicker => "Включить / выключить кликер",
            HotkeyAction.SwitchButton => "Сменить левую / правую кнопку",
            _ => "Включить / выключить Ultra Mode"
        };

        if (_inputHook is not null)
        {
            _inputHook.Suspended = true;
        }

        using var dialog = new HotkeyCaptureDialog(actionName, current);
        EventHandler<HotkeyBinding>? mouseCaptureHandler = null;
        if (_inputHook is not null)
        {
            mouseCaptureHandler = (_, binding) => dialog.AcceptBinding(binding);
            _inputHook.MouseBindingCaptured += mouseCaptureHandler;
        }

        try
        {
            if (dialog.ShowDialog(this) != DialogResult.OK)
            {
                return;
            }

            var candidate = dialog.SelectedHotkey;
            if (!candidate.IsDisabled && IsUsedByOtherAction(action, candidate))
            {
                MessageBox.Show(
                    this,
                    "Эта комбинация уже назначена другому действию.",
                    "WinClicker Ultra",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
                return;
            }

            SetHotkey(action, candidate);
            UpdateHotkeyLabels();
            UpdateHookConfiguration();
            SaveSettings();
        }
        finally
        {
            if (_inputHook is not null)
            {
                if (mouseCaptureHandler is not null)
                {
                    _inputHook.MouseBindingCaptured -= mouseCaptureHandler;
                }

                _inputHook.Suspended = false;
            }
        }
    }

    private HotkeyBinding GetHotkey(HotkeyAction action)
    {
        return action switch
        {
            HotkeyAction.ToggleClicker => _settings.ToggleHotkey,
            HotkeyAction.SwitchButton => _settings.SwitchButtonHotkey,
            _ => _settings.UltraHotkey
        };
    }

    private void SetHotkey(HotkeyAction action, HotkeyBinding binding)
    {
        switch (action)
        {
            case HotkeyAction.ToggleClicker:
                _settings.ToggleHotkey = binding;
                break;
            case HotkeyAction.SwitchButton:
                _settings.SwitchButtonHotkey = binding;
                break;
            case HotkeyAction.ToggleUltraMode:
                _settings.UltraHotkey = binding;
                break;
        }
    }

    private bool IsUsedByOtherAction(HotkeyAction currentAction, HotkeyBinding candidate)
    {
        foreach (var action in Enum.GetValues<HotkeyAction>())
        {
            if (action != currentAction && candidate.Equals(GetHotkey(action)))
            {
                return true;
            }
        }

        return false;
    }

    private void UpdateHookConfiguration()
    {
        _inputHook?.UpdateConfiguration(_settings);
    }

    private void UpdateStatistics()
    {
        var now = Stopwatch.GetTimestamp();
        var elapsedSeconds = (now - _lastStatsTimestamp) / (double)Stopwatch.Frequency;
        var clicks = _clickEngine.SessionClicks;
        var difference = Math.Max(0, clicks - _lastClicks);
        var clicksPerSecond = _clickEngine.IsRunning && elapsedSeconds > 0
            ? difference / elapsedSeconds
            : 0;

        _speedLabel.Text = $"{clicksPerSecond:N0} кликов/с";
        _clickCountLabel.Text = $"Сессия: {clicks:N0}";
        _lastClicks = clicks;
        _lastStatsTimestamp = now;
        UpdateStatus();
    }

    private void UpdateStatus()
    {
        var running = _clickEngine.IsRunning;
        _statusLabel.Text = running ? "●  РАБОТАЕТ" : "●  ОСТАНОВЛЕН";
        _statusLabel.ForeColor = running ? Running : Stopped;
        _startStopButton.Text = running ? "Остановить" : "Запустить";
        _startStopButton.BackColor = running ? Stopped : Accent;
        _trayIcon.Text = running ? "WinClicker Ultra — работает" : "WinClicker Ultra — остановлен";
    }

    private void UpdateModeLabel()
    {
        var button = _settings.ClickButton == ClickButton.Left ? "ЛЕВАЯ" : "ПРАВАЯ";
        var pattern = _settings.Pattern switch
        {
            ClickPattern.Double => "DOUBLE",
            ClickPattern.Triple => "TRIPLE",
            _ => "SINGLE"
        };
        _modeLabel.Text = _settings.UltraMode
            ? $"{button} • {pattern} • ULTRA ×{_settings.UltraBatchSize}"
            : $"{button} • {pattern} • {_settings.IntervalMs} мс";
        _modeLabel.ForeColor = _settings.UltraMode ? Ultra : TextMuted;
    }

    private void UpdateSettingsAvailability()
    {
        _intervalInput.Enabled = !_settings.UltraMode;
        _ultraBatchInput.Enabled = _settings.UltraMode;
    }

    private void UpdateHotkeyLabels()
    {
        _toggleHotkeyLabel.Text = _settings.ToggleHotkey.ToDisplayString();
        _switchHotkeyLabel.Text = _settings.SwitchButtonHotkey.ToDisplayString();
        _ultraHotkeyLabel.Text = _settings.UltraHotkey.ToDisplayString();
    }

    private void MinimizeIfNeeded()
    {
        if (_closing || WindowState != FormWindowState.Minimized || !_settings.MinimizeToTray)
        {
            return;
        }

        Hide();
        _trayIcon.Visible = true;
        if (!_trayHintShown)
        {
            _trayHintShown = true;
            _trayIcon.ShowBalloonTip(1800, "WinClicker Ultra", "Приложение продолжает работать в трее.", ToolTipIcon.Info);
        }
    }

    private void RestoreFromTray()
    {
        Show();
        WindowState = FormWindowState.Normal;
        Activate();
        _trayIcon.Visible = false;
    }

    private void MainFormClosing(object? sender, FormClosingEventArgs e)
    {
        _closing = true;
        _statsTimer.Stop();
        _statsTimer.Dispose();
        _clickEngine.Dispose();
        _inputHook?.Dispose();
        _trayIcon.Visible = false;
        _trayIcon.Dispose();
        SaveSettings();
    }

    private void SaveSettings()
    {
        _settingsStore.Save(_settings);
    }

    private static TabPage CreateTabPage(string text)
    {
        return new TabPage
        {
            Text = text,
            BackColor = Card,
            ForeColor = TextPrimary,
            UseVisualStyleBackColor = false
        };
    }

    private static Panel CreateCard(Point location, Size size)
    {
        return new Panel
        {
            Location = location,
            Size = size,
            BackColor = Card
        };
    }

    private static Label CreateSectionTitle(string text, Point location)
    {
        return CreateLabel(text, location, new Size(300, 24), 9F, Accent, true);
    }

    private static Label CreateLabel(string text, Point location, Size size, float fontSize, Color color, bool semibold = false)
    {
        return new Label
        {
            Text = text,
            Location = location,
            Size = size,
            ForeColor = color,
            Font = new Font(semibold ? "Segoe UI Semibold" : "Segoe UI", fontSize),
            TextAlign = ContentAlignment.MiddleLeft
        };
    }

    private static Label CreateHotkeyValue(Point location)
    {
        return new Label
        {
            Location = location,
            Size = new Size(225, 34),
            BackColor = CardLight,
            ForeColor = TextPrimary,
            Font = new Font("Segoe UI Semibold", 9.5F),
            TextAlign = ContentAlignment.MiddleCenter,
            AutoEllipsis = true
        };
    }

    private static Button CreateButton(string text, Point location, Size size, Color color, float fontSize)
    {
        return new Button
        {
            Text = text,
            Location = location,
            Size = size,
            BackColor = color,
            ForeColor = TextPrimary,
            Font = new Font("Segoe UI Semibold", fontSize),
            FlatStyle = FlatStyle.Flat,
            Cursor = Cursors.Hand,
            FlatAppearance = { BorderSize = 0 }
        };
    }

    private static NumericUpDown CreateNumericInput(Point location, Size size, decimal minimum, decimal maximum)
    {
        return new NumericUpDown
        {
            Location = location,
            Size = size,
            Minimum = minimum,
            Maximum = maximum,
            Increment = 1,
            BackColor = CardLight,
            ForeColor = TextPrimary,
            BorderStyle = BorderStyle.FixedSingle,
            TextAlign = HorizontalAlignment.Center,
            Font = new Font("Segoe UI Semibold", 10F)
        };
    }

    private static ComboBox CreateComboBox(Point location, Size size)
    {
        return new ComboBox
        {
            Location = location,
            Size = size,
            DropDownStyle = ComboBoxStyle.DropDownList,
            BackColor = CardLight,
            ForeColor = TextPrimary,
            FlatStyle = FlatStyle.Flat,
            Font = new Font("Segoe UI Semibold", 9.5F)
        };
    }

    private static RadioButton CreateRadioButton(string text, Point location)
    {
        return new RadioButton
        {
            Text = text,
            Location = location,
            Size = new Size(88, 28),
            ForeColor = TextPrimary,
            BackColor = Card,
            Cursor = Cursors.Hand
        };
    }

    private static CheckBox CreateCheckBox(string text, Point location, Size size)
    {
        return new CheckBox
        {
            Text = text,
            Location = location,
            Size = size,
            ForeColor = TextMuted,
            BackColor = Color.Transparent,
            Cursor = Cursors.Hand
        };
    }
}
