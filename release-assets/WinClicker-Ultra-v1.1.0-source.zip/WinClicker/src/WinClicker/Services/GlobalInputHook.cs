using System.ComponentModel;
using System.Runtime.InteropServices;
using WinClicker.Models;

namespace WinClicker.Services;

internal enum HotkeyAction
{
    ToggleClicker,
    SwitchButton,
    ToggleUltraMode
}

internal sealed record HookConfiguration(
    HotkeyBinding Toggle,
    HotkeyBinding SwitchButton,
    HotkeyBinding Ultra,
    bool IgnoreExtraModifiers,
    bool SuppressHotkeys);

internal sealed class GlobalInputHook : IDisposable
{
    private readonly NativeMethods.LowLevelKeyboardProc _keyboardCallback;
    private readonly NativeMethods.LowLevelMouseProc _mouseCallback;
    private readonly HashSet<int> _pressedKeys = new();
    private readonly HashSet<int> _suppressedKeys = new();
    private readonly HashSet<HotkeyMouseButton> _pressedMouseButtons = new();
    private readonly HashSet<HotkeyMouseButton> _suppressedMouseButtons = new();
    private readonly HashSet<HotkeyMouseButton> _captureSuppressedMouseButtons = new();
    private IntPtr _keyboardHookHandle;
    private IntPtr _mouseHookHandle;
    private HookConfiguration _configuration = new(
        HotkeyBinding.Disabled(),
        HotkeyBinding.Disabled(),
        HotkeyBinding.Disabled(),
        true,
        false);
    private bool _suspended;
    private bool _disposed;

    internal GlobalInputHook()
    {
        _keyboardCallback = KeyboardHookCallback;
        _mouseCallback = MouseHookCallback;
    }

    internal event EventHandler<HotkeyAction>? HotkeyPressed;
    internal event EventHandler<HotkeyBinding>? MouseBindingCaptured;

    internal bool Suspended
    {
        get => _suspended;
        set
        {
            _suspended = value;
            _pressedKeys.Clear();
            _suppressedKeys.Clear();
            _pressedMouseButtons.Clear();
            _suppressedMouseButtons.Clear();
        }
    }

    internal void Start()
    {
        ObjectDisposedException.ThrowIf(_disposed, this);
        if (_keyboardHookHandle != IntPtr.Zero || _mouseHookHandle != IntPtr.Zero)
        {
            return;
        }

        var moduleHandle = NativeMethods.GetModuleHandle(null);
        _keyboardHookHandle = NativeMethods.SetWindowsKeyboardHookEx(
            NativeMethods.WhKeyboardLl,
            _keyboardCallback,
            moduleHandle,
            0);

        if (_keyboardHookHandle == IntPtr.Zero)
        {
            throw new Win32Exception(Marshal.GetLastWin32Error(), "Не удалось подключить глобальные клавиатурные хоткеи.");
        }

        _mouseHookHandle = NativeMethods.SetWindowsMouseHookEx(
            NativeMethods.WhMouseLl,
            _mouseCallback,
            moduleHandle,
            0);

        if (_mouseHookHandle == IntPtr.Zero)
        {
            var error = Marshal.GetLastWin32Error();
            NativeMethods.UnhookWindowsHookEx(_keyboardHookHandle);
            _keyboardHookHandle = IntPtr.Zero;
            throw new Win32Exception(error, "Не удалось подключить глобальные хоткеи мыши.");
        }
    }

    internal void UpdateConfiguration(AppSettings settings)
    {
        _configuration = new HookConfiguration(
            settings.ToggleHotkey.Clone(),
            settings.SwitchButtonHotkey.Clone(),
            settings.UltraHotkey.Clone(),
            settings.IgnoreExtraModifiers,
            settings.SuppressHotkeys);
    }

    private IntPtr KeyboardHookCallback(int nCode, IntPtr wParam, IntPtr lParam)
    {
        if (nCode < 0)
        {
            return NativeMethods.CallNextHookEx(_keyboardHookHandle, nCode, wParam, lParam);
        }

        var message = unchecked((int)wParam.ToInt64());
        var isKeyDown = message is NativeMethods.WmKeyDown or NativeMethods.WmSysKeyDown;
        var isKeyUp = message is NativeMethods.WmKeyUp or NativeMethods.WmSysKeyUp;
        if (!isKeyDown && !isKeyUp)
        {
            return NativeMethods.CallNextHookEx(_keyboardHookHandle, nCode, wParam, lParam);
        }

        var data = Marshal.PtrToStructure<NativeMethods.KbdLlHookStruct>(lParam);
        var virtualKey = unchecked((int)data.vkCode);

        if (isKeyUp)
        {
            _pressedKeys.Remove(virtualKey);
            if (_suppressedKeys.Remove(virtualKey))
            {
                return new IntPtr(1);
            }

            return NativeMethods.CallNextHookEx(_keyboardHookHandle, nCode, wParam, lParam);
        }

        if (_suspended)
        {
            return NativeMethods.CallNextHookEx(_keyboardHookHandle, nCode, wParam, lParam);
        }

        if (!_pressedKeys.Add(virtualKey))
        {
            return _suppressedKeys.Contains(virtualKey)
                ? new IntPtr(1)
                : NativeMethods.CallNextHookEx(_keyboardHookHandle, nCode, wParam, lParam);
        }

        GetModifiers(out var control, out var alt, out var shift, out var win);
        var action = SelectKeyboardAction(_configuration, virtualKey, control, alt, shift, win);
        if (action is null)
        {
            return NativeMethods.CallNextHookEx(_keyboardHookHandle, nCode, wParam, lParam);
        }

        RaiseHotkey(action.Value);
        if (!_configuration.SuppressHotkeys)
        {
            return NativeMethods.CallNextHookEx(_keyboardHookHandle, nCode, wParam, lParam);
        }

        _suppressedKeys.Add(virtualKey);
        return new IntPtr(1);
    }

    private IntPtr MouseHookCallback(int nCode, IntPtr wParam, IntPtr lParam)
    {
        if (nCode < 0)
        {
            return NativeMethods.CallNextHookEx(_mouseHookHandle, nCode, wParam, lParam);
        }

        var message = unchecked((int)wParam.ToInt64());
        var data = Marshal.PtrToStructure<NativeMethods.MsLlHookStruct>(lParam);
        if ((data.flags & NativeMethods.LlMhfInjected) != 0
            || !TryGetMouseButton(message, data.mouseData, out var button, out var isDown, out var isUp))
        {
            return NativeMethods.CallNextHookEx(_mouseHookHandle, nCode, wParam, lParam);
        }

        if (isUp)
        {
            _pressedMouseButtons.Remove(button);
            if (_captureSuppressedMouseButtons.Remove(button) || _suppressedMouseButtons.Remove(button))
            {
                return new IntPtr(1);
            }

            return NativeMethods.CallNextHookEx(_mouseHookHandle, nCode, wParam, lParam);
        }

        if (!isDown || !_pressedMouseButtons.Add(button))
        {
            return _suppressedMouseButtons.Contains(button)
                ? new IntPtr(1)
                : NativeMethods.CallNextHookEx(_mouseHookHandle, nCode, wParam, lParam);
        }

        GetModifiers(out var control, out var alt, out var shift, out var win);
        if (_suspended)
        {
            _captureSuppressedMouseButtons.Add(button);
            try
            {
                MouseBindingCaptured?.Invoke(
                    this,
                    HotkeyBinding.FromMouse(button, control, alt, shift, win));
            }
            catch
            {
                // Ошибка окна назначения не должна нарушить глобальную цепочку мыши.
            }

            return new IntPtr(1);
        }

        var action = SelectMouseAction(_configuration, button, control, alt, shift, win);
        if (action is null)
        {
            return NativeMethods.CallNextHookEx(_mouseHookHandle, nCode, wParam, lParam);
        }

        RaiseHotkey(action.Value);
        if (!_configuration.SuppressHotkeys)
        {
            return NativeMethods.CallNextHookEx(_mouseHookHandle, nCode, wParam, lParam);
        }

        _suppressedMouseButtons.Add(button);
        return new IntPtr(1);
    }

    private void RaiseHotkey(HotkeyAction action)
    {
        try
        {
            HotkeyPressed?.Invoke(this, action);
        }
        catch
        {
            // Исключение обработчика не должно нарушить глобальную цепочку ввода.
        }
    }

    private static HotkeyAction? SelectKeyboardAction(
        HookConfiguration configuration,
        int virtualKey,
        bool control,
        bool alt,
        bool shift,
        bool win)
    {
        HotkeyAction? bestAction = null;
        var bestModifierCount = -1;
        ConsiderCandidate(
            configuration.Toggle.MatchesKeyboard(
                virtualKey, control, alt, shift, win, configuration.IgnoreExtraModifiers),
            configuration.Toggle,
            HotkeyAction.ToggleClicker,
            ref bestAction,
            ref bestModifierCount);
        ConsiderCandidate(
            configuration.SwitchButton.MatchesKeyboard(
                virtualKey, control, alt, shift, win, configuration.IgnoreExtraModifiers),
            configuration.SwitchButton,
            HotkeyAction.SwitchButton,
            ref bestAction,
            ref bestModifierCount);
        ConsiderCandidate(
            configuration.Ultra.MatchesKeyboard(
                virtualKey, control, alt, shift, win, configuration.IgnoreExtraModifiers),
            configuration.Ultra,
            HotkeyAction.ToggleUltraMode,
            ref bestAction,
            ref bestModifierCount);
        return bestAction;
    }

    private static HotkeyAction? SelectMouseAction(
        HookConfiguration configuration,
        HotkeyMouseButton button,
        bool control,
        bool alt,
        bool shift,
        bool win)
    {
        HotkeyAction? bestAction = null;
        var bestModifierCount = -1;
        ConsiderCandidate(
            configuration.Toggle.MatchesMouse(
                button, control, alt, shift, win, configuration.IgnoreExtraModifiers),
            configuration.Toggle,
            HotkeyAction.ToggleClicker,
            ref bestAction,
            ref bestModifierCount);
        ConsiderCandidate(
            configuration.SwitchButton.MatchesMouse(
                button, control, alt, shift, win, configuration.IgnoreExtraModifiers),
            configuration.SwitchButton,
            HotkeyAction.SwitchButton,
            ref bestAction,
            ref bestModifierCount);
        ConsiderCandidate(
            configuration.Ultra.MatchesMouse(
                button, control, alt, shift, win, configuration.IgnoreExtraModifiers),
            configuration.Ultra,
            HotkeyAction.ToggleUltraMode,
            ref bestAction,
            ref bestModifierCount);
        return bestAction;
    }

    private static void ConsiderCandidate(
        bool matches,
        HotkeyBinding binding,
        HotkeyAction action,
        ref HotkeyAction? bestAction,
        ref int bestModifierCount)
    {
        if (!matches || binding.ModifierCount <= bestModifierCount)
        {
            return;
        }

        bestAction = action;
        bestModifierCount = binding.ModifierCount;
    }

    private static bool TryGetMouseButton(
        int message,
        uint mouseData,
        out HotkeyMouseButton button,
        out bool isDown,
        out bool isUp)
    {
        button = HotkeyMouseButton.None;
        isDown = message is NativeMethods.WmMButtonDown or NativeMethods.WmXButtonDown;
        isUp = message is NativeMethods.WmMButtonUp or NativeMethods.WmXButtonUp;
        if (!isDown && !isUp)
        {
            return false;
        }

        if (message is NativeMethods.WmMButtonDown or NativeMethods.WmMButtonUp)
        {
            button = HotkeyMouseButton.Middle;
            return true;
        }

        var xButton = (mouseData >> 16) & 0xFFFF;
        button = xButton switch
        {
            NativeMethods.XButton1 => HotkeyMouseButton.Mouse4,
            NativeMethods.XButton2 => HotkeyMouseButton.Mouse5,
            _ => HotkeyMouseButton.None
        };
        return button != HotkeyMouseButton.None;
    }

    private static void GetModifiers(out bool control, out bool alt, out bool shift, out bool win)
    {
        control = NativeMethods.IsKeyDown(NativeMethods.VkControl);
        alt = NativeMethods.IsKeyDown(NativeMethods.VkMenu);
        shift = NativeMethods.IsKeyDown(NativeMethods.VkShift);
        win = NativeMethods.IsKeyDown(NativeMethods.VkLWin) || NativeMethods.IsKeyDown(NativeMethods.VkRWin);
    }

    public void Dispose()
    {
        if (_disposed)
        {
            return;
        }

        _disposed = true;
        if (_keyboardHookHandle != IntPtr.Zero)
        {
            NativeMethods.UnhookWindowsHookEx(_keyboardHookHandle);
            _keyboardHookHandle = IntPtr.Zero;
        }

        if (_mouseHookHandle != IntPtr.Zero)
        {
            NativeMethods.UnhookWindowsHookEx(_mouseHookHandle);
            _mouseHookHandle = IntPtr.Zero;
        }

        GC.SuppressFinalize(this);
    }
}
