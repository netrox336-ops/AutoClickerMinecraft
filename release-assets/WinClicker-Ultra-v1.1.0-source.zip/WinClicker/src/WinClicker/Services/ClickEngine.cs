using System.Runtime.InteropServices;
using WinClicker.Models;

namespace WinClicker.Services;

internal sealed class ClickEngine : IDisposable
{
    private readonly object _gate = new();
    private volatile int _intervalMs = 50;
    private volatile int _button = (int)ClickButton.Left;
    private volatile int _pattern = (int)ClickPattern.Single;
    private volatile int _ultraMode;
    private volatile int _ultraBatchSize = 8;
    private volatile int _startDelayMs;
    private volatile int _clickLimit;
    private long _sessionClicks;
    private ManualResetEvent? _stopSignal;
    private Thread? _worker;
    private bool _disposed;

    internal bool IsRunning
    {
        get
        {
            lock (_gate)
            {
                return _worker is { IsAlive: true };
            }
        }
    }

    internal long SessionClicks => Interlocked.Read(ref _sessionClicks);

    internal void Start(AppSettings settings)
    {
        ObjectDisposedException.ThrowIf(_disposed, this);
        ApplySettings(settings);
        lock (_gate)
        {
            if (_worker is { IsAlive: true })
            {
                return;
            }

            _stopSignal?.Dispose();
            _stopSignal = null;
            _worker = null;
            Interlocked.Exchange(ref _sessionClicks, 0);

            var stopSignal = new ManualResetEvent(false);
            _stopSignal = stopSignal;
            _worker = new Thread(() => WorkerLoop(stopSignal))
            {
                IsBackground = true,
                Name = "WinClicker.UltraEngine",
                Priority = ThreadPriority.AboveNormal
            };
            _worker.Start();
        }
    }

    internal void Stop()
    {
        ManualResetEvent? stopSignal;
        Thread? worker;
        lock (_gate)
        {
            stopSignal = _stopSignal;
            worker = _worker;
            if (stopSignal is null || worker is null)
            {
                return;
            }

            stopSignal.Set();
        }

        var stopped = Thread.CurrentThread == worker;
        if (!stopped)
        {
            stopped = worker.Join(TimeSpan.FromSeconds(2));
        }

        if (!stopped)
        {
            return;
        }

        lock (_gate)
        {
            if (ReferenceEquals(_worker, worker))
            {
                _worker = null;
                _stopSignal = null;
                stopSignal.Dispose();
            }
        }
    }

    internal void ApplySettings(AppSettings settings)
    {
        settings.Normalize();
        _intervalMs = settings.IntervalMs;
        _button = (int)settings.ClickButton;
        _pattern = (int)settings.Pattern;
        _ultraMode = settings.UltraMode ? 1 : 0;
        _ultraBatchSize = settings.UltraBatchSize;
        _startDelayMs = settings.StartDelayMs;
        _clickLimit = settings.ClickLimit;
    }

    internal static int CalculateInputEventCount(ClickPattern pattern, int cycles)
    {
        return Math.Clamp((int)pattern, 1, 3) * Math.Max(1, cycles) * 2;
    }

    private void WorkerLoop(ManualResetEvent stopSignal)
    {
        NativeMethods.timeBeginPeriod(1);
        try
        {
            var startDelay = _startDelayMs;
            if (startDelay > 0 && stopSignal.WaitOne(startDelay))
            {
                return;
            }

            var cachedButton = -1;
            var cachedClickCount = -1;
            NativeMethods.Input[]? cachedInputs = null;
            var ultraLoopCount = 0;

            while (!stopSignal.WaitOne(0))
            {
                var button = _button;
                var patternCount = Math.Clamp(_pattern, 1, 3);
                var ultra = _ultraMode != 0;
                var batchSize = ultra ? NormalizeBatchSize(_ultraBatchSize) : 1;
                var requestedClickCount = patternCount * batchSize;
                var limit = _clickLimit;
                if (limit > 0)
                {
                    var remaining = limit - Interlocked.Read(ref _sessionClicks);
                    if (remaining <= 0)
                    {
                        break;
                    }

                    requestedClickCount = (int)Math.Min(requestedClickCount, remaining);
                }

                if (cachedInputs is null
                    || cachedButton != button
                    || cachedClickCount != requestedClickCount)
                {
                    cachedButton = button;
                    cachedClickCount = requestedClickCount;
                    cachedInputs = BuildClickInputs((ClickButton)button, requestedClickCount);
                }

                var sentEvents = NativeMethods.SendInput(
                    (uint)cachedInputs.Length,
                    cachedInputs,
                    Marshal.SizeOf<NativeMethods.Input>());
                var sentClicks = sentEvents / 2;
                if (sentClicks > 0)
                {
                    Interlocked.Add(ref _sessionClicks, sentClicks);
                }
                else
                {
                    Thread.Yield();
                }

                if (!ultra)
                {
                    if (stopSignal.WaitOne(_intervalMs))
                    {
                        break;
                    }

                    continue;
                }

                ultraLoopCount++;
                if ((ultraLoopCount & 15) == 0)
                {
                    Thread.Yield();
                }
            }
        }
        finally
        {
            NativeMethods.timeEndPeriod(1);
        }
    }

    private static NativeMethods.Input[] BuildClickInputs(ClickButton button, int clickCount)
    {
        clickCount = Math.Max(1, clickCount);
        var downFlag = button == ClickButton.Left
            ? NativeMethods.MouseeventfLeftdown
            : NativeMethods.MouseeventfRightdown;
        var upFlag = button == ClickButton.Left
            ? NativeMethods.MouseeventfLeftup
            : NativeMethods.MouseeventfRightup;
        var inputs = new NativeMethods.Input[clickCount * 2];
        for (var index = 0; index < inputs.Length; index += 2)
        {
            inputs[index] = CreateMouseInput(downFlag);
            inputs[index + 1] = CreateMouseInput(upFlag);
        }

        return inputs;
    }

    private static NativeMethods.Input CreateMouseInput(uint flags)
    {
        return new NativeMethods.Input
        {
            type = NativeMethods.InputMouse,
            data = new NativeMethods.InputUnion
            {
                mouse = new NativeMethods.MouseInput
                {
                    dwFlags = flags
                }
            }
        };
    }

    private static int NormalizeBatchSize(int batchSize)
    {
        return batchSize is 1 or 4 or 8 or 16 or 32 ? batchSize : 8;
    }

    public void Dispose()
    {
        if (_disposed)
        {
            return;
        }

        Stop();
        _disposed = true;
        GC.SuppressFinalize(this);
    }
}
