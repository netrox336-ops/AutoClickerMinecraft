using System.Windows.Forms;
using WinClicker.Models;

namespace WinClicker.Services;

internal static class SelfTestRunner
{
    internal static int Run()
    {
        try
        {
            var plainF6 = HotkeyBinding.FromKey(Keys.F6);
            Assert(plainF6.MatchesKeyboard((int)Keys.F6, false, false, true, false, true),
                "F6 должен срабатывать при дополнительно зажатом Shift.");
            Assert(!plainF6.MatchesKeyboard((int)Keys.F6, false, false, true, false, false),
                "F6 не должен срабатывать с лишним Shift в строгом режиме.");

            var ctrlF7 = HotkeyBinding.FromKey(Keys.F7, control: true);
            Assert(!ctrlF7.MatchesKeyboard((int)Keys.F7, false, false, false, false, true),
                "Ctrl+F7 не должен срабатывать без Ctrl.");
            Assert(ctrlF7.MatchesKeyboard((int)Keys.F7, true, false, true, false, true),
                "Ctrl+F7 должен принимать лишний Shift в совместимом режиме.");

            var mouse4 = HotkeyBinding.FromMouse(HotkeyMouseButton.Mouse4);
            Assert(mouse4.MatchesMouse(HotkeyMouseButton.Mouse4, false, false, true, false, true),
                "Mouse 4 должен срабатывать с дополнительно зажатым Shift.");
            Assert(!mouse4.MatchesMouse(HotkeyMouseButton.Mouse5, false, false, false, false, true),
                "Mouse 4 не должен совпадать с Mouse 5.");

            var low = new AppSettings { IntervalMs = 0 };
            low.Normalize();
            Assert(low.IntervalMs == 1, "Нижняя граница интервала должна быть 1 мс.");

            var high = new AppSettings { IntervalMs = 5000 };
            high.Normalize();
            Assert(high.IntervalMs == 1000, "Верхняя граница интервала должна быть 1000 мс.");

            var ultra = new AppSettings { UltraBatchSize = 99, ClickLimit = 2_000_000, StartDelayMs = -1 };
            ultra.Normalize();
            Assert(ultra.UltraBatchSize == 8, "Некорректный Ultra-пакет должен сбрасываться на ×8.");
            Assert(ultra.ClickLimit == 1_000_000, "Лимит кликов должен ограничиваться миллионом.");
            Assert(ultra.StartDelayMs == 0, "Задержка старта не может быть отрицательной.");

            Assert(ClickEngine.CalculateInputEventCount(ClickPattern.Double, 4) == 16,
                "Double ×4 должен создавать 16 INPUT-событий.");
            Assert(ClickEngine.CalculateInputEventCount(ClickPattern.Triple, 32) == 192,
                "Triple ×32 должен создавать 192 INPUT-события.");
            return 0;
        }
        catch
        {
            return 1;
        }
    }

    private static void Assert(bool condition, string message)
    {
        if (!condition)
        {
            throw new InvalidOperationException(message);
        }
    }
}
