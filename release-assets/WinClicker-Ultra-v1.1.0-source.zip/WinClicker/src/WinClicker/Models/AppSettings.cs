using System.Text.Json.Serialization;
using System.Windows.Forms;

namespace WinClicker.Models;

internal enum ClickButton
{
    Left = 0,
    Right = 1
}

internal enum ClickPattern
{
    Single = 1,
    Double = 2,
    Triple = 3
}

internal enum HotkeyMouseButton
{
    None = 0,
    Middle = 1,
    Mouse4 = 2,
    Mouse5 = 3
}

internal sealed class HotkeyBinding : IEquatable<HotkeyBinding>
{
    public int VirtualKey { get; set; }
    public HotkeyMouseButton MouseButton { get; set; }
    public bool Control { get; set; }
    public bool Alt { get; set; }
    public bool Shift { get; set; }
    public bool Win { get; set; }

    [JsonIgnore]
    public bool IsMouse => MouseButton != HotkeyMouseButton.None;

    [JsonIgnore]
    public bool IsDisabled => !IsMouse && VirtualKey <= 0;

    [JsonIgnore]
    public int ModifierCount => (Control ? 1 : 0) + (Alt ? 1 : 0) + (Shift ? 1 : 0) + (Win ? 1 : 0);

    public static HotkeyBinding Disabled() => new();

    public static HotkeyBinding FromKey(Keys key, bool control = false, bool alt = false, bool shift = false, bool win = false)
    {
        return new HotkeyBinding
        {
            VirtualKey = (int)key,
            MouseButton = HotkeyMouseButton.None,
            Control = control,
            Alt = alt,
            Shift = shift,
            Win = win
        };
    }

    public static HotkeyBinding FromMouse(
        HotkeyMouseButton button,
        bool control = false,
        bool alt = false,
        bool shift = false,
        bool win = false)
    {
        return new HotkeyBinding
        {
            VirtualKey = 0,
            MouseButton = button,
            Control = control,
            Alt = alt,
            Shift = shift,
            Win = win
        };
    }

    public HotkeyBinding Clone()
    {
        return new HotkeyBinding
        {
            VirtualKey = VirtualKey,
            MouseButton = MouseButton,
            Control = Control,
            Alt = Alt,
            Shift = Shift,
            Win = Win
        };
    }

    public void Normalize()
    {
        if (MouseButton != HotkeyMouseButton.None)
        {
            if (!Enum.IsDefined(MouseButton))
            {
                Reset();
                return;
            }

            VirtualKey = 0;
            return;
        }

        if (VirtualKey is < 1 or > 255 || IsModifierKey((Keys)VirtualKey))
        {
            Reset();
        }
    }

    public bool MatchesKeyboard(
        int virtualKey,
        bool control,
        bool alt,
        bool shift,
        bool win,
        bool ignoreExtraModifiers)
    {
        return !IsMouse
            && !IsDisabled
            && VirtualKey == virtualKey
            && ModifiersMatch(control, alt, shift, win, ignoreExtraModifiers);
    }

    public bool MatchesMouse(
        HotkeyMouseButton button,
        bool control,
        bool alt,
        bool shift,
        bool win,
        bool ignoreExtraModifiers)
    {
        return IsMouse
            && MouseButton == button
            && ModifiersMatch(control, alt, shift, win, ignoreExtraModifiers);
    }

    public string ToDisplayString()
    {
        if (IsDisabled)
        {
            return "Не назначено";
        }

        var parts = new List<string>(5);
        if (Control) parts.Add("Ctrl");
        if (Alt) parts.Add("Alt");
        if (Shift) parts.Add("Shift");
        if (Win) parts.Add("Win");
        parts.Add(IsMouse ? GetMouseButtonName(MouseButton) : GetKeyName((Keys)VirtualKey));
        return string.Join(" + ", parts);
    }

    public bool Equals(HotkeyBinding? other)
    {
        return other is not null
            && VirtualKey == other.VirtualKey
            && MouseButton == other.MouseButton
            && Control == other.Control
            && Alt == other.Alt
            && Shift == other.Shift
            && Win == other.Win;
    }

    public override bool Equals(object? obj) => Equals(obj as HotkeyBinding);

    public override int GetHashCode() => HashCode.Combine(VirtualKey, MouseButton, Control, Alt, Shift, Win);

    public static bool IsModifierKey(Keys key)
    {
        return key is Keys.ControlKey or Keys.LControlKey or Keys.RControlKey
            or Keys.Menu or Keys.LMenu or Keys.RMenu
            or Keys.ShiftKey or Keys.LShiftKey or Keys.RShiftKey
            or Keys.LWin or Keys.RWin;
    }

    private bool ModifiersMatch(bool control, bool alt, bool shift, bool win, bool ignoreExtraModifiers)
    {
        if (ignoreExtraModifiers)
        {
            return (!Control || control)
                && (!Alt || alt)
                && (!Shift || shift)
                && (!Win || win);
        }

        return Control == control && Alt == alt && Shift == shift && Win == win;
    }

    private void Reset()
    {
        VirtualKey = 0;
        MouseButton = HotkeyMouseButton.None;
        Control = false;
        Alt = false;
        Shift = false;
        Win = false;
    }

    private static string GetMouseButtonName(HotkeyMouseButton button)
    {
        return button switch
        {
            HotkeyMouseButton.Middle => "Mouse 3",
            HotkeyMouseButton.Mouse4 => "Mouse 4",
            HotkeyMouseButton.Mouse5 => "Mouse 5",
            _ => "Mouse"
        };
    }

    private static string GetKeyName(Keys key)
    {
        var virtualKey = (int)key;
        if (virtualKey >= (int)Keys.D0 && virtualKey <= (int)Keys.D9)
        {
            return ((char)('0' + (virtualKey - (int)Keys.D0))).ToString();
        }

        if (virtualKey >= (int)Keys.A && virtualKey <= (int)Keys.Z)
        {
            return key.ToString();
        }

        if (virtualKey >= (int)Keys.NumPad0 && virtualKey <= (int)Keys.NumPad9)
        {
            return $"Num {virtualKey - (int)Keys.NumPad0}";
        }

        return key switch
        {
            Keys.Space => "Space",
            Keys.Enter => "Enter",
            Keys.Escape => "Esc",
            Keys.Back => "Backspace",
            Keys.Delete => "Delete",
            Keys.Insert => "Insert",
            Keys.Home => "Home",
            Keys.End => "End",
            Keys.PageUp => "Page Up",
            Keys.PageDown => "Page Down",
            Keys.Left => "←",
            Keys.Right => "→",
            Keys.Up => "↑",
            Keys.Down => "↓",
            Keys.Oemtilde => "`",
            Keys.OemMinus => "-",
            Keys.Oemplus => "=",
            Keys.OemOpenBrackets => "[",
            Keys.OemCloseBrackets => "]",
            Keys.OemPipe => "\\",
            Keys.OemSemicolon => ";",
            Keys.OemQuotes => "'",
            Keys.Oemcomma => ",",
            Keys.OemPeriod => ".",
            Keys.OemQuestion => "/",
            _ => key.ToString()
        };
    }
}

internal sealed class AppSettings
{
    public int IntervalMs { get; set; } = 50;
    public ClickButton ClickButton { get; set; } = global::WinClicker.Models.ClickButton.Left;
    public ClickPattern Pattern { get; set; } = ClickPattern.Single;
    public bool UltraMode { get; set; }
    public int UltraBatchSize { get; set; } = 8;
    public int StartDelayMs { get; set; }
    public int ClickLimit { get; set; }
    public HotkeyBinding ToggleHotkey { get; set; } = HotkeyBinding.FromKey(Keys.F6);
    public HotkeyBinding SwitchButtonHotkey { get; set; } = HotkeyBinding.FromKey(Keys.F7);
    public HotkeyBinding UltraHotkey { get; set; } = HotkeyBinding.Disabled();
    public bool IgnoreExtraModifiers { get; set; } = true;
    public bool SuppressHotkeys { get; set; } = true;
    public bool MinimizeToTray { get; set; } = true;

    public void Normalize()
    {
        IntervalMs = Math.Clamp(IntervalMs, 1, 1000);
        StartDelayMs = Math.Clamp(StartDelayMs, 0, 5000);
        ClickLimit = Math.Clamp(ClickLimit, 0, 1_000_000);
        if (UltraBatchSize is not (1 or 4 or 8 or 16 or 32))
        {
            UltraBatchSize = 8;
        }

        if (!Enum.IsDefined<global::WinClicker.Models.ClickButton>(ClickButton))
        {
            ClickButton = global::WinClicker.Models.ClickButton.Left;
        }

        if (!Enum.IsDefined(Pattern))
        {
            Pattern = ClickPattern.Single;
        }

        ToggleHotkey ??= HotkeyBinding.FromKey(Keys.F6);
        SwitchButtonHotkey ??= HotkeyBinding.FromKey(Keys.F7);
        UltraHotkey ??= HotkeyBinding.Disabled();
        ToggleHotkey.Normalize();
        SwitchButtonHotkey.Normalize();
        UltraHotkey.Normalize();

        if (!ToggleHotkey.IsDisabled && ToggleHotkey.Equals(SwitchButtonHotkey))
        {
            SwitchButtonHotkey = ToggleHotkey.Equals(HotkeyBinding.FromKey(Keys.F7))
                ? HotkeyBinding.FromKey(Keys.F8)
                : HotkeyBinding.FromKey(Keys.F7);
        }

        if (!UltraHotkey.IsDisabled
            && (UltraHotkey.Equals(ToggleHotkey) || UltraHotkey.Equals(SwitchButtonHotkey)))
        {
            UltraHotkey = HotkeyBinding.Disabled();
        }
    }
}
