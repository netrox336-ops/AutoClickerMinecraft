# Changelog

## 2.0.0 — Next / Design System

- полностью новый угольно-чёрный интерфейс с красным акцентом и общей библиотекой UI-компонентов;
- Burst Mode: 2/3/5/10 кликов, внутренний интервал, пауза между очередями;
- независимые Toggle/Hold/Press режимы глобальных хоткеев;
- Random Interval: Min–Max и Base ± Variation;
- обязательный Panic Key с отпусканием кнопок и сбросом worker;
- Performance Normal/High/Ultra, CPU priority и фактический CPS/CPU;
- компактный click-through Overlay с четырьмя углами и прозрачностью;
- безопасный Ultra Benchmark с фактическим результатом SendInput;
- миграция настроек WinClicker Ultra 1.1.0;
- расширенные встроенные и ручные тесты.

## 1.1.0 — Ultra

- Ultra batch ×1–×32;
- Single/Double/Triple;
- Mouse 3/4/5 hotkeys;
- задержка старта, лимит и live CPS.
