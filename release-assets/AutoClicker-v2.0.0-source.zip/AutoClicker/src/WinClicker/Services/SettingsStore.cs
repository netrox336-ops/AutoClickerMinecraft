using System.Text.Json;
using WinClicker.Models;

namespace WinClicker.Services;

internal sealed class SettingsStore
{
    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        WriteIndented = true,
        PropertyNameCaseInsensitive = true
    };

    private readonly string _settingsPath;
    private readonly string _legacySettingsPath;

    internal SettingsStore()
    {
        var localAppData = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
        var directory = Path.Combine(
            localAppData,
            "AutoClicker");
        _legacySettingsPath = Path.Combine(
            localAppData,
            "WinClicker",
            "settings.json");
        _settingsPath = Path.Combine(directory, "settings.json");
    }

    internal AppSettings Load()
    {
        try
        {
            var sourcePath = File.Exists(_settingsPath)
                ? _settingsPath
                : File.Exists(_legacySettingsPath)
                    ? _legacySettingsPath
                    : null;
            if (sourcePath is null)
            {
                return new AppSettings();
            }

            var json = File.ReadAllText(sourcePath);
            var settings = JsonSerializer.Deserialize<AppSettings>(json, JsonOptions) ?? new AppSettings();
            settings.Normalize();
            return settings;
        }
        catch (JsonException)
        {
            return new AppSettings();
        }
        catch (IOException)
        {
            return new AppSettings();
        }
        catch (UnauthorizedAccessException)
        {
            return new AppSettings();
        }
    }

    internal bool Save(AppSettings settings)
    {
        try
        {
            settings.Normalize();
            var directory = Path.GetDirectoryName(_settingsPath)!;
            Directory.CreateDirectory(directory);
            var temporaryPath = _settingsPath + ".tmp";
            File.WriteAllText(temporaryPath, JsonSerializer.Serialize(settings, JsonOptions));
            File.Move(temporaryPath, _settingsPath, true);
            return true;
        }
        catch (IOException)
        {
            return false;
        }
        catch (UnauthorizedAccessException)
        {
            return false;
        }
    }
}
