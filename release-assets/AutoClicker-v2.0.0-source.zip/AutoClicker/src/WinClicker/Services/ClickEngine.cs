using System.Diagnostics;
using System.Runtime.InteropServices;
using WinClicker.Models;

namespace WinClicker.Services;

internal sealed class ClickEngine : IDisposable
{
    private readonly object _gate = new();
    private readonly Dictionary<(ClickButton Button, int ClickCount), NativeMethods.Input[]> _inputCache = new();
    private AppSettings _settings = new();
    private ManualResetEvent? _stopSignal;
    private Thread? _worker;
    private int _runGeneration;
    private long _sessionClicks;
    private long _generatedEvents;
    private long _deliveredEvents;
    private bool _disposed;

    internal event EventHandler? RunStopped;

    internal bool IsRunning
    {
        get
        {
            lock (_gate)
            {
                return _worker is { IsAlive: true };
            }
        }
    }

    internal long SessionClicks => Interlocked.Read(ref _sessionClicks);
    internal long GeneratedEvents => Interlocked.Read(ref _generatedEvents);
    internal long DeliveredEvents => Interlocked.Read(ref _deliveredEvents);

    internal bool Start(
        AppSettings settings,
        bool oneShot = false,
        PerformanceMode? forcedPerformance = null)
    {
        ObjectDisposedException.ThrowIf(_disposed, this);
        ApplySettings(settings);

        lock (_gate)
        {
            if (_worker is { IsAlive: true })
            {
                return false;
            }

            _stopSignal?.Dispose();
            _stopSignal = new ManualResetEvent(false);
            Interlocked.Exchange(ref _sessionClicks, 0);
            Interlocked.Exchange(ref _generatedEvents, 0);
            Interlocked.Exchange(ref _deliveredEvents, 0);

            var stopSignal = _stopSignal;
            var generation = unchecked(++_runGeneration);
            var worker = new Thread(() => WorkerLoop(stopSignal, generation, oneShot, forcedPerformance))
            {
                IsBackground = true,
                Name = oneShot ? "AutoClicker.PressWorker" : "AutoClicker.ClickWorker"
            };
            worker.Priority = ResolveThreadPriority(Volatile.Read(ref _settings), forcedPerformance);
            _worker = worker;
            worker.Start();
            return true;
        }
    }

    internal bool TriggerOnce(AppSettings settings, PerformanceMode? forcedPerformance = null)
        => Start(settings, oneShot: true, forcedPerformance: forcedPerformance);

    internal void Stop()
    {
        SignalStop(joinMilliseconds: 1200);
        ReleasePressedButtons();
    }

    internal void PanicStop()
    {
        lock (_gate)
        {
            unchecked
            {
                _runGeneration++;
            }

            _stopSignal?.Set();
        }

        ReleasePressedButtons();
    }

    internal void ResetStatistics()
    {
        Interlocked.Exchange(ref _sessionClicks, 0);
        Interlocked.Exchange(ref _generatedEvents, 0);
        Interlocked.Exchange(ref _deliveredEvents, 0);
    }

    internal void ApplySettings(AppSettings settings)
    {
        var snapshot = settings.CloneForEngine();
        Volatile.Write(ref _settings, snapshot);

        lock (_gate)
        {
            if (_worker is null)
            {
                return;
            }

            try
            {
                _worker.Priority = ResolveThreadPriority(snapshot, null);
            }
            catch (ThreadStateException)
            {
                // The worker completed while settings were being applied.
            }
        }
    }

    internal static int CalculateInputEventCount(ClickPattern pattern, int cycles)
        => Math.Clamp((int)pattern, 1, 3) * Math.Max(1, cycles) * 2;

    internal static (double Minimum, double Maximum) CalculateDelayBounds(
        AppSettings settings,
        bool insideBurst)
    {
        return settings.RandomInterval switch
        {
            RandomIntervalMode.Range => (settings.RandomMinMs, settings.RandomMaxMs),
            RandomIntervalMode.Variation =>
                (Math.Max(1, settings.RandomBaseMs - settings.RandomVariationMs),
                 Math.Min(1000, settings.RandomBaseMs + settings.RandomVariationMs)),
            _ when insideBurst => (settings.BurstIntervalMs, settings.BurstIntervalMs),
            _ => (settings.IntervalMs, settings.IntervalMs)
        };
    }

    internal static void ReleasePressedButtons()
    {
        if (!OperatingSystem.IsWindows())
        {
            return;
        }

        var inputs = new[]
        {
            CreateMouseInput(NativeMethods.MouseeventfLeftup),
            CreateMouseInput(NativeMethods.MouseeventfRightup),
            CreateMouseInput(NativeMethods.MouseeventfMiddleup),
            CreateMouseInput(NativeMethods.MouseeventfXup, NativeMethods.XButton1),
            CreateMouseInput(NativeMethods.MouseeventfXup, NativeMethods.XButton2)
        };
        NativeMethods.SendInput((uint)inputs.Length, inputs, Marshal.SizeOf<NativeMethods.Input>());
    }

    private void WorkerLoop(
        ManualResetEvent stopSignal,
        int generation,
        bool oneShot,
        PerformanceMode? forcedPerformance)
    {
        NativeMethods.timeBeginPeriod(1);
        try
        {
            var initial = Volatile.Read(ref _settings);
            if (initial.StartDelayMs > 0 && stopSignal.WaitOne(initial.StartDelayMs))
            {
                return;
            }

            var random = new Random(unchecked(Environment.TickCount * 397) ^ Environment.CurrentManagedThreadId);
            var ultraIterations = 0;

            while (!stopSignal.WaitOne(0) && generation == Volatile.Read(ref _runGeneration))
            {
                var settings = Volatile.Read(ref _settings);
                var performance = forcedPerformance ?? settings.Performance;
                var continueRunning = settings.BurstEnabled
                    ? ExecuteBurst(settings, performance, stopSignal, random)
                    : ExecuteCycle(settings, performance, stopSignal, random, oneShot, ref ultraIterations);

                if (!continueRunning || oneShot || ReachedClickLimit(settings))
                {
                    break;
                }

                if (settings.BurstEnabled
                    && WaitPrecisely(stopSignal, settings.BurstPauseMs, performance != PerformanceMode.Normal))
                {
                    break;
                }
            }
        }
        finally
        {
            NativeMethods.timeEndPeriod(1);
            CompleteWorker(stopSignal);
        }
    }

    private bool ExecuteCycle(
        AppSettings settings,
        PerformanceMode performance,
        ManualResetEvent stopSignal,
        Random random,
        bool oneShot,
        ref int ultraIterations)
    {
        var patternClicks = Math.Clamp((int)settings.Pattern, 1, 3);
        var requestedClicks = performance == PerformanceMode.Ultra
            ? patternClicks * NormalizeBatchSize(settings.UltraBatchSize)
            : patternClicks;
        requestedClicks = ApplyClickLimit(settings, requestedClicks);
        if (requestedClicks <= 0)
        {
            return false;
        }

        SendClicks(settings.ClickButton, requestedClicks);
        if (oneShot)
        {
            return true;
        }

        if (performance == PerformanceMode.Ultra)
        {
            ultraIterations++;
            if ((ultraIterations & 15) == 0)
            {
                Thread.Yield();
            }

            return true;
        }

        var delay = PickDelay(settings, insideBurst: false, random);
        return !WaitPrecisely(stopSignal, delay, performance == PerformanceMode.High);
    }

    private bool ExecuteBurst(
        AppSettings settings,
        PerformanceMode performance,
        ManualResetEvent stopSignal,
        Random random)
    {
        var requestedClicks = ApplyClickLimit(settings, settings.BurstClicks);
        if (requestedClicks <= 0)
        {
            return false;
        }

        var bounds = CalculateDelayBounds(settings, insideBurst: true);
        if (bounds.Maximum <= 0)
        {
            SendClicks(settings.ClickButton, requestedClicks);
            return true;
        }

        for (var index = 0; index < requestedClicks; index++)
        {
            if (stopSignal.WaitOne(0))
            {
                return false;
            }

            SendClicks(settings.ClickButton, 1);
            if (index + 1 >= requestedClicks)
            {
                continue;
            }

            var delay = PickDelay(settings, insideBurst: true, random);
            if (WaitPrecisely(stopSignal, delay, performance != PerformanceMode.Normal))
            {
                return false;
            }
        }

        return true;
    }

    private int ApplyClickLimit(AppSettings settings, int requestedClicks)
    {
        if (settings.ClickLimit <= 0)
        {
            return Math.Max(1, requestedClicks);
        }

        var remaining = settings.ClickLimit - Interlocked.Read(ref _sessionClicks);
        return remaining <= 0 ? 0 : (int)Math.Min(requestedClicks, remaining);
    }

    private bool ReachedClickLimit(AppSettings settings)
        => settings.ClickLimit > 0 && Interlocked.Read(ref _sessionClicks) >= settings.ClickLimit;

    private void SendClicks(ClickButton button, int clickCount)
    {
        var cacheKey = (Button: button, ClickCount: Math.Max(1, clickCount));
        if (!_inputCache.TryGetValue(cacheKey, out var inputs))
        {
            inputs = BuildClickInputs(cacheKey.Button, cacheKey.ClickCount);
            _inputCache[cacheKey] = inputs;
        }
        Interlocked.Add(ref _generatedEvents, inputs.Length);
        var sentEvents = NativeMethods.SendInput(
            (uint)inputs.Length,
            inputs,
            Marshal.SizeOf<NativeMethods.Input>());
        Interlocked.Add(ref _deliveredEvents, sentEvents);

        var deliveredClicks = sentEvents / 2;
        if (deliveredClicks > 0)
        {
            Interlocked.Add(ref _sessionClicks, deliveredClicks);
        }
        else
        {
            Thread.Yield();
        }
    }

    private static NativeMethods.Input[] BuildClickInputs(ClickButton button, int clickCount)
    {
        clickCount = Math.Max(1, clickCount);
        var downFlag = button == ClickButton.Left
            ? NativeMethods.MouseeventfLeftdown
            : NativeMethods.MouseeventfRightdown;
        var upFlag = button == ClickButton.Left
            ? NativeMethods.MouseeventfLeftup
            : NativeMethods.MouseeventfRightup;
        var inputs = new NativeMethods.Input[clickCount * 2];
        for (var index = 0; index < inputs.Length; index += 2)
        {
            inputs[index] = CreateMouseInput(downFlag);
            inputs[index + 1] = CreateMouseInput(upFlag);
        }

        return inputs;
    }

    private static NativeMethods.Input CreateMouseInput(uint flags, uint mouseData = 0)
    {
        return new NativeMethods.Input
        {
            type = NativeMethods.InputMouse,
            data = new NativeMethods.InputUnion
            {
                mouse = new NativeMethods.MouseInput
                {
                    mouseData = mouseData,
                    dwFlags = flags
                }
            }
        };
    }

    private static double PickDelay(AppSettings settings, bool insideBurst, Random random)
    {
        var bounds = CalculateDelayBounds(settings, insideBurst);
        if (Math.Abs(bounds.Maximum - bounds.Minimum) < 0.0001)
        {
            return bounds.Minimum;
        }

        return bounds.Minimum + (random.NextDouble() * (bounds.Maximum - bounds.Minimum));
    }

    private static bool WaitPrecisely(ManualResetEvent stopSignal, double milliseconds, bool highPrecision)
    {
        if (milliseconds <= 0)
        {
            return stopSignal.WaitOne(0);
        }

        if (!highPrecision)
        {
            return stopSignal.WaitOne(Math.Max(1, (int)Math.Round(milliseconds)));
        }

        var start = Stopwatch.GetTimestamp();
        var targetTicks = milliseconds * Stopwatch.Frequency / 1000d;
        if (milliseconds >= 2)
        {
            var coarseWait = Math.Max(0, (int)Math.Floor(milliseconds) - 1);
            if (coarseWait > 0 && stopSignal.WaitOne(coarseWait))
            {
                return true;
            }
        }

        while (Stopwatch.GetTimestamp() - start < targetTicks)
        {
            if (stopSignal.WaitOne(0))
            {
                return true;
            }

            Thread.SpinWait(32);
        }

        return false;
    }

    private static ThreadPriority ResolveThreadPriority(
        AppSettings settings,
        PerformanceMode? forcedPerformance)
    {
        if (settings.CpuPriority == CpuPriorityMode.High)
        {
            return ThreadPriority.Highest;
        }

        return (forcedPerformance ?? settings.Performance) == PerformanceMode.Normal
            ? ThreadPriority.Normal
            : ThreadPriority.AboveNormal;
    }

    private static int NormalizeBatchSize(int batchSize)
        => batchSize is 1 or 4 or 8 or 16 or 32 ? batchSize : 8;

    private void SignalStop(int joinMilliseconds)
    {
        Thread? worker;
        lock (_gate)
        {
            worker = _worker;
            _stopSignal?.Set();
        }

        if (worker is not null && Thread.CurrentThread != worker)
        {
            worker.Join(joinMilliseconds);
        }
    }

    private void CompleteWorker(ManualResetEvent signal)
    {
        lock (_gate)
        {
            if (ReferenceEquals(_worker, Thread.CurrentThread))
            {
                _worker = null;
                _stopSignal = null;
            }
        }

        signal.Dispose();
        try
        {
            RunStopped?.Invoke(this, EventArgs.Empty);
        }
        catch
        {
            // A UI subscriber may already be shutting down.
        }
    }

    public void Dispose()
    {
        if (_disposed)
        {
            return;
        }

        PanicStop();
        SignalStop(joinMilliseconds: 1200);
        _disposed = true;
        GC.SuppressFinalize(this);
    }
}
