using System.Windows.Forms;
using WinClicker.Models;

namespace WinClicker.Services;

internal static class SelfTestRunner
{
    internal static int Run()
    {
        try
        {
            TestHotkeys();
            TestSettingsNormalization();
            TestBurstAndRandomIntervals();
            TestUltraAndBenchmarkMath();
            return 0;
        }
        catch
        {
            return 1;
        }
    }

    private static void TestHotkeys()
    {
        var plainF6 = HotkeyBinding.FromKey(Keys.F6);
        Assert(plainF6.MatchesKeyboard((int)Keys.F6, false, false, true, false, true),
            "F6 должен срабатывать при дополнительно зажатом Shift.");
        Assert(!plainF6.MatchesKeyboard((int)Keys.F6, false, false, true, false, false),
            "F6 не должен срабатывать с лишним Shift в строгом режиме.");

        var ctrlF7 = HotkeyBinding.FromKey(Keys.F7, control: true);
        Assert(!ctrlF7.MatchesKeyboard((int)Keys.F7, false, false, false, false, true),
            "Ctrl+F7 не должен срабатывать без Ctrl.");
        Assert(ctrlF7.MatchesKeyboard((int)Keys.F7, true, false, true, false, true),
            "Ctrl+F7 должен принимать лишний Shift в совместимом режиме.");

        var mouse4 = HotkeyBinding.FromMouse(HotkeyMouseButton.Mouse4);
        Assert(mouse4.MatchesMouse(HotkeyMouseButton.Mouse4, false, false, true, false, true),
            "Mouse 4 должен срабатывать с дополнительно зажатым Shift.");
        Assert(!mouse4.MatchesMouse(HotkeyMouseButton.Mouse5, false, false, false, false, true),
            "Mouse 4 не должен совпадать с Mouse 5.");

        var duplicatePanic = new AppSettings
        {
            ToggleHotkey = HotkeyBinding.FromKey(Keys.F12),
            PanicHotkey = HotkeyBinding.FromKey(Keys.F12)
        };
        duplicatePanic.Normalize();
        Assert(!duplicatePanic.ToggleHotkey.Equals(duplicatePanic.PanicHotkey),
            "Panic Key должен иметь уникальный бинд.");
        Assert(!duplicatePanic.PanicHotkey.IsDisabled,
            "Panic Key нельзя отключить нормализацией.");

        var panicOnF6 = new AppSettings
        {
            ToggleHotkey = HotkeyBinding.FromKey(Keys.F6),
            PanicHotkey = HotkeyBinding.FromKey(Keys.F6)
        };
        panicOnF6.Normalize();
        Assert(!panicOnF6.ToggleHotkey.Equals(panicOnF6.PanicHotkey),
            "Переназначение Panic на F6 должно сдвинуть основной хоткей.");
    }

    private static void TestSettingsNormalization()
    {
        var settings = new AppSettings
        {
            IntervalMs = 5000,
            StartDelayMs = -1,
            ClickLimit = 2_000_000,
            UltraBatchSize = 99,
            BurstClicks = 7,
            BurstIntervalMs = -4,
            BurstPauseMs = 9000,
            OverlayOpacityPercent = 5
        };
        settings.Normalize();
        Assert(settings.IntervalMs == 1000, "Интервал должен ограничиваться 1000 мс.");
        Assert(settings.StartDelayMs == 0, "Задержка старта не может быть отрицательной.");
        Assert(settings.ClickLimit == 1_000_000, "Лимит кликов должен ограничиваться миллионом.");
        Assert(settings.UltraBatchSize == 8, "Некорректный Ultra batch должен стать ×8.");
        Assert(settings.BurstClicks == 5, "Некорректная очередь должна стать 5 кликов.");
        Assert(settings.BurstIntervalMs == 0, "Внутренний интервал Burst не может быть отрицательным.");
        Assert(settings.BurstPauseMs == 5000, "Пауза Burst должна ограничиваться 5000 мс.");
        Assert(settings.OverlayOpacityPercent == 20, "Overlay не должен становиться невидимым.");

        var migrated = new AppSettings { UltraMode = true, Performance = PerformanceMode.Normal };
        migrated.Normalize();
        Assert(migrated.Performance == PerformanceMode.Ultra,
            "Ultra из настроек 1.1.0 должен мигрировать в профиль Ultra 2.0.");
    }

    private static void TestBurstAndRandomIntervals()
    {
        var range = new AppSettings
        {
            RandomInterval = RandomIntervalMode.Range,
            RandomMinMs = 55,
            RandomMaxMs = 40
        };
        range.Normalize();
        var rangeBounds = ClickEngine.CalculateDelayBounds(range, insideBurst: true);
        Assert(rangeBounds.Minimum == 40 && rangeBounds.Maximum == 55,
            "Перевёрнутый Random range должен автоматически исправляться.");

        var variation = new AppSettings
        {
            RandomInterval = RandomIntervalMode.Variation,
            RandomBaseMs = 50,
            RandomVariationMs = 5
        };
        var variationBounds = ClickEngine.CalculateDelayBounds(variation, insideBurst: false);
        Assert(variationBounds.Minimum == 45 && variationBounds.Maximum == 55,
            "Base 50 ±5 должен давать диапазон 45–55 мс.");

        var burst = new AppSettings
        {
            RandomInterval = RandomIntervalMode.Off,
            BurstIntervalMs = 0.25
        };
        var burstBounds = ClickEngine.CalculateDelayBounds(burst, insideBurst: true);
        Assert(Math.Abs(burstBounds.Minimum - 0.25) < 0.0001,
            "Burst должен сохранять субмиллисекундный внутренний интервал.");
    }

    private static void TestUltraAndBenchmarkMath()
    {
        Assert(ClickEngine.CalculateInputEventCount(ClickPattern.Double, 4) == 16,
            "Double ×4 должен создавать 16 INPUT-событий.");
        Assert(ClickEngine.CalculateInputEventCount(ClickPattern.Triple, 32) == 192,
            "Triple ×32 должен создавать 192 INPUT-события.");
        Assert(UltraBenchmark.RecommendBatchSize(130_000) == 32,
            "Быстрая система должна получать рекомендацию ×32.");
        Assert(UltraBenchmark.RecommendBatchSize(12_000) == 4,
            "Средняя система должна получать рекомендацию ×4.");
        var minimum = UltraBenchmark.RecommendMinimumInterval(8_000);
        Assert(minimum > 0.28 && minimum < 0.30,
            "Рекомендуемый интервал должен считаться по полным down/up кликам.");
    }

    private static void Assert(bool condition, string message)
    {
        if (!condition)
        {
            throw new InvalidOperationException(message);
        }
    }
}
