using System.Diagnostics;
using System.Runtime.InteropServices;

namespace WinClicker.Services;

internal sealed record BenchmarkResult(
    double GeneratedEventsPerSecond,
    double DeliveredEventsPerSecond,
    double RecommendedMinimumMs,
    int RecommendedBatchSize,
    TimeSpan Duration);

internal static class UltraBenchmark
{
    private const int BatchSize = 128;

    internal static Task<BenchmarkResult> RunAsync(
        TimeSpan duration,
        IProgress<int>? progress,
        CancellationToken cancellationToken)
    {
        if (!OperatingSystem.IsWindows())
        {
            throw new PlatformNotSupportedException("Benchmark доступен только в Windows.");
        }

        duration = TimeSpan.FromMilliseconds(Math.Clamp(duration.TotalMilliseconds, 750, 5000));
        return Task.Run(() => Run(duration, progress, cancellationToken), cancellationToken);
    }

    internal static int RecommendBatchSize(double deliveredEventsPerSecond)
    {
        return deliveredEventsPerSecond switch
        {
            >= 120_000 => 32,
            >= 60_000 => 16,
            >= 25_000 => 8,
            >= 10_000 => 4,
            _ => 1
        };
    }

    internal static double RecommendMinimumInterval(double deliveredEventsPerSecond)
    {
        if (!double.IsFinite(deliveredEventsPerSecond) || deliveredEventsPerSecond <= 0)
        {
            return 1;
        }

        var fullClicksPerSecond = deliveredEventsPerSecond / 2d;
        return Math.Clamp((1000d / fullClicksPerSecond) * 1.15d, 0.01d, 1000d);
    }

    private static BenchmarkResult Run(
        TimeSpan duration,
        IProgress<int>? progress,
        CancellationToken cancellationToken)
    {
        var generated = 0L;
        var delivered = 0L;
        var inputSize = Marshal.SizeOf<NativeMethods.Input>();
        var stopwatch = Stopwatch.StartNew();
        var lastProgress = -1;
        NativeMethods.timeBeginPeriod(1);
        try
        {
            while (stopwatch.Elapsed < duration)
            {
                cancellationToken.ThrowIfCancellationRequested();

                // Rebuilding the array intentionally measures event generation as well as delivery.
                var inputs = new NativeMethods.Input[BatchSize];
                for (var index = 0; index < inputs.Length; index++)
                {
                    inputs[index] = new NativeMethods.Input
                    {
                        type = NativeMethods.InputMouse,
                        data = new NativeMethods.InputUnion
                        {
                            mouse = new NativeMethods.MouseInput
                            {
                                dx = 0,
                                dy = 0,
                                dwFlags = NativeMethods.MouseeventfMove
                            }
                        }
                    };
                }

                generated += inputs.Length;
                delivered += NativeMethods.SendInput((uint)inputs.Length, inputs, inputSize);

                var currentProgress = (int)Math.Clamp(
                    stopwatch.Elapsed.TotalMilliseconds / duration.TotalMilliseconds * 100d,
                    0,
                    100);
                if (currentProgress != lastProgress)
                {
                    lastProgress = currentProgress;
                    progress?.Report(currentProgress);
                }

                Thread.Yield();
            }
        }
        finally
        {
            NativeMethods.timeEndPeriod(1);
        }

        stopwatch.Stop();
        progress?.Report(100);
        var elapsedSeconds = Math.Max(0.001d, stopwatch.Elapsed.TotalSeconds);
        var generatedRate = generated / elapsedSeconds;
        var deliveredRate = delivered / elapsedSeconds;
        return new BenchmarkResult(
            generatedRate,
            deliveredRate,
            RecommendMinimumInterval(deliveredRate),
            RecommendBatchSize(deliveredRate),
            stopwatch.Elapsed);
    }
}
