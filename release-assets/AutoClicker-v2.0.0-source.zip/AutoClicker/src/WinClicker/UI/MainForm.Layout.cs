using System.Drawing.Drawing2D;
using WinClicker.Models;
using WinClicker.Services;

namespace WinClicker.UI;

internal sealed partial class MainForm
{
    private void BuildLayout()
    {
        var sidebar = new Panel
        {
            Location = Point.Empty,
            Size = new Size(176, 760),
            BackColor = Theme.Sidebar
        };
        var sidebarBorder = new Panel
        {
            Location = new Point(175, 0),
            Size = new Size(1, 760),
            BackColor = Theme.BorderSoft
        };
        sidebar.Controls.Add(sidebarBorder);

        var logo = new LogoMark { Location = new Point(18, 15), Size = new Size(42, 42) };
        var brand = CreateLabel("AUTO CLICKER", new Point(67, 14), new Size(102, 25), 11.5F, Theme.TextPrimary, true);
        var brandCaption = CreateLabel("FAST • PRECISE", new Point(68, 38), new Size(100, 18), 7.3F, Theme.TextMuted);
        sidebar.Controls.AddRange(new Control[] { logo, brand, brandCaption });

        var navItems = new[]
        {
            ("Главная", "⌂   ГЛАВНАЯ"),
            ("Кликер", "⚙   КЛИКЕР"),
            ("Хоткеи", "⌨   ХОТКЕИ"),
            ("Overlay", "▣   OVERLAY"),
            ("Benchmark", "⚡   BENCHMARK")
        };
        for (var index = 0; index < navItems.Length; index++)
        {
            var item = navItems[index];
            var button = new ThemedButton
            {
                Text = item.Item2,
                Location = new Point(12, 84 + (index * 48)),
                Size = new Size(152, 40),
                ButtonStyle = ThemedButtonStyle.Navigation,
                TextAlign = ContentAlignment.MiddleLeft,
                Font = Theme.Font(8.7F, true)
            };
            button.Click += (_, _) => ShowPage(item.Item1);
            _navButtons[item.Item1] = button;
            sidebar.Controls.Add(button);
        }

        var panicButton = new ThemedButton
        {
            Text = "⚠  EMERGENCY STOP",
            Location = new Point(12, 660),
            Size = new Size(152, 42),
            ButtonStyle = ThemedButtonStyle.Danger,
            Font = Theme.Font(8.2F, true)
        };
        panicButton.Click += (_, _) =>
        {
            _clickEngine.PanicStop();
            _benchmarkCancellation?.Cancel();
            CompletePanicStop();
        };
        var version = CreateLabel("v2.0.0  •  WIN 11 x64", new Point(19, 717), new Size(145, 20), 7.5F, Theme.TextMuted);
        sidebar.Controls.AddRange(new Control[] { panicButton, version });

        var titleBar = new Panel
        {
            Location = new Point(176, 0),
            Size = new Size(1004, 56),
            BackColor = Theme.Background
        };
        var titleBorder = new Panel
        {
            Location = new Point(0, 55),
            Size = new Size(1004, 1),
            BackColor = Theme.BorderSoft
        };
        _pageTitle = CreateLabel("ГЛАВНАЯ", new Point(27, 13), new Size(410, 30), 13F, Theme.TextPrimary, true);
        _topStatusLabel = CreateLabel("● READY", new Point(730, 17), new Size(110, 24), 8F, Theme.Success, true);
        _topStatusLabel.TextAlign = ContentAlignment.MiddleRight;
        var minimizeButton = new ThemedButton
        {
            Text = "—",
            Location = new Point(856, 10),
            Size = new Size(56, 35),
            ButtonStyle = ThemedButtonStyle.Ghost,
            Font = Theme.Font(12F, true)
        };
        minimizeButton.Click += (_, _) => WindowState = FormWindowState.Minimized;
        var closeButton = new ThemedButton
        {
            Text = "×",
            Location = new Point(922, 10),
            Size = new Size(56, 35),
            ButtonStyle = ThemedButtonStyle.Danger,
            Font = Theme.Font(13F, true)
        };
        closeButton.Click += (_, _) => Close();
        titleBar.Controls.AddRange(new Control[] { titleBorder, _pageTitle, _topStatusLabel, minimizeButton, closeButton });
        titleBar.MouseDown += DragWindow;
        _pageTitle.MouseDown += DragWindow;

        var pageHost = new Panel
        {
            Location = new Point(176, 56),
            Size = new Size(1004, 704),
            BackColor = Theme.Background
        };
        RegisterPage(pageHost, "Главная", BuildHomePage());
        RegisterPage(pageHost, "Кликер", BuildClickerPage());
        RegisterPage(pageHost, "Хоткеи", BuildHotkeysPage());
        RegisterPage(pageHost, "Overlay", BuildOverlayPage());
        RegisterPage(pageHost, "Benchmark", BuildBenchmarkPage());

        Controls.AddRange(new Control[] { sidebar, titleBar, pageHost });
        sidebar.BringToFront();
        titleBar.BringToFront();
        ShowPage("Главная");
    }

    private Panel BuildHomePage()
    {
        var page = CreatePage();
        AddPageIntro(page, "ПАНЕЛЬ УПРАВЛЕНИЯ", "Текущая сессия и производительность реального SendInput");

        var resetButton = CreateButton("СБРОСИТЬ СТАТИСТИКУ", new Point(792, 20), new Size(184, 34), ThemedButtonStyle.Ghost);
        resetButton.Click += (_, _) => ResetStatistics();
        page.Controls.Add(resetButton);

        var statusCard = CreateCard(new Point(28, 72), new Size(300, 100));
        statusCard.Controls.Add(CreateCardTitle("СТАТУС", new Point(18, 12)));
        _statusLabel = CreateLabel("○  ОСТАНОВЛЕН", new Point(18, 35), new Size(260, 28), 13.5F, Theme.TextSecondary, true);
        _statusDetailLabel = CreateLabel("NORMAL • TOGGLE", new Point(19, 65), new Size(264, 22), 8F, Theme.TextMuted);
        statusCard.Controls.AddRange(new Control[] { _statusLabel, _statusDetailLabel });

        var clicksCard = CreateCard(new Point(342, 72), new Size(290, 100));
        clicksCard.Controls.Add(CreateCardTitle("ДОСТАВЛЕНО КЛИКОВ", new Point(18, 12)));
        _clickCountLabel = CreateLabel("0", new Point(18, 36), new Size(250, 32), 18F, Theme.TextPrimary, true);
        clicksCard.Controls.Add(_clickCountLabel);
        clicksCard.Controls.Add(CreateLabel("Текущая сессия", new Point(19, 69), new Size(220, 18), 8F, Theme.TextMuted));

        var metricsCard = CreateCard(new Point(646, 72), new Size(330, 100));
        metricsCard.Controls.Add(CreateCardTitle("LIVE PERFORMANCE", new Point(18, 12)));
        _rateLabel = CreateLabel("0 CPS", new Point(18, 36), new Size(180, 30), 16F, Theme.Accent, true);
        _cpuLabel = CreateLabel("CPU 0.0%", new Point(202, 39), new Size(105, 24), 10F, Theme.TextSecondary, true);
        _cpuLabel.TextAlign = ContentAlignment.MiddleRight;
        metricsCard.Controls.AddRange(new Control[] { _rateLabel, _cpuLabel });
        metricsCard.Controls.Add(CreateLabel("Только принятые Windows события", new Point(19, 69), new Size(280, 18), 8F, Theme.TextMuted));

        var controlCard = CreateCard(new Point(28, 188), new Size(456, 220));
        controlCard.Controls.Add(CreateCardTitle("УПРАВЛЕНИЕ", new Point(18, 14)));
        _startStopButton = CreateButton("▶  ЗАПУСТИТЬ", new Point(24, 53), new Size(195, 112), ThemedButtonStyle.Primary);
        _startStopButton.Font = Theme.Font(12F, true);
        _startStopButton.Radius = 12;
        _startStopButton.Click += (_, _) => ToggleClicking();
        controlCard.Controls.Add(_startStopButton);
        controlCard.Controls.Add(CreateLabel("ОСНОВНОЙ ХОТКЕЙ", new Point(248, 55), new Size(180, 18), 7.5F, Theme.TextMuted, true));
        _homeHotkeyLabel = CreateLabel("F6", new Point(246, 77), new Size(175, 34), 16F, Theme.TextPrimary, true);
        controlCard.Controls.Add(_homeHotkeyLabel);
        controlCard.Controls.Add(CreateLabel("Toggle / Hold / Press задаётся\nотдельно на странице «Хоткеи»", new Point(247, 122), new Size(185, 48), 8F, Theme.TextSecondary));
        _homePanicLabel = CreateLabel("PANIC: F12", new Point(24, 180), new Size(390, 20), 8F, Theme.Accent, true);
        controlCard.Controls.Add(_homePanicLabel);

        var performanceCard = CreateCard(new Point(500, 188), new Size(476, 220));
        performanceCard.Controls.Add(CreateCardTitle("ULTRA MODE 2.0", new Point(18, 14)));
        performanceCard.Controls.Add(CreateFieldCaption("PERFORMANCE", new Point(20, 47), new Size(205, 18)));
        _performanceInput = CreateComboBox(new Point(20, 68), new Size(205, 31), "Normal", "High", "Ultra");
        _performanceInput.SelectedIndexChanged += (_, _) => ClickSettingsChanged();
        performanceCard.Controls.Add(_performanceInput);
        performanceCard.Controls.Add(CreateFieldCaption("CPU PRIORITY", new Point(245, 47), new Size(205, 18)));
        _cpuPriorityInput = CreateComboBox(new Point(245, 68), new Size(205, 31), "Normal", "High (AboveNormal)");
        _cpuPriorityInput.SelectedIndexChanged += (_, _) => ClickSettingsChanged();
        performanceCard.Controls.Add(_cpuPriorityInput);
        performanceCard.Controls.Add(CreateFieldCaption("ULTRA BATCH", new Point(20, 112), new Size(205, 18)));
        _ultraBatchInput = CreateComboBox(new Point(20, 133), new Size(205, 31), "×1", "×4", "×8", "×16", "×32 MAX");
        _ultraBatchInput.SelectedIndexChanged += (_, _) => ClickSettingsChanged();
        performanceCard.Controls.Add(_ultraBatchInput);
        _performanceActualLabel = CreateLabel("Current rate: ~0 clicks/sec   •   CPU: 0.0%", new Point(20, 180), new Size(430, 22), 8.2F, Theme.TextSecondary);
        performanceCard.Controls.Add(_performanceActualLabel);

        var summaryCard = CreateCard(new Point(28, 426), new Size(948, 184));
        summaryCard.Controls.Add(CreateCardTitle("ТЕКУЩАЯ КОНФИГУРАЦИЯ", new Point(18, 14)));
        _homeClickSummaryLabel = CreateLabel("LMB • SINGLE", new Point(22, 48), new Size(275, 28), 12F, Theme.TextPrimary, true);
        _homeBurstSummaryLabel = CreateLabel("Burst Mode выключен", new Point(22, 83), new Size(560, 23), 9F, Theme.TextSecondary);
        _homeRandomSummaryLabel = CreateLabel("Фиксированный интервал 50 ms", new Point(22, 112), new Size(560, 23), 9F, Theme.TextSecondary);
        var configureButton = CreateButton("НАСТРОИТЬ КЛИКЕР", new Point(706, 67), new Size(212, 48), ThemedButtonStyle.Secondary);
        configureButton.Click += (_, _) => ShowPage("Кликер");
        summaryCard.Controls.AddRange(new Control[] { _homeClickSummaryLabel, _homeBurstSummaryLabel, _homeRandomSummaryLabel, configureButton });
        summaryCard.Controls.Add(CreateLabel("Фактический CPS может быть выше скорости, которую принимает конкретная игра.", new Point(22, 148), new Size(870, 20), 8F, Theme.TextMuted));

        page.Controls.AddRange(new Control[] { statusCard, clicksCard, metricsCard, controlCard, performanceCard, summaryCard });
        return page;
    }

    private Panel BuildClickerPage()
    {
        var page = CreatePage();
        AddPageIntro(page, "КЛИКЕР", "Режим клика, Burst очереди, Random Interval и ограничения сессии");

        var clickCard = CreateCard(new Point(28, 72), new Size(456, 220));
        clickCard.Controls.Add(CreateCardTitle("РЕЖИМ КЛИКА", new Point(18, 14)));
        clickCard.Controls.Add(CreateFieldCaption("КНОПКА", new Point(20, 48), new Size(160, 18)));
        _leftButton = CreateButton("LMB  •  ЛЕВАЯ", new Point(20, 69), new Size(194, 42), ThemedButtonStyle.Secondary);
        _rightButton = CreateButton("RMB  •  ПРАВАЯ", new Point(226, 69), new Size(204, 42), ThemedButtonStyle.Secondary);
        _leftButton.Click += (_, _) => SetClickButton(ClickButton.Left);
        _rightButton.Click += (_, _) => SetClickButton(ClickButton.Right);
        clickCard.Controls.AddRange(new Control[] { _leftButton, _rightButton });
        clickCard.Controls.Add(CreateFieldCaption("PATTERN", new Point(20, 126), new Size(190, 18)));
        _patternInput = CreateComboBox(new Point(20, 147), new Size(194, 31), "Single click", "Double click", "Triple click");
        _patternInput.SelectedIndexChanged += (_, _) => ClickSettingsChanged();
        clickCard.Controls.Add(_patternInput);
        clickCard.Controls.Add(CreateFieldCaption("INTERVAL", new Point(226, 126), new Size(190, 18)));
        _intervalInput = CreateNumeric(new Point(226, 147), new Size(154, 31), 1, 1000);
        _intervalInput.ValueChanged += (_, _) => ClickSettingsChanged();
        clickCard.Controls.Add(_intervalInput);
        clickCard.Controls.Add(CreateLabel("ms", new Point(386, 151), new Size(40, 24), 8.5F, Theme.TextMuted));
        clickCard.Controls.Add(CreateLabel("В Burst Mode pattern заменяется точным числом кликов.", new Point(20, 190), new Size(410, 18), 7.7F, Theme.TextMuted));

        var burstCard = CreateCard(new Point(500, 72), new Size(476, 220));
        burstCard.Controls.Add(CreateCardTitle("BURST MODE", new Point(18, 14)));
        _burstToggle = new ToggleSwitch { Location = new Point(408, 13) };
        _burstToggle.CheckedChanged += (_, _) => ClickSettingsChanged();
        burstCard.Controls.Add(_burstToggle);
        burstCard.Controls.Add(CreateFieldCaption("КЛИКОВ В ОЧЕРЕДИ", new Point(20, 50), new Size(200, 18)));
        _burstCountInput = CreateComboBox(new Point(20, 71), new Size(200, 31), "2 клика", "3 клика", "5 кликов", "10 кликов");
        _burstCountInput.SelectedIndexChanged += (_, _) => ClickSettingsChanged();
        burstCard.Controls.Add(_burstCountInput);
        burstCard.Controls.Add(CreateFieldCaption("ИНТЕРВАЛ ВНУТРИ", new Point(242, 50), new Size(200, 18)));
        _burstIntervalInput = CreateNumeric(new Point(242, 71), new Size(158, 31), 0, 1000, 1, 0.1M);
        _burstIntervalInput.ValueChanged += (_, _) => ClickSettingsChanged();
        burstCard.Controls.Add(_burstIntervalInput);
        burstCard.Controls.Add(CreateLabel("ms", new Point(407, 75), new Size(38, 24), 8.5F, Theme.TextMuted));
        burstCard.Controls.Add(CreateFieldCaption("ПАУЗА МЕЖДУ ОЧЕРЕДЯМИ", new Point(20, 119), new Size(250, 18)));
        _burstPauseInput = CreateNumeric(new Point(20, 140), new Size(200, 31), 0, 5000);
        _burstPauseInput.ValueChanged += (_, _) => ClickSettingsChanged();
        burstCard.Controls.Add(_burstPauseInput);
        burstCard.Controls.Add(CreateLabel("ms", new Point(228, 144), new Size(38, 24), 8.5F, Theme.TextMuted));
        burstCard.Controls.Add(CreateLabel("Пример: 5 × 2 ms → пауза 100 ms → повтор", new Point(20, 190), new Size(425, 18), 7.7F, Theme.TextMuted));

        var randomCard = CreateCard(new Point(28, 310), new Size(456, 242));
        randomCard.Controls.Add(CreateCardTitle("RANDOM INTERVAL", new Point(18, 14)));
        randomCard.Controls.Add(CreateFieldCaption("РЕЖИМ", new Point(20, 48), new Size(410, 18)));
        _randomModeInput = CreateComboBox(new Point(20, 69), new Size(410, 31), "Выключен", "Диапазон Min–Max", "Base ± Variation");
        _randomModeInput.SelectedIndexChanged += (_, _) => ClickSettingsChanged();
        randomCard.Controls.Add(_randomModeInput);
        randomCard.Controls.Add(CreateFieldCaption("MIN", new Point(20, 116), new Size(90, 18)));
        _randomMinInput = CreateNumeric(new Point(20, 137), new Size(90, 31), 1, 1000);
        _randomMinInput.ValueChanged += (_, _) => ClickSettingsChanged();
        randomCard.Controls.Add(_randomMinInput);
        randomCard.Controls.Add(CreateFieldCaption("MAX", new Point(121, 116), new Size(90, 18)));
        _randomMaxInput = CreateNumeric(new Point(121, 137), new Size(90, 31), 1, 1000);
        _randomMaxInput.ValueChanged += (_, _) => ClickSettingsChanged();
        randomCard.Controls.Add(_randomMaxInput);
        randomCard.Controls.Add(CreateFieldCaption("BASE", new Point(229, 116), new Size(90, 18)));
        _randomBaseInput = CreateNumeric(new Point(229, 137), new Size(90, 31), 1, 1000);
        _randomBaseInput.ValueChanged += (_, _) => ClickSettingsChanged();
        randomCard.Controls.Add(_randomBaseInput);
        randomCard.Controls.Add(CreateFieldCaption("± VAR", new Point(330, 116), new Size(90, 18)));
        _randomVariationInput = CreateNumeric(new Point(330, 137), new Size(100, 31), 0, 999);
        _randomVariationInput.ValueChanged += (_, _) => ClickSettingsChanged();
        randomCard.Controls.Add(_randomVariationInput);
        randomCard.Controls.Add(CreateLabel("Новый интервал выбирается перед каждым следующим кликом.\nВ Burst он заменяет фиксированный внутренний интервал.", new Point(20, 185), new Size(410, 42), 8F, Theme.TextSecondary));

        var advancedCard = CreateCard(new Point(500, 310), new Size(476, 242));
        advancedCard.Controls.Add(CreateCardTitle("ДОПОЛНИТЕЛЬНО", new Point(18, 14)));
        advancedCard.Controls.Add(CreateFieldCaption("ЗАДЕРЖКА СТАРТА", new Point(20, 50), new Size(200, 18)));
        _startDelayInput = CreateNumeric(new Point(20, 71), new Size(200, 31), 0, 5000);
        _startDelayInput.ValueChanged += (_, _) => ClickSettingsChanged();
        advancedCard.Controls.Add(_startDelayInput);
        advancedCard.Controls.Add(CreateLabel("ms", new Point(228, 75), new Size(38, 24), 8.5F, Theme.TextMuted));
        advancedCard.Controls.Add(CreateFieldCaption("ЛИМИТ КЛИКОВ", new Point(253, 50), new Size(195, 18)));
        _clickLimitInput = CreateNumeric(new Point(253, 71), new Size(195, 31), 0, 1_000_000, 0, 100);
        _clickLimitInput.ThousandsSeparator = true;
        _clickLimitInput.ValueChanged += (_, _) => ClickSettingsChanged();
        advancedCard.Controls.Add(_clickLimitInput);
        advancedCard.Controls.Add(CreateLabel("0 = без ограничений", new Point(254, 105), new Size(190, 18), 7.7F, Theme.TextMuted));
        advancedCard.Controls.Add(CreateFieldCaption("СВЕРНУТЬ В ТРЕЙ", new Point(20, 139), new Size(260, 18)));
        _minimizeToTrayToggle = new ToggleSwitch { Location = new Point(406, 135) };
        _minimizeToTrayToggle.CheckedChanged += (_, _) => ClickSettingsChanged();
        advancedCard.Controls.Add(_minimizeToTrayToggle);
        advancedCard.Controls.Add(CreateLabel("Настройки сохраняются автоматически в профиле пользователя Windows.", new Point(20, 184), new Size(425, 38), 8F, Theme.TextSecondary));

        var note = CreateLabel("ULTRA игнорирует обычный интервал, но сохраняет явные интервалы и паузы Burst Mode.", new Point(29, 574), new Size(920, 24), 8.3F, Theme.Warning);
        page.Controls.AddRange(new Control[] { clickCard, burstCard, randomCard, advancedCard, note });
        return page;
    }

    private Panel BuildHotkeysPage()
    {
        var page = CreatePage();
        AddPageIntro(page, "ГОРЯЧИЕ КЛАВИШИ", "Клавиатура, Mouse 3 / Mouse 4 / Mouse 5 и независимый режим срабатывания");
        CreateHotkeyRow(page, HotkeyAction.Clicker, 72, "ЗАПУСК КЛИКЕРА", "Toggle — переключить • Hold — пока удерживается • Press — один Burst");
        CreateHotkeyRow(page, HotkeyAction.SwitchButton, 174, "СМЕНА LMB / RMB", "Hold временно меняет кнопку и возвращает её после отпускания");
        CreateHotkeyRow(page, HotkeyAction.UltraMode, 276, "ULTRA MODE", "Toggle — вкл/выкл • Hold — временно Ultra • Press — один Ultra Burst");
        CreateHotkeyRow(page, HotkeyAction.Panic, 378, "PANIC KEY", "Emergency Stop всегда выполняется по Press и не может быть отключён");

        var options = CreateCard(new Point(28, 496), new Size(948, 116));
        options.Controls.Add(CreateCardTitle("ПОВЕДЕНИЕ ХОТКЕЕВ", new Point(18, 13)));
        _ignoreExtraModifiersToggle = new ToggleSwitch { Location = new Point(405, 45) };
        _ignoreExtraModifiersToggle.CheckedChanged += (_, _) => HotkeyOptionsChanged();
        options.Controls.Add(CreateLabel("Работать при других зажатых клавишах (W + Space + Shift)", new Point(20, 44), new Size(375, 26), 8.6F, Theme.TextSecondary));
        options.Controls.Add(_ignoreExtraModifiersToggle);
        _suppressHotkeysToggle = new ToggleSwitch { Location = new Point(875, 45) };
        _suppressHotkeysToggle.CheckedChanged += (_, _) => HotkeyOptionsChanged();
        options.Controls.Add(CreateLabel("Не передавать сам хоткей в игру", new Point(530, 44), new Size(335, 26), 8.6F, Theme.TextSecondary));
        options.Controls.Add(_suppressHotkeysToggle);
        options.Controls.Add(CreateLabel("Panic обрабатывается до действий остальных хоткеев и сразу отправляет отпускание LMB/RMB/Mouse 3/4/5.", new Point(20, 82), new Size(885, 20), 7.8F, Theme.TextMuted));
        page.Controls.Add(options);
        return page;
    }

    private Panel BuildOverlayPage()
    {
        var page = CreatePage();
        AddPageIntro(page, "ИГРОВОЙ OVERLAY", "Компактный click-through индикатор поверх окон без внедрения в игру");

        var preview = CreateCard(new Point(28, 72), new Size(456, 310));
        preview.Controls.Add(CreateCardTitle("ПРЕДПРОСМОТР", new Point(18, 14)));
        preview.Controls.Add(CreateLabel("Overlay обновляется из реального счётчика доставленных кликов.", new Point(20, 45), new Size(410, 38), 8.2F, Theme.TextSecondary));
        var overlayMock = new RoundedPanel
        {
            Location = new Point(55, 105),
            Size = new Size(346, 92),
            BackColor = Theme.Background,
            BorderColor = Theme.AccentDark,
            Radius = 12
        };
        _overlayPreviewTitle = CreateLabel("○  OFF", new Point(22, 16), new Size(300, 27), 11F, Theme.TextSecondary, true);
        _overlayPreviewDetails = CreateLabel("Overlay остаётся видимым как индикатор состояния", new Point(23, 48), new Size(300, 23), 8F, Theme.TextMuted);
        overlayMock.Controls.AddRange(new Control[] { _overlayPreviewTitle, _overlayPreviewDetails });
        preview.Controls.Add(overlayMock);
        preview.Controls.Add(CreateLabel("Размер: 250 × 66 px  •  не принимает клики  •  не получает фокус", new Point(54, 218), new Size(350, 38), 8F, Theme.TextMuted));

        var settingsCard = CreateCard(new Point(500, 72), new Size(476, 310));
        settingsCard.Controls.Add(CreateCardTitle("НАСТРОЙКИ OVERLAY", new Point(18, 14)));
        settingsCard.Controls.Add(CreateLabel("ПОКАЗЫВАТЬ В ИГРЕ", new Point(20, 52), new Size(300, 26), 8.5F, Theme.TextSecondary, true));
        _overlayEnabledToggle = new ToggleSwitch { Location = new Point(408, 50) };
        _overlayEnabledToggle.CheckedChanged += (_, _) => OverlaySettingsChanged();
        settingsCard.Controls.Add(_overlayEnabledToggle);
        settingsCard.Controls.Add(CreateFieldCaption("УГОЛ ЭКРАНА", new Point(20, 99), new Size(420, 18)));
        _overlayCornerInput = CreateComboBox(new Point(20, 120), new Size(430, 31), "Top Left", "Top Right", "Bottom Left", "Bottom Right");
        _overlayCornerInput.SelectedIndexChanged += (_, _) => OverlaySettingsChanged();
        settingsCard.Controls.Add(_overlayCornerInput);
        settingsCard.Controls.Add(CreateFieldCaption("ПРОЗРАЧНОСТЬ", new Point(20, 174), new Size(300, 18)));
        _overlayOpacityLabel = CreateLabel("78%", new Point(382, 169), new Size(68, 25), 9F, Theme.TextPrimary, true);
        _overlayOpacityLabel.TextAlign = ContentAlignment.MiddleRight;
        settingsCard.Controls.Add(_overlayOpacityLabel);
        _overlayOpacityInput = new TrackBar
        {
            Location = new Point(14, 199),
            Size = new Size(442, 43),
            Minimum = 20,
            Maximum = 100,
            TickStyle = TickStyle.None,
            BackColor = Theme.Surface,
            SmallChange = 2,
            LargeChange = 10
        };
        _overlayOpacityInput.ValueChanged += (_, _) => OverlaySettingsChanged();
        settingsCard.Controls.Add(_overlayOpacityInput);
        settingsCard.Controls.Add(CreateLabel("OFF также отображается, чтобы состояние было видно без переключения окон.", new Point(20, 253), new Size(420, 40), 8F, Theme.TextMuted));

        var compatibility = CreateCard(new Point(28, 404), new Size(948, 176));
        compatibility.Controls.Add(CreateCardTitle("СОВМЕСТИМОСТЬ", new Point(18, 14)));
        compatibility.Controls.Add(CreateLabel(
            "✓ Minecraft Java / Bedrock: оконный и безрамочный полноэкранный режим\n" +
            "✓ Большинство игр, которые отображаются через композитор Windows 11\n" +
            "○ Эксклюзивный fullscreen может скрывать любой обычный topmost-overlay\n\n" +
            "Overlay — отдельное прозрачное окно. Он не внедряется в процесс игры, не скрывает приложение и не обходит античит.",
            new Point(22, 45),
            new Size(895, 112),
            8.7F,
            Theme.TextSecondary));
        page.Controls.AddRange(new Control[] { preview, settingsCard, compatibility });
        return page;
    }

    private Panel BuildBenchmarkPage()
    {
        var page = CreatePage();
        AddPageIntro(page, "ULTRA BENCHMARK", "Короткий безопасный тест генерации и доставки событий через SendInput");

        var intro = CreateCard(new Point(28, 72), new Size(948, 126));
        intro.Controls.Add(CreateCardTitle("КАК РАБОТАЕТ ТЕСТ", new Point(18, 14)));
        intro.Controls.Add(CreateLabel(
            "В течение 1.5 секунды worker создаёт и отправляет нейтральные mouse-move события с нулевым смещением. " +
            "Реальные клики не выполняются. Delivered events берётся из результата SendInput, а не из теоретической формулы.",
            new Point(20, 44),
            new Size(895, 62),
            8.7F,
            Theme.TextSecondary));

        var results = CreateCard(new Point(28, 216), new Size(600, 270));
        results.Controls.Add(CreateCardTitle("РЕЗУЛЬТАТ", new Point(18, 14)));
        AddBenchmarkMetric(results, "Event generation", 55, out _benchmarkGeneratedLabel);
        AddBenchmarkMetric(results, "Delivered events", 103, out _benchmarkDeliveredLabel);
        AddBenchmarkMetric(results, "Recommended minimum", 151, out _benchmarkMinimumLabel);
        results.Controls.Add(CreateFieldCaption("ОПТИМАЛЬНЫЙ ПРОФИЛЬ", new Point(20, 205), new Size(250, 18)));
        _benchmarkRecommendationLabel = CreateLabel("Сначала запустите benchmark", new Point(270, 199), new Size(305, 30), 9F, Theme.TextSecondary, true);
        _benchmarkRecommendationLabel.TextAlign = ContentAlignment.MiddleRight;
        results.Controls.Add(_benchmarkRecommendationLabel);

        var controls = CreateCard(new Point(646, 216), new Size(330, 270));
        controls.Controls.Add(CreateCardTitle("ЗАПУСК", new Point(18, 14)));
        _benchmarkRunButton = CreateButton("RUN BENCHMARK", new Point(22, 55), new Size(286, 55), ThemedButtonStyle.Primary);
        _benchmarkRunButton.Click += async (_, _) => await RunBenchmarkAsync();
        controls.Controls.Add(_benchmarkRunButton);
        _benchmarkProgress = new ProgressBar
        {
            Location = new Point(22, 127),
            Size = new Size(286, 12),
            Minimum = 0,
            Maximum = 100,
            Style = ProgressBarStyle.Continuous
        };
        controls.Controls.Add(_benchmarkProgress);
        _benchmarkApplyButton = CreateButton("APPLY OPTIMAL SETTINGS", new Point(22, 164), new Size(286, 48), ThemedButtonStyle.Secondary);
        _benchmarkApplyButton.Enabled = false;
        _benchmarkApplyButton.Click += (_, _) => ApplyBenchmarkSettings();
        controls.Controls.Add(_benchmarkApplyButton);
        controls.Controls.Add(CreateLabel("Применение отключает Burst/Random и выбирает Ultra batch по результату.", new Point(22, 222), new Size(286, 34), 7.5F, Theme.TextMuted));

        var note = CreateCard(new Point(28, 504), new Size(948, 92));
        note.Controls.Add(CreateLabel("ВАЖНО", new Point(20, 15), new Size(100, 22), 8F, Theme.Warning, true));
        note.Controls.Add(CreateLabel("Benchmark измеряет пропускную способность Windows на этом ПК. Игра всё равно может обрабатывать ввод реже — например, один раз за кадр или игровой tick.", new Point(20, 40), new Size(900, 38), 8.2F, Theme.TextSecondary));

        page.Controls.AddRange(new Control[] { intro, results, controls, note });
        return page;
    }

    private void CreateHotkeyRow(
        Control page,
        HotkeyAction action,
        int y,
        string title,
        string description)
    {
        var row = CreateCard(new Point(28, y), new Size(948, 88));
        row.Controls.Add(CreateLabel(title, new Point(18, 15), new Size(205, 23), 9F, action == HotkeyAction.Panic ? Theme.Accent : Theme.TextPrimary, true));
        row.Controls.Add(CreateLabel(description, new Point(18, 42), new Size(420, 29), 7.7F, Theme.TextMuted));
        var hotkeyLabel = CreateLabel("Не назначено", new Point(455, 24), new Size(205, 40), 9.5F, Theme.TextPrimary, true);
        hotkeyLabel.BackColor = Theme.SurfaceRaised;
        hotkeyLabel.TextAlign = ContentAlignment.MiddleCenter;
        _hotkeyLabels[action] = hotkeyLabel;
        row.Controls.Add(hotkeyLabel);
        var edit = CreateButton("ИЗМЕНИТЬ", new Point(675, 25), new Size(105, 38), action == HotkeyAction.Panic ? ThemedButtonStyle.Danger : ThemedButtonStyle.Secondary);
        edit.Click += (_, _) => EditHotkey(action);
        row.Controls.Add(edit);
        var mode = CreateComboBox(new Point(795, 28), new Size(132, 31), "Toggle", "Hold", "Press");
        if (action == HotkeyAction.Panic)
        {
            mode.SelectedIndex = (int)HotkeyTriggerMode.Press;
            mode.Enabled = false;
        }
        else
        {
            mode.SelectedIndexChanged += (_, _) =>
                SetHotkeyMode(action, (HotkeyTriggerMode)Math.Max(0, mode.SelectedIndex));
        }

        _hotkeyModeInputs[action] = mode;
        row.Controls.Add(mode);
        page.Controls.Add(row);
    }

    private void HotkeyOptionsChanged()
    {
        if (_loading)
        {
            return;
        }

        _settings.IgnoreExtraModifiers = _ignoreExtraModifiersToggle.Checked;
        _settings.SuppressHotkeys = _suppressHotkeysToggle.Checked;
        UpdateHookConfiguration();
        SaveSettings();
    }

    private void AddBenchmarkMetric(RoundedPanel card, string name, int y, out Label valueLabel)
    {
        card.Controls.Add(CreateLabel(name, new Point(20, y), new Size(255, 30), 9F, Theme.TextSecondary));
        valueLabel = CreateLabel("—", new Point(280, y), new Size(295, 30), 12F, Theme.TextPrimary, true);
        valueLabel.TextAlign = ContentAlignment.MiddleRight;
        card.Controls.Add(valueLabel);
        card.Controls.Add(new Panel
        {
            Location = new Point(20, y + 37),
            Size = new Size(555, 1),
            BackColor = Theme.BorderSoft
        });
    }

    private void BuildTray()
    {
        var trayMenu = new ContextMenuStrip
        {
            BackColor = Theme.Surface,
            ForeColor = Theme.TextPrimary,
            Renderer = new ToolStripProfessionalRenderer(new DarkColorTable())
        };
        trayMenu.Items.Add("Показать", null, (_, _) => RestoreFromTray());
        trayMenu.Items.Add("Запустить / остановить", null, (_, _) => ToggleClicking());
        trayMenu.Items.Add("Ultra Mode", null, (_, _) => ToggleUltraMode());
        trayMenu.Items.Add(new ToolStripSeparator());
        trayMenu.Items.Add("Emergency Stop", null, (_, _) =>
        {
            _clickEngine.PanicStop();
            _benchmarkCancellation?.Cancel();
            CompletePanicStop();
        });
        trayMenu.Items.Add("Выход", null, (_, _) => Close());
        _trayIcon = new NotifyIcon
        {
            Text = "AUTO CLICKER",
            Icon = SystemIcons.Application,
            Visible = false,
            ContextMenuStrip = trayMenu
        };
        _trayIcon.DoubleClick += (_, _) => RestoreFromTray();
    }

    private void RegisterPage(Control host, string name, Panel page)
    {
        page.Visible = false;
        _pages[name] = page;
        host.Controls.Add(page);
    }

    private void ShowPage(string name)
    {
        if (!_pages.TryGetValue(name, out var selectedPage))
        {
            return;
        }

        foreach (var page in _pages.Values)
        {
            page.Visible = ReferenceEquals(page, selectedPage);
        }

        foreach (var pair in _navButtons)
        {
            pair.Value.Selected = pair.Key == name;
            pair.Value.Invalidate();
        }

        _pageTitle.Text = name.ToUpperInvariant();
        selectedPage.BringToFront();
    }

    private void DragWindow(object? sender, MouseEventArgs e)
    {
        if (e.Button != MouseButtons.Left)
        {
            return;
        }

        NativeMethods.ReleaseCapture();
        NativeMethods.SendMessage(Handle, NativeMethods.WmNclbuttonDown, new IntPtr(NativeMethods.HtCaption), IntPtr.Zero);
    }

    private static Panel CreatePage()
    {
        return new Panel
        {
            Dock = DockStyle.Fill,
            BackColor = Theme.Background
        };
    }

    private static void AddPageIntro(Control page, string title, string subtitle)
    {
        page.Controls.Add(CreateLabel(title, new Point(28, 12), new Size(520, 24), 9F, Theme.TextPrimary, true));
        page.Controls.Add(CreateLabel(subtitle, new Point(28, 36), new Size(700, 20), 8F, Theme.TextMuted));
    }

    private static RoundedPanel CreateCard(Point location, Size size)
    {
        return new RoundedPanel
        {
            Location = location,
            Size = size,
            BackColor = Theme.Surface,
            BorderColor = Theme.BorderSoft,
            Radius = 10
        };
    }

    private static Label CreateCardTitle(string text, Point location)
        => CreateLabel(text, location, new Size(350, 22), 8F, Theme.TextSecondary, true);

    private static Label CreateFieldCaption(string text, Point location, Size size)
        => CreateLabel(text, location, size, 7.4F, Theme.TextMuted, true);

    private static Label CreateLabel(
        string text,
        Point location,
        Size size,
        float fontSize,
        Color color,
        bool semibold = false)
    {
        return new Label
        {
            Text = text,
            Location = location,
            Size = size,
            ForeColor = color,
            Font = Theme.Font(fontSize, semibold),
            BackColor = Color.Transparent,
            TextAlign = ContentAlignment.MiddleLeft
        };
    }

    private static ThemedButton CreateButton(
        string text,
        Point location,
        Size size,
        ThemedButtonStyle style)
    {
        return new ThemedButton
        {
            Text = text,
            Location = location,
            Size = size,
            ButtonStyle = style
        };
    }

    private static ComboBox CreateComboBox(Point location, Size size, params string[] items)
    {
        var combo = new ComboBox
        {
            Location = location,
            Size = size,
            DropDownStyle = ComboBoxStyle.DropDownList,
            BackColor = Theme.SurfaceRaised,
            ForeColor = Theme.TextPrimary,
            FlatStyle = FlatStyle.Flat,
            Font = Theme.Font(9F, true),
            DrawMode = DrawMode.OwnerDrawFixed,
            ItemHeight = 24
        };
        combo.Items.AddRange(items.Cast<object>().ToArray());
        combo.DrawItem += DrawComboItem;
        return combo;
    }

    private static void DrawComboItem(object? sender, DrawItemEventArgs e)
    {
        if (sender is not ComboBox combo || e.Index < 0)
        {
            return;
        }

        using var background = new SolidBrush(
            (e.State & DrawItemState.Selected) != 0 ? Theme.AccentMuted : Theme.SurfaceRaised);
        e.Graphics.FillRectangle(background, e.Bounds);
        TextRenderer.DrawText(
            e.Graphics,
            combo.Items[e.Index]?.ToString() ?? string.Empty,
            combo.Font,
            e.Bounds,
            Theme.TextPrimary,
            TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.EndEllipsis);
    }

    private static NumericUpDown CreateNumeric(
        Point location,
        Size size,
        decimal minimum,
        decimal maximum,
        int decimalPlaces = 0,
        decimal increment = 1)
    {
        return new NumericUpDown
        {
            Location = location,
            Size = size,
            Minimum = minimum,
            Maximum = maximum,
            DecimalPlaces = decimalPlaces,
            Increment = increment,
            BackColor = Theme.SurfaceRaised,
            ForeColor = Theme.TextPrimary,
            BorderStyle = BorderStyle.FixedSingle,
            TextAlign = HorizontalAlignment.Center,
            Font = Theme.Font(9F, true)
        };
    }

    private sealed class DarkColorTable : ProfessionalColorTable
    {
        public override Color ToolStripDropDownBackground => Theme.Surface;
        public override Color MenuItemSelected => Theme.AccentMuted;
        public override Color MenuItemBorder => Theme.AccentDark;
        public override Color ImageMarginGradientBegin => Theme.Surface;
        public override Color ImageMarginGradientMiddle => Theme.Surface;
        public override Color ImageMarginGradientEnd => Theme.Surface;
        public override Color SeparatorDark => Theme.Border;
        public override Color SeparatorLight => Theme.Border;
    }
}
