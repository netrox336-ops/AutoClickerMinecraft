using System.Drawing.Drawing2D;

namespace WinClicker.UI;

internal static class Theme
{
    internal static readonly Color Background = Color.FromArgb(13, 15, 19);
    internal static readonly Color Sidebar = Color.FromArgb(10, 12, 15);
    internal static readonly Color Surface = Color.FromArgb(20, 23, 28);
    internal static readonly Color SurfaceRaised = Color.FromArgb(27, 30, 37);
    internal static readonly Color SurfaceHover = Color.FromArgb(34, 37, 44);
    internal static readonly Color Border = Color.FromArgb(42, 45, 52);
    internal static readonly Color BorderSoft = Color.FromArgb(31, 34, 40);
    internal static readonly Color Accent = Color.FromArgb(255, 45, 32);
    internal static readonly Color AccentDark = Color.FromArgb(184, 15, 15);
    internal static readonly Color AccentMuted = Color.FromArgb(73, 22, 23);
    internal static readonly Color TextPrimary = Color.FromArgb(242, 242, 244);
    internal static readonly Color TextSecondary = Color.FromArgb(172, 173, 180);
    internal static readonly Color TextMuted = Color.FromArgb(119, 121, 129);
    internal static readonly Color Success = Color.FromArgb(62, 222, 133);
    internal static readonly Color Warning = Color.FromArgb(255, 183, 77);

    internal static Font Font(float size, bool semibold = false)
        => new("Segoe UI", size, semibold ? FontStyle.Bold : FontStyle.Regular, GraphicsUnit.Point);

    internal static GraphicsPath RoundedRectangle(Rectangle bounds, int radius)
    {
        var diameter = Math.Max(2, Math.Min(radius * 2, Math.Min(bounds.Width, bounds.Height)));
        var arc = new Rectangle(bounds.Location, new Size(diameter, diameter));
        var path = new GraphicsPath();
        path.AddArc(arc, 180, 90);
        arc.X = bounds.Right - diameter;
        path.AddArc(arc, 270, 90);
        arc.Y = bounds.Bottom - diameter;
        path.AddArc(arc, 0, 90);
        arc.X = bounds.Left;
        path.AddArc(arc, 90, 90);
        path.CloseFigure();
        return path;
    }
}
