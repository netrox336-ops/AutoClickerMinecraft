using System.Diagnostics;
using WinClicker.Models;
using WinClicker.Services;

namespace WinClicker.UI;

internal sealed partial class MainForm : Form
{
    private static readonly int[] UltraBatchValues = { 1, 4, 8, 16, 32 };
    private static readonly int[] BurstClickValues = { 2, 3, 5, 10 };

    private readonly SettingsStore _settingsStore = new();
    private readonly ClickEngine _clickEngine = new();
    private readonly OverlayForm _overlay = new();
    private readonly Process _process = Process.GetCurrentProcess();
    private readonly AppSettings _settings;
    private readonly Dictionary<string, Panel> _pages = new();
    private readonly Dictionary<string, ThemedButton> _navButtons = new();
    private readonly Dictionary<HotkeyAction, Label> _hotkeyLabels = new();
    private readonly Dictionary<HotkeyAction, ComboBox> _hotkeyModeInputs = new();

    private Label _pageTitle = null!;
    private Label _topStatusLabel = null!;
    private Label _statusLabel = null!;
    private Label _statusDetailLabel = null!;
    private Label _clickCountLabel = null!;
    private Label _rateLabel = null!;
    private Label _cpuLabel = null!;
    private Label _performanceActualLabel = null!;
    private Label _homeClickSummaryLabel = null!;
    private Label _homeBurstSummaryLabel = null!;
    private Label _homeRandomSummaryLabel = null!;
    private Label _homeHotkeyLabel = null!;
    private Label _homePanicLabel = null!;
    private ThemedButton _startStopButton = null!;

    private ThemedButton _leftButton = null!;
    private ThemedButton _rightButton = null!;
    private ComboBox _patternInput = null!;
    private NumericUpDown _intervalInput = null!;
    private ToggleSwitch _burstToggle = null!;
    private ComboBox _burstCountInput = null!;
    private NumericUpDown _burstIntervalInput = null!;
    private NumericUpDown _burstPauseInput = null!;
    private ComboBox _randomModeInput = null!;
    private NumericUpDown _randomMinInput = null!;
    private NumericUpDown _randomMaxInput = null!;
    private NumericUpDown _randomBaseInput = null!;
    private NumericUpDown _randomVariationInput = null!;
    private NumericUpDown _startDelayInput = null!;
    private NumericUpDown _clickLimitInput = null!;
    private ToggleSwitch _minimizeToTrayToggle = null!;

    private ComboBox _performanceInput = null!;
    private ComboBox _cpuPriorityInput = null!;
    private ComboBox _ultraBatchInput = null!;

    private ToggleSwitch _ignoreExtraModifiersToggle = null!;
    private ToggleSwitch _suppressHotkeysToggle = null!;

    private ToggleSwitch _overlayEnabledToggle = null!;
    private ComboBox _overlayCornerInput = null!;
    private TrackBar _overlayOpacityInput = null!;
    private Label _overlayOpacityLabel = null!;
    private Label _overlayPreviewTitle = null!;
    private Label _overlayPreviewDetails = null!;

    private Label _benchmarkGeneratedLabel = null!;
    private Label _benchmarkDeliveredLabel = null!;
    private Label _benchmarkMinimumLabel = null!;
    private Label _benchmarkRecommendationLabel = null!;
    private ProgressBar _benchmarkProgress = null!;
    private ThemedButton _benchmarkRunButton = null!;
    private ThemedButton _benchmarkApplyButton = null!;

    private NotifyIcon _trayIcon = null!;
    private System.Windows.Forms.Timer _statsTimer = null!;
    private GlobalInputHook? _inputHook;
    private CancellationTokenSource? _benchmarkCancellation;
    private BenchmarkResult? _benchmarkResult;
    private PerformanceMode? _performanceBeforeHold;
    private PerformanceMode? _oneShotPerformanceOverride;
    private bool _switchHeld;
    private bool _loading = true;
    private bool _closing;
    private bool _trayHintShown;
    private long _lastClicks;
    private long _lastStatsTimestamp;
    private TimeSpan _lastCpuTime;
    private double _currentClicksPerSecond;
    private double _currentCpuPercent;
    private DateTime _panicMessageUntilUtc;

    internal MainForm()
    {
        _settings = _settingsStore.Load();
        _settings.Normalize();

        Text = "AUTO CLICKER";
        ClientSize = new Size(1180, 760);
        StartPosition = FormStartPosition.CenterScreen;
        FormBorderStyle = FormBorderStyle.None;
        MaximizeBox = false;
        BackColor = Theme.Background;
        ForeColor = Theme.TextPrimary;
        Font = Theme.Font(9.5F);
        AutoScaleMode = AutoScaleMode.Dpi;
        DoubleBuffered = true;

        BuildLayout();
        BuildTray();
        ApplySettingsToInterface();
        _clickEngine.ApplySettings(_settings);
        _clickEngine.RunStopped += ClickEngineOnRunStopped;
        _loading = false;
        ApplyProcessPriority();
        UpdateAllVisuals();

        _statsTimer = new System.Windows.Forms.Timer { Interval = 250 };
        _statsTimer.Tick += (_, _) => UpdateStatistics();
        _lastStatsTimestamp = Stopwatch.GetTimestamp();
        _lastCpuTime = _process.TotalProcessorTime;
        _statsTimer.Start();

        Shown += (_, _) =>
        {
            InstallInputHook();
            _overlay.Configure(_settings);
            _overlay.UpdateState(false, _settings.ClickButton, _settings.Performance, 0);
        };
        Resize += (_, _) => MinimizeIfNeeded();
        FormClosing += MainFormClosing;
        MinimumSize = MaximumSize = Size;
    }

    private void InstallInputHook()
    {
        try
        {
            _inputHook = new GlobalInputHook();
            _inputHook.UpdateConfiguration(_settings);
            _inputHook.HotkeyChanged += InputHookOnHotkeyChanged;
            _inputHook.Start();
        }
        catch (Exception exception)
        {
            _inputHook?.Dispose();
            _inputHook = null;
            MessageBox.Show(
                this,
                $"Глобальные хоткеи не запущены. Управление из окна продолжит работать.\n\n{exception.Message}",
                "AUTO CLICKER",
                MessageBoxButtons.OK,
                MessageBoxIcon.Warning);
        }
    }

    private void ApplySettingsToInterface()
    {
        _loading = true;
        _settings.Normalize();
        _leftButton.Selected = _settings.ClickButton == ClickButton.Left;
        _rightButton.Selected = _settings.ClickButton == ClickButton.Right;
        _patternInput.SelectedIndex = Math.Clamp((int)_settings.Pattern - 1, 0, 2);
        _intervalInput.Value = _settings.IntervalMs;
        _burstToggle.Checked = _settings.BurstEnabled;
        _burstCountInput.SelectedIndex = Math.Max(0, Array.IndexOf(BurstClickValues, _settings.BurstClicks));
        _burstIntervalInput.Value = (decimal)_settings.BurstIntervalMs;
        _burstPauseInput.Value = _settings.BurstPauseMs;
        _randomModeInput.SelectedIndex = (int)_settings.RandomInterval;
        _randomMinInput.Value = _settings.RandomMinMs;
        _randomMaxInput.Value = _settings.RandomMaxMs;
        _randomBaseInput.Value = _settings.RandomBaseMs;
        _randomVariationInput.Value = _settings.RandomVariationMs;
        _startDelayInput.Value = _settings.StartDelayMs;
        _clickLimitInput.Value = _settings.ClickLimit;
        _minimizeToTrayToggle.Checked = _settings.MinimizeToTray;
        _performanceInput.SelectedIndex = (int)_settings.Performance;
        _cpuPriorityInput.SelectedIndex = (int)_settings.CpuPriority;
        _ultraBatchInput.SelectedIndex = Math.Max(0, Array.IndexOf(UltraBatchValues, _settings.UltraBatchSize));
        _ignoreExtraModifiersToggle.Checked = _settings.IgnoreExtraModifiers;
        _suppressHotkeysToggle.Checked = _settings.SuppressHotkeys;
        _overlayEnabledToggle.Checked = _settings.OverlayEnabled;
        _overlayCornerInput.SelectedIndex = (int)_settings.OverlayCorner;
        _overlayOpacityInput.Value = _settings.OverlayOpacityPercent;
        UpdateHotkeyLabels();
        UpdateHotkeyModeInputs();
        _loading = false;
    }

    private void ClickSettingsChanged()
    {
        if (_loading)
        {
            return;
        }

        _settings.Pattern = (ClickPattern)Math.Clamp(_patternInput.SelectedIndex + 1, 1, 3);
        _settings.IntervalMs = (int)_intervalInput.Value;
        _settings.BurstEnabled = _burstToggle.Checked;
        if (_burstCountInput.SelectedIndex >= 0)
        {
            _settings.BurstClicks = BurstClickValues[_burstCountInput.SelectedIndex];
        }

        _settings.BurstIntervalMs = (double)_burstIntervalInput.Value;
        _settings.BurstPauseMs = (int)_burstPauseInput.Value;
        _settings.RandomInterval = (RandomIntervalMode)Math.Max(0, _randomModeInput.SelectedIndex);
        _settings.RandomMinMs = (int)_randomMinInput.Value;
        _settings.RandomMaxMs = (int)_randomMaxInput.Value;
        _settings.RandomBaseMs = (int)_randomBaseInput.Value;
        _settings.RandomVariationMs = (int)_randomVariationInput.Value;
        _settings.StartDelayMs = (int)_startDelayInput.Value;
        _settings.ClickLimit = (int)_clickLimitInput.Value;
        _settings.MinimizeToTray = _minimizeToTrayToggle.Checked;
        _settings.Performance = (PerformanceMode)Math.Max(0, _performanceInput.SelectedIndex);
        _settings.UltraMode = _settings.Performance == PerformanceMode.Ultra;
        _settings.CpuPriority = (CpuPriorityMode)Math.Max(0, _cpuPriorityInput.SelectedIndex);
        if (_ultraBatchInput.SelectedIndex >= 0)
        {
            _settings.UltraBatchSize = UltraBatchValues[_ultraBatchInput.SelectedIndex];
        }

        ApplyEngineSettings();
    }

    private void SetClickButton(ClickButton button)
    {
        _settings.ClickButton = button;
        _leftButton.Selected = button == ClickButton.Left;
        _rightButton.Selected = button == ClickButton.Right;
        _leftButton.Invalidate();
        _rightButton.Invalidate();
        ApplyEngineSettings();
    }

    private void ApplyEngineSettings()
    {
        _settings.UltraMode = _settings.Performance == PerformanceMode.Ultra;
        _settings.Normalize();
        _clickEngine.ApplySettings(_settings);
        ApplyProcessPriority();
        UpdateAllVisuals();
        SaveSettings();
    }

    private void ApplyProcessPriority()
    {
        try
        {
            _process.PriorityClass = _settings.CpuPriority == CpuPriorityMode.High
                ? ProcessPriorityClass.AboveNormal
                : ProcessPriorityClass.Normal;
        }
        catch (Exception) when (OperatingSystem.IsWindows())
        {
            // Some managed PCs deny changing process priority; the worker priority still applies.
        }
    }

    private void ToggleClicking()
    {
        if (_clickEngine.IsRunning)
        {
            StopClicking();
        }
        else
        {
            StartClicking();
        }
    }

    private void StartClicking()
    {
        _panicMessageUntilUtc = default;
        _oneShotPerformanceOverride = null;
        if (_clickEngine.Start(_settings))
        {
            BeginStatisticsWindow();
        }

        UpdateStatus();
    }

    private void StopClicking()
    {
        _clickEngine.Stop();
        _oneShotPerformanceOverride = null;
        UpdateStatus();
    }

    private void TriggerOnce(PerformanceMode? forcedPerformance = null)
    {
        _panicMessageUntilUtc = default;
        _oneShotPerformanceOverride = forcedPerformance;
        if (_clickEngine.TriggerOnce(_settings, forcedPerformance))
        {
            BeginStatisticsWindow();
        }
        else
        {
            _oneShotPerformanceOverride = null;
        }

        UpdateStatus();
    }

    private void BeginStatisticsWindow()
    {
        _lastClicks = 0;
        _lastStatsTimestamp = Stopwatch.GetTimestamp();
        _lastCpuTime = _process.TotalProcessorTime;
    }

    private void SwitchMouseButton()
    {
        SetClickButton(_settings.ClickButton == ClickButton.Left ? ClickButton.Right : ClickButton.Left);
    }

    private void ToggleUltraMode()
    {
        SetPerformance(_settings.Performance == PerformanceMode.Ultra
            ? PerformanceMode.Normal
            : PerformanceMode.Ultra);
    }

    private void SetPerformance(PerformanceMode performance)
    {
        _settings.Performance = performance;
        _settings.UltraMode = performance == PerformanceMode.Ultra;
        _loading = true;
        _performanceInput.SelectedIndex = (int)performance;
        _loading = false;
        ApplyEngineSettings();
    }

    private void InputHookOnHotkeyChanged(object? sender, GlobalHotkeyEventArgs e)
    {
        if (_closing)
        {
            return;
        }

        if (e.Action == HotkeyAction.Panic && e.Signal == HotkeySignal.Pressed)
        {
            _clickEngine.PanicStop();
            _benchmarkCancellation?.Cancel();
            QueueOnUi(CompletePanicStop);
            return;
        }

        QueueOnUi(() => HandleHotkey(e.Action, e.Signal));
    }

    private void HandleHotkey(HotkeyAction action, HotkeySignal signal)
    {
        if (_closing)
        {
            return;
        }

        switch (action)
        {
            case HotkeyAction.Clicker:
                HandleClickerHotkey(signal);
                break;
            case HotkeyAction.SwitchButton:
                HandleSwitchHotkey(signal);
                break;
            case HotkeyAction.UltraMode:
                HandleUltraHotkey(signal);
                break;
        }
    }

    private void HandleClickerHotkey(HotkeySignal signal)
    {
        switch (_settings.ToggleHotkeyMode)
        {
            case HotkeyTriggerMode.Hold:
                if (signal == HotkeySignal.Pressed)
                {
                    StartClicking();
                }
                else
                {
                    StopClicking();
                }

                break;
            case HotkeyTriggerMode.Press when signal == HotkeySignal.Pressed:
                TriggerOnce();
                break;
            case HotkeyTriggerMode.Toggle when signal == HotkeySignal.Pressed:
                ToggleClicking();
                break;
        }
    }

    private void HandleSwitchHotkey(HotkeySignal signal)
    {
        if (_settings.SwitchButtonHotkeyMode == HotkeyTriggerMode.Hold)
        {
            if (signal == HotkeySignal.Pressed && !_switchHeld)
            {
                _switchHeld = true;
                SwitchMouseButton();
            }
            else if (signal == HotkeySignal.Released && _switchHeld)
            {
                _switchHeld = false;
                SwitchMouseButton();
            }

            return;
        }

        if (signal == HotkeySignal.Pressed)
        {
            SwitchMouseButton();
        }
    }

    private void HandleUltraHotkey(HotkeySignal signal)
    {
        switch (_settings.UltraHotkeyMode)
        {
            case HotkeyTriggerMode.Hold:
                if (signal == HotkeySignal.Pressed && _performanceBeforeHold is null)
                {
                    _performanceBeforeHold = _settings.Performance;
                    SetPerformance(PerformanceMode.Ultra);
                }
                else if (signal == HotkeySignal.Released && _performanceBeforeHold is { } previous)
                {
                    _performanceBeforeHold = null;
                    SetPerformance(previous);
                }

                break;
            case HotkeyTriggerMode.Press when signal == HotkeySignal.Pressed:
                TriggerOnce(PerformanceMode.Ultra);
                break;
            case HotkeyTriggerMode.Toggle when signal == HotkeySignal.Pressed:
                ToggleUltraMode();
                break;
        }
    }

    private void CompletePanicStop()
    {
        _performanceBeforeHold = null;
        _oneShotPerformanceOverride = null;
        _switchHeld = false;
        _settings.Performance = PerformanceMode.Normal;
        _settings.UltraMode = false;
        _settings.CpuPriority = CpuPriorityMode.Normal;
        _panicMessageUntilUtc = DateTime.UtcNow.AddSeconds(2.5);
        _currentClicksPerSecond = 0;

        _loading = true;
        _performanceInput.SelectedIndex = (int)PerformanceMode.Normal;
        _cpuPriorityInput.SelectedIndex = (int)CpuPriorityMode.Normal;
        _loading = false;
        _clickEngine.ApplySettings(_settings);
        ApplyProcessPriority();
        SaveSettings();
        UpdateAllVisuals();
    }

    private void QueueOnUi(Action action)
    {
        if (_closing || !IsHandleCreated)
        {
            return;
        }

        try
        {
            BeginInvoke(action);
        }
        catch (InvalidOperationException)
        {
            // The window is already closing.
        }
    }

    private void EditHotkey(HotkeyAction action)
    {
        StopClicking();
        var current = GetHotkey(action);
        var actionName = action switch
        {
            HotkeyAction.Clicker => "Запуск кликера",
            HotkeyAction.SwitchButton => "Смена LMB / RMB",
            HotkeyAction.UltraMode => "Ultra Mode",
            _ => "Emergency Stop"
        };

        if (_inputHook is not null)
        {
            _inputHook.Suspended = true;
        }

        using var dialog = new HotkeyCaptureDialog(actionName, current);
        EventHandler<HotkeyBinding>? mouseCaptureHandler = null;
        if (_inputHook is not null)
        {
            mouseCaptureHandler = (_, binding) => dialog.AcceptBinding(binding);
            _inputHook.MouseBindingCaptured += mouseCaptureHandler;
        }

        try
        {
            if (dialog.ShowDialog(this) != DialogResult.OK)
            {
                return;
            }

            var candidate = dialog.SelectedHotkey;
            if (action == HotkeyAction.Panic && candidate.IsDisabled)
            {
                MessageBox.Show(this, "Panic Key нельзя отключить.", "AUTO CLICKER", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            if (!candidate.IsDisabled && IsUsedByOtherAction(action, candidate))
            {
                MessageBox.Show(this, "Эта комбинация уже назначена другому действию.", "AUTO CLICKER", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            SetHotkey(action, candidate);
            _settings.Normalize();
            UpdateHotkeyLabels();
            UpdateHookConfiguration();
            SaveSettings();
        }
        finally
        {
            if (_inputHook is not null)
            {
                if (mouseCaptureHandler is not null)
                {
                    _inputHook.MouseBindingCaptured -= mouseCaptureHandler;
                }

                _inputHook.Suspended = false;
            }
        }
    }

    private HotkeyBinding GetHotkey(HotkeyAction action)
    {
        return action switch
        {
            HotkeyAction.Clicker => _settings.ToggleHotkey,
            HotkeyAction.SwitchButton => _settings.SwitchButtonHotkey,
            HotkeyAction.UltraMode => _settings.UltraHotkey,
            _ => _settings.PanicHotkey
        };
    }

    private void SetHotkey(HotkeyAction action, HotkeyBinding binding)
    {
        switch (action)
        {
            case HotkeyAction.Clicker:
                _settings.ToggleHotkey = binding;
                break;
            case HotkeyAction.SwitchButton:
                _settings.SwitchButtonHotkey = binding;
                break;
            case HotkeyAction.UltraMode:
                _settings.UltraHotkey = binding;
                break;
            case HotkeyAction.Panic:
                _settings.PanicHotkey = binding;
                break;
        }
    }

    private HotkeyTriggerMode GetHotkeyMode(HotkeyAction action)
    {
        return action switch
        {
            HotkeyAction.Clicker => _settings.ToggleHotkeyMode,
            HotkeyAction.SwitchButton => _settings.SwitchButtonHotkeyMode,
            HotkeyAction.UltraMode => _settings.UltraHotkeyMode,
            _ => HotkeyTriggerMode.Press
        };
    }

    private void SetHotkeyMode(HotkeyAction action, HotkeyTriggerMode mode)
    {
        if (_loading || action == HotkeyAction.Panic)
        {
            return;
        }

        switch (action)
        {
            case HotkeyAction.Clicker:
                _settings.ToggleHotkeyMode = mode;
                break;
            case HotkeyAction.SwitchButton:
                _settings.SwitchButtonHotkeyMode = mode;
                break;
            case HotkeyAction.UltraMode:
                _settings.UltraHotkeyMode = mode;
                break;
        }

        SaveSettings();
        UpdateAllVisuals();
    }

    private bool IsUsedByOtherAction(HotkeyAction currentAction, HotkeyBinding candidate)
    {
        return Enum.GetValues<HotkeyAction>()
            .Any(action => action != currentAction && candidate.Equals(GetHotkey(action)));
    }

    private void UpdateHookConfiguration() => _inputHook?.UpdateConfiguration(_settings);

    private void UpdateHotkeyLabels()
    {
        foreach (var action in Enum.GetValues<HotkeyAction>())
        {
            if (_hotkeyLabels.TryGetValue(action, out var label))
            {
                label.Text = GetHotkey(action).ToDisplayString();
            }
        }
    }

    private void UpdateHotkeyModeInputs()
    {
        foreach (var pair in _hotkeyModeInputs)
        {
            pair.Value.SelectedIndex = (int)GetHotkeyMode(pair.Key);
        }
    }

    private void OverlaySettingsChanged()
    {
        if (_loading)
        {
            return;
        }

        _settings.OverlayEnabled = _overlayEnabledToggle.Checked;
        _settings.OverlayCorner = (OverlayCorner)Math.Max(0, _overlayCornerInput.SelectedIndex);
        _settings.OverlayOpacityPercent = _overlayOpacityInput.Value;
        _settings.Normalize();
        _overlayOpacityLabel.Text = $"{_settings.OverlayOpacityPercent}%";
        _overlay.Configure(_settings);
        UpdateOverlayPreview();
        SaveSettings();
    }

    private async Task RunBenchmarkAsync()
    {
        if (_benchmarkCancellation is not null)
        {
            return;
        }

        StopClicking();
        _benchmarkCancellation = new CancellationTokenSource();
        _benchmarkRunButton.Enabled = false;
        _benchmarkApplyButton.Enabled = false;
        _benchmarkProgress.Value = 0;
        _benchmarkGeneratedLabel.Text = "—";
        _benchmarkDeliveredLabel.Text = "—";
        _benchmarkMinimumLabel.Text = "—";
        _benchmarkRecommendationLabel.Text = "Тест выполняется…";
        var progress = new Progress<int>(value => _benchmarkProgress.Value = Math.Clamp(value, 0, 100));

        try
        {
            _benchmarkResult = await UltraBenchmark.RunAsync(
                TimeSpan.FromMilliseconds(1500),
                progress,
                _benchmarkCancellation.Token);
            _benchmarkGeneratedLabel.Text = $"{_benchmarkResult.GeneratedEventsPerSecond:N0}/s";
            _benchmarkDeliveredLabel.Text = $"{_benchmarkResult.DeliveredEventsPerSecond:N0}/s";
            _benchmarkMinimumLabel.Text = $"{_benchmarkResult.RecommendedMinimumMs:0.00} ms";
            _benchmarkRecommendationLabel.Text = $"ULTRA ×{_benchmarkResult.RecommendedBatchSize} • безопасный запас 15%";
            _benchmarkApplyButton.Enabled = _benchmarkResult.DeliveredEventsPerSecond > 0;
        }
        catch (OperationCanceledException)
        {
            if (!_closing)
            {
                _benchmarkRecommendationLabel.Text = "Тест остановлен Panic Key";
            }
        }
        catch (Exception exception)
        {
            if (!_closing)
            {
                _benchmarkRecommendationLabel.Text = "Benchmark не выполнен";
                MessageBox.Show(this, exception.Message, "AUTO CLICKER", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
        finally
        {
            _benchmarkCancellation?.Dispose();
            _benchmarkCancellation = null;
            if (!_closing)
            {
                _benchmarkRunButton.Enabled = true;
            }
        }
    }

    private void ApplyBenchmarkSettings()
    {
        if (_benchmarkResult is null)
        {
            return;
        }

        _settings.Performance = PerformanceMode.Ultra;
        _settings.UltraMode = true;
        _settings.UltraBatchSize = _benchmarkResult.RecommendedBatchSize;
        _settings.CpuPriority = _benchmarkResult.DeliveredEventsPerSecond < 25_000
            ? CpuPriorityMode.High
            : CpuPriorityMode.Normal;
        _settings.IntervalMs = Math.Clamp((int)Math.Ceiling(_benchmarkResult.RecommendedMinimumMs), 1, 1000);
        _settings.BurstEnabled = false;
        _settings.RandomInterval = RandomIntervalMode.Off;
        ApplySettingsToInterface();
        ApplyEngineSettings();
        ShowPage("Главная");
    }

    private void UpdateStatistics()
    {
        var now = Stopwatch.GetTimestamp();
        var elapsedSeconds = (now - _lastStatsTimestamp) / (double)Stopwatch.Frequency;
        if (elapsedSeconds <= 0)
        {
            return;
        }

        var clicks = _clickEngine.SessionClicks;
        var difference = Math.Max(0, clicks - _lastClicks);
        _currentClicksPerSecond = _clickEngine.IsRunning ? difference / elapsedSeconds : 0;

        var cpuTime = _process.TotalProcessorTime;
        var cpuSeconds = Math.Max(0, (cpuTime - _lastCpuTime).TotalSeconds);
        _currentCpuPercent = Math.Clamp(
            cpuSeconds / elapsedSeconds / Math.Max(1, Environment.ProcessorCount) * 100d,
            0,
            100);

        _lastClicks = clicks;
        _lastStatsTimestamp = now;
        _lastCpuTime = cpuTime;
        _clickCountLabel.Text = $"{clicks:N0}";
        _rateLabel.Text = $"{_currentClicksPerSecond:N0} CPS";
        _cpuLabel.Text = $"CPU {_currentCpuPercent:0.0}%";
        _performanceActualLabel.Text = $"Current rate: ~{_currentClicksPerSecond:N0} clicks/sec   •   CPU: {_currentCpuPercent:0.0}%";
        UpdateStatus();
        UpdateOverlayPreview();
    }

    private void UpdateAllVisuals()
    {
        UpdateAvailability();
        UpdateSummaries();
        UpdateStatus();
        UpdateOverlayPreview();
        _overlayOpacityLabel.Text = $"{_settings.OverlayOpacityPercent}%";
        if (IsHandleCreated)
        {
            _overlay.Configure(_settings);
        }
    }

    private void UpdateAvailability()
    {
        var randomEnabled = _settings.RandomInterval != RandomIntervalMode.Off;
        _patternInput.Enabled = !_settings.BurstEnabled;
        _intervalInput.Enabled = !_settings.BurstEnabled
            && _settings.Performance != PerformanceMode.Ultra
            && !randomEnabled;
        _burstCountInput.Enabled = _settings.BurstEnabled;
        _burstPauseInput.Enabled = _settings.BurstEnabled;
        _burstIntervalInput.Enabled = _settings.BurstEnabled && !randomEnabled;
        _randomModeInput.Enabled = _settings.Performance != PerformanceMode.Ultra || _settings.BurstEnabled;
        _randomMinInput.Enabled = _settings.RandomInterval == RandomIntervalMode.Range;
        _randomMaxInput.Enabled = _settings.RandomInterval == RandomIntervalMode.Range;
        _randomBaseInput.Enabled = _settings.RandomInterval == RandomIntervalMode.Variation;
        _randomVariationInput.Enabled = _settings.RandomInterval == RandomIntervalMode.Variation;
        _ultraBatchInput.Enabled = _settings.Performance == PerformanceMode.Ultra && !_settings.BurstEnabled;
    }

    private void UpdateSummaries()
    {
        var button = _settings.ClickButton == ClickButton.Left ? "LMB" : "RMB";
        var pattern = _settings.Pattern switch
        {
            ClickPattern.Double => "DOUBLE",
            ClickPattern.Triple => "TRIPLE",
            _ => "SINGLE"
        };
        _homeClickSummaryLabel.Text = $"{button}  •  {(_settings.BurstEnabled ? "BURST" : pattern)}";
        _homeBurstSummaryLabel.Text = _settings.BurstEnabled
            ? $"{_settings.BurstClicks} кликов × {_settings.BurstIntervalMs:0.##} ms  →  пауза {_settings.BurstPauseMs} ms"
            : "Burst Mode выключен";
        _homeRandomSummaryLabel.Text = _settings.RandomInterval switch
        {
            RandomIntervalMode.Range => $"Random {_settings.RandomMinMs}–{_settings.RandomMaxMs} ms",
            RandomIntervalMode.Variation => $"Base {_settings.RandomBaseMs} ms  •  Variation ±{_settings.RandomVariationMs} ms",
            _ => $"Фиксированный интервал {_settings.IntervalMs} ms"
        };
        _homeHotkeyLabel.Text = _settings.ToggleHotkey.ToDisplayString();
        _homePanicLabel.Text = $"PANIC: {_settings.PanicHotkey.ToDisplayString()}";
        _leftButton.Selected = _settings.ClickButton == ClickButton.Left;
        _rightButton.Selected = _settings.ClickButton == ClickButton.Right;
        _leftButton.Invalidate();
        _rightButton.Invalidate();
    }

    private void UpdateStatus()
    {
        var panicVisible = DateTime.UtcNow < _panicMessageUntilUtc;
        var running = _clickEngine.IsRunning && !panicVisible;
        _statusLabel.Text = running ? "●  РАБОТАЕТ" : "○  ОСТАНОВЛЕН";
        _statusLabel.ForeColor = running ? Theme.Accent : Theme.TextSecondary;
        _topStatusLabel.Text = running ? "● ACTIVE" : "● READY";
        _topStatusLabel.ForeColor = running ? Theme.Accent : Theme.Success;
        _startStopButton.Text = running ? "■  ОСТАНОВИТЬ" : "▶  ЗАПУСТИТЬ";
        _startStopButton.ButtonStyle = running ? ThemedButtonStyle.Danger : ThemedButtonStyle.Primary;
        _startStopButton.Invalidate();

        var displayedPerformance = running && _oneShotPerformanceOverride is { } forced
            ? forced
            : _settings.Performance;
        _statusDetailLabel.Text = !running && panicVisible
            ? "EMERGENCY STOP • очередь сброшена • кнопки отпущены"
            : $"{displayedPerformance.ToString().ToUpperInvariant()}  •  {GetHotkeyMode(HotkeyAction.Clicker).ToString().ToUpperInvariant()}";
        _trayIcon.Text = running ? "AUTO CLICKER — работает" : "AUTO CLICKER — остановлен";
        _overlay.UpdateState(running, _settings.ClickButton, displayedPerformance, _currentClicksPerSecond);
    }

    private void UpdateOverlayPreview()
    {
        var running = _clickEngine.IsRunning && DateTime.UtcNow >= _panicMessageUntilUtc;
        _overlayPreviewTitle.Text = running ? "●  AUTO CLICKER" : "○  OFF";
        _overlayPreviewTitle.ForeColor = running ? Theme.TextPrimary : Theme.TextSecondary;
        var performance = _oneShotPerformanceOverride ?? _settings.Performance;
        _overlayPreviewDetails.Text = running
            ? $"{(_settings.ClickButton == ClickButton.Left ? "LMB" : "RMB")}  •  {performance.ToString().ToUpperInvariant()}  •  {_currentClicksPerSecond:N0} CPS"
            : "Overlay остаётся видимым как индикатор состояния";
    }

    private void ClickEngineOnRunStopped(object? sender, EventArgs e)
    {
        QueueOnUi(() =>
        {
            _oneShotPerformanceOverride = null;
            UpdateStatus();
        });
    }

    private void ResetStatistics()
    {
        _clickEngine.ResetStatistics();
        _lastClicks = 0;
        _currentClicksPerSecond = 0;
        _clickCountLabel.Text = "0";
        _rateLabel.Text = "0 CPS";
        UpdateStatus();
    }

    private void MinimizeIfNeeded()
    {
        if (_closing || WindowState != FormWindowState.Minimized || !_settings.MinimizeToTray)
        {
            return;
        }

        Hide();
        _trayIcon.Visible = true;
        if (!_trayHintShown)
        {
            _trayHintShown = true;
            _trayIcon.ShowBalloonTip(1800, "AUTO CLICKER", "Приложение продолжает работать в трее.", ToolTipIcon.Info);
        }
    }

    private void RestoreFromTray()
    {
        Show();
        WindowState = FormWindowState.Normal;
        Activate();
        _trayIcon.Visible = false;
    }

    private void MainFormClosing(object? sender, FormClosingEventArgs e)
    {
        _closing = true;
        _benchmarkCancellation?.Cancel();
        _statsTimer.Stop();
        _statsTimer.Dispose();
        _clickEngine.RunStopped -= ClickEngineOnRunStopped;
        _clickEngine.Dispose();
        _inputHook?.Dispose();
        _overlay.Close();
        _overlay.Dispose();
        _trayIcon.Visible = false;
        _trayIcon.Dispose();
        SaveSettings();
        _process.Dispose();
    }

    private void SaveSettings() => _settingsStore.Save(_settings);
}
