using System.Drawing.Drawing2D;
using WinClicker.Models;

namespace WinClicker.UI;

internal sealed class OverlayForm : Form
{
    private bool _running;
    private ClickButton _button = ClickButton.Left;
    private PerformanceMode _performance = PerformanceMode.Normal;
    private double _clicksPerSecond;
    private OverlayCorner _corner = OverlayCorner.TopRight;

    internal OverlayForm()
    {
        FormBorderStyle = FormBorderStyle.None;
        StartPosition = FormStartPosition.Manual;
        ShowInTaskbar = false;
        TopMost = true;
        BackColor = Theme.Surface;
        ClientSize = new Size(250, 66);
        DoubleBuffered = true;
        Font = Theme.Font(9F);
    }

    protected override bool ShowWithoutActivation => true;

    protected override CreateParams CreateParams
    {
        get
        {
            const int wsExTransparent = 0x00000020;
            const int wsExToolWindow = 0x00000080;
            const int wsExLayered = 0x00080000;
            const int wsExNoActivate = 0x08000000;
            var parameters = base.CreateParams;
            parameters.ExStyle |= wsExTransparent | wsExToolWindow | wsExLayered | wsExNoActivate;
            return parameters;
        }
    }

    internal void Configure(AppSettings settings)
    {
        _corner = settings.OverlayCorner;
        Opacity = Math.Clamp(settings.OverlayOpacityPercent / 100d, 0.2d, 1d);
        Reposition();

        if (settings.OverlayEnabled)
        {
            if (!Visible)
            {
                Show();
            }
        }
        else if (Visible)
        {
            Hide();
        }
    }

    internal void UpdateState(
        bool running,
        ClickButton button,
        PerformanceMode performance,
        double clicksPerSecond)
    {
        _running = running;
        _button = button;
        _performance = performance;
        _clicksPerSecond = Math.Max(0, clicksPerSecond);
        Invalidate();
    }

    internal void Reposition()
    {
        var area = Screen.PrimaryScreen?.WorkingArea ?? new Rectangle(0, 0, 1920, 1080);
        const int margin = 18;
        var x = _corner is OverlayCorner.TopRight or OverlayCorner.BottomRight
            ? area.Right - Width - margin
            : area.Left + margin;
        var y = _corner is OverlayCorner.BottomLeft or OverlayCorner.BottomRight
            ? area.Bottom - Height - margin
            : area.Top + margin;
        Location = new Point(x, y);
    }

    protected override void OnResize(EventArgs e)
    {
        base.OnResize(e);
        if (Width <= 1 || Height <= 1)
        {
            return;
        }

        using var path = Theme.RoundedRectangle(new Rectangle(0, 0, Width, Height), 11);
        Region?.Dispose();
        Region = new Region(path);
    }

    protected override void OnPaint(PaintEventArgs e)
    {
        e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
        var bounds = new Rectangle(0, 0, Width - 1, Height - 1);
        using var path = Theme.RoundedRectangle(bounds, 11);
        using var background = new SolidBrush(Theme.Surface);
        using var border = new Pen(_running ? Theme.AccentDark : Theme.Border);
        e.Graphics.FillPath(background, path);
        e.Graphics.DrawPath(border, path);

        var dotColor = _running ? Theme.Accent : Theme.TextMuted;
        using var dot = new SolidBrush(dotColor);
        e.Graphics.FillEllipse(dot, 15, 17, 8, 8);

        if (!_running)
        {
            using var offFont = Theme.Font(10F, semibold: true);
            using var offCaptionFont = Theme.Font(8F);
            TextRenderer.DrawText(
                e.Graphics,
                "OFF",
                offFont,
                new Rectangle(31, 11, 90, 26),
                Theme.TextSecondary,
                TextFormatFlags.Left | TextFormatFlags.VerticalCenter);
            TextRenderer.DrawText(
                e.Graphics,
                "AUTO CLICKER",
                offCaptionFont,
                new Rectangle(31, 34, 150, 18),
                Theme.TextMuted,
                TextFormatFlags.Left | TextFormatFlags.VerticalCenter);
            return;
        }

        using var titleFont = Theme.Font(9.5F, semibold: true);
        using var detailsFont = Theme.Font(8.2F);
        TextRenderer.DrawText(
            e.Graphics,
            "AUTO CLICKER",
            titleFont,
            new Rectangle(31, 9, 190, 23),
            Theme.TextPrimary,
            TextFormatFlags.Left | TextFormatFlags.VerticalCenter);
        var buttonText = _button == ClickButton.Left ? "LMB" : "RMB";
        var performanceText = _performance.ToString().ToUpperInvariant();
        var details = $"{buttonText}  •  {performanceText}  •  {_clicksPerSecond:N0} CPS";
        TextRenderer.DrawText(
            e.Graphics,
            details,
            detailsFont,
            new Rectangle(31, 34, 205, 20),
            Theme.TextSecondary,
            TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.EndEllipsis);
    }
}
