using WinClicker.Models;

namespace WinClicker.UI;

internal sealed class HotkeyCaptureDialog : Form
{
    private readonly Label _capturedLabel;

    internal HotkeyCaptureDialog(string actionName, HotkeyBinding current)
    {
        SelectedHotkey = current.Clone();

        Text = "Назначить горячую клавишу";
        ClientSize = new Size(500, 270);
        MinimumSize = MaximumSize = Size;
        StartPosition = FormStartPosition.CenterParent;
        FormBorderStyle = FormBorderStyle.FixedDialog;
        MaximizeBox = false;
        MinimizeBox = false;
        ShowInTaskbar = false;
        KeyPreview = true;
        BackColor = Theme.Background;
        ForeColor = Theme.TextPrimary;
        Font = Theme.Font(9.5F);

        var accent = new Panel
        {
            Dock = DockStyle.Top,
            Height = 3,
            BackColor = Theme.Accent
        };
        var title = CreateLabel(actionName, new Point(24, 20), new Size(445, 30), 14F, Theme.TextPrimary, true);
        var hint = CreateLabel(
            "Нажмите клавишу, Mouse 3, Mouse 4 или Mouse 5.\nEsc — отмена, Delete — очистить назначение.",
            new Point(25, 58),
            new Size(450, 48),
            9F,
            Theme.TextSecondary);

        var captureCard = new RoundedPanel
        {
            Location = new Point(24, 112),
            Size = new Size(452, 60),
            BackColor = Theme.Surface,
            BorderColor = Theme.AccentDark
        };
        _capturedLabel = CreateLabel(
            current.ToDisplayString(),
            new Point(8, 8),
            new Size(436, 44),
            13F,
            Theme.Accent,
            true);
        _capturedLabel.TextAlign = ContentAlignment.MiddleCenter;
        captureCard.Controls.Add(_capturedLabel);

        var clearButton = CreateButton("Очистить", new Point(174, 205), new Size(94, 38), ThemedButtonStyle.Ghost);
        clearButton.Click += (_, _) =>
        {
            SelectedHotkey = HotkeyBinding.Disabled();
            DialogResult = DialogResult.OK;
            Close();
        };

        var cancelButton = CreateButton("Отмена", new Point(278, 205), new Size(94, 38), ThemedButtonStyle.Secondary);
        cancelButton.DialogResult = DialogResult.Cancel;

        var keepButton = CreateButton("Оставить", new Point(382, 205), new Size(94, 38), ThemedButtonStyle.Primary);
        keepButton.Click += (_, _) =>
        {
            DialogResult = DialogResult.OK;
            Close();
        };

        Controls.AddRange(new Control[] { accent, title, hint, captureCard, clearButton, cancelButton, keepButton });
        CancelButton = cancelButton;
    }

    internal HotkeyBinding SelectedHotkey { get; private set; }

    internal void AcceptBinding(HotkeyBinding binding)
    {
        if (IsDisposed)
        {
            return;
        }

        if (InvokeRequired)
        {
            BeginInvoke(new Action(() => AcceptBinding(binding)));
            return;
        }

        SelectedHotkey = binding.Clone();
        _capturedLabel.Text = SelectedHotkey.ToDisplayString();
        DialogResult = DialogResult.OK;
        Close();
    }

    protected override void OnKeyDown(KeyEventArgs e)
    {
        base.OnKeyDown(e);
        if (e.KeyCode == Keys.Escape && e.Modifiers == Keys.None)
        {
            DialogResult = DialogResult.Cancel;
            Close();
            return;
        }

        if (e.KeyCode == Keys.Delete && e.Modifiers == Keys.None)
        {
            SelectedHotkey = HotkeyBinding.Disabled();
            DialogResult = DialogResult.OK;
            Close();
            return;
        }

        if (HotkeyBinding.IsModifierKey(e.KeyCode))
        {
            _capturedLabel.Text = "Добавьте обычную клавишу…";
            e.Handled = true;
            e.SuppressKeyPress = true;
            return;
        }

        var binding = HotkeyBinding.FromKey(
            e.KeyCode,
            e.Control,
            e.Alt,
            e.Shift,
            NativeMethods.IsKeyDown(NativeMethods.VkLWin) || NativeMethods.IsKeyDown(NativeMethods.VkRWin));
        e.Handled = true;
        e.SuppressKeyPress = true;
        AcceptBinding(binding);
    }

    private static Label CreateLabel(
        string text,
        Point location,
        Size size,
        float fontSize,
        Color color,
        bool semibold = false)
    {
        return new Label
        {
            Text = text,
            Location = location,
            Size = size,
            ForeColor = color,
            Font = Theme.Font(fontSize, semibold),
            TextAlign = ContentAlignment.MiddleLeft
        };
    }

    private static ThemedButton CreateButton(
        string text,
        Point location,
        Size size,
        ThemedButtonStyle style)
    {
        return new ThemedButton
        {
            Text = text,
            Location = location,
            Size = size,
            ButtonStyle = style
        };
    }
}
