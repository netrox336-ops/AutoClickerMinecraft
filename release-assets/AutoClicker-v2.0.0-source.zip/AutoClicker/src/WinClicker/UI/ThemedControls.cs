using System.Drawing.Drawing2D;

namespace WinClicker.UI;

internal sealed class RoundedPanel : Panel
{
    internal RoundedPanel()
    {
        DoubleBuffered = true;
        BackColor = Theme.Surface;
        BorderColor = Theme.BorderSoft;
        Radius = 10;
    }

    internal Color BorderColor { get; set; }
    internal int Radius { get; set; }

    protected override void OnResize(EventArgs eventargs)
    {
        base.OnResize(eventargs);
        if (Width <= 1 || Height <= 1)
        {
            return;
        }

        using var path = Theme.RoundedRectangle(new Rectangle(0, 0, Width, Height), Radius);
        Region?.Dispose();
        Region = new Region(path);
    }

    protected override void OnPaint(PaintEventArgs e)
    {
        e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
        using var path = Theme.RoundedRectangle(new Rectangle(0, 0, Width - 1, Height - 1), Radius);
        using var fill = new SolidBrush(BackColor);
        using var border = new Pen(BorderColor);
        e.Graphics.FillPath(fill, path);
        e.Graphics.DrawPath(border, path);
    }
}

internal enum ThemedButtonStyle
{
    Primary,
    Secondary,
    Danger,
    Ghost,
    Navigation
}

internal sealed class ThemedButton : Button
{
    private bool _hovered;
    private bool _pressed;

    internal ThemedButton()
    {
        SetStyle(
            ControlStyles.UserPaint
            | ControlStyles.AllPaintingInWmPaint
            | ControlStyles.OptimizedDoubleBuffer
            | ControlStyles.SupportsTransparentBackColor,
            true);
        DoubleBuffered = true;
        FlatStyle = FlatStyle.Flat;
        FlatAppearance.BorderSize = 0;
        BackColor = Color.Transparent;
        ForeColor = Theme.TextPrimary;
        Cursor = Cursors.Hand;
        Font = Theme.Font(9.5F, semibold: true);
        Radius = 7;
        ButtonStyle = ThemedButtonStyle.Secondary;
        TabStop = true;
    }

    internal ThemedButtonStyle ButtonStyle { get; set; }
    internal bool Selected { get; set; }
    internal int Radius { get; set; }

    protected override void OnMouseEnter(EventArgs e)
    {
        _hovered = true;
        Invalidate();
        base.OnMouseEnter(e);
    }

    protected override void OnMouseLeave(EventArgs e)
    {
        _hovered = false;
        _pressed = false;
        Invalidate();
        base.OnMouseLeave(e);
    }

    protected override void OnMouseDown(MouseEventArgs mevent)
    {
        _pressed = true;
        Invalidate();
        base.OnMouseDown(mevent);
    }

    protected override void OnMouseUp(MouseEventArgs mevent)
    {
        _pressed = false;
        Invalidate();
        base.OnMouseUp(mevent);
    }

    protected override void OnEnabledChanged(EventArgs e)
    {
        base.OnEnabledChanged(e);
        Invalidate();
    }

    protected override void OnPaint(PaintEventArgs pevent)
    {
        pevent.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
        var bounds = new Rectangle(0, 0, Width - 1, Height - 1);
        using var path = Theme.RoundedRectangle(bounds, Radius);
        var (background, border, foreground) = ResolveColors();
        using var fill = new SolidBrush(background);
        using var pen = new Pen(border);
        pevent.Graphics.FillPath(fill, path);
        pevent.Graphics.DrawPath(pen, path);
        TextRenderer.DrawText(
            pevent.Graphics,
            Text,
            Font,
            bounds,
            foreground,
            TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.EndEllipsis);
    }

    private (Color Background, Color Border, Color Foreground) ResolveColors()
    {
        if (!Enabled)
        {
            return (Theme.Surface, Theme.BorderSoft, Theme.TextMuted);
        }

        var darken = _pressed;
        return ButtonStyle switch
        {
            ThemedButtonStyle.Primary =>
                (darken ? Theme.AccentDark : _hovered ? Color.FromArgb(255, 67, 55) : Theme.Accent,
                 Theme.Accent,
                 Color.White),
            ThemedButtonStyle.Danger =>
                (_hovered ? Theme.AccentMuted : Theme.Background, Theme.AccentDark, Theme.Accent),
            ThemedButtonStyle.Ghost =>
                (_hovered ? Theme.SurfaceHover : Color.Transparent, Theme.BorderSoft, Theme.TextSecondary),
            ThemedButtonStyle.Navigation =>
                (Selected ? Theme.AccentMuted : _hovered ? Theme.Surface : Color.Transparent,
                 Selected ? Theme.AccentDark : Color.Transparent,
                 Selected ? Theme.TextPrimary : Theme.TextSecondary),
            _ =>
                (darken ? Theme.Surface : _hovered ? Theme.SurfaceHover : Theme.SurfaceRaised,
                 Theme.Border,
                 Theme.TextPrimary)
        };
    }
}

internal sealed class ToggleSwitch : CheckBox
{
    internal ToggleSwitch()
    {
        AutoSize = false;
        Size = new Size(44, 24);
        Cursor = Cursors.Hand;
        SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);
    }

    protected override void OnPaint(PaintEventArgs e)
    {
        e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
        var track = new Rectangle(1, 3, Width - 3, Height - 7);
        using var trackPath = Theme.RoundedRectangle(track, track.Height / 2);
        using var trackBrush = new SolidBrush(Checked ? Theme.Accent : Theme.SurfaceRaised);
        using var border = new Pen(Checked ? Theme.Accent : Theme.Border);
        e.Graphics.FillPath(trackBrush, trackPath);
        e.Graphics.DrawPath(border, trackPath);

        var knobSize = track.Height - 4;
        var knobX = Checked ? track.Right - knobSize - 2 : track.Left + 2;
        using var knobBrush = new SolidBrush(Color.White);
        e.Graphics.FillEllipse(knobBrush, knobX, track.Top + 2, knobSize, knobSize);
    }
}

internal sealed class LogoMark : Control
{
    internal LogoMark()
    {
        DoubleBuffered = true;
        Size = new Size(38, 38);
    }

    protected override void OnPaint(PaintEventArgs e)
    {
        e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
        var bounds = new Rectangle(1, 1, Width - 3, Height - 3);
        using var path = Theme.RoundedRectangle(bounds, 9);
        using var glow = new SolidBrush(Theme.AccentMuted);
        using var border = new Pen(Theme.AccentDark, 1.4F);
        e.Graphics.FillPath(glow, path);
        e.Graphics.DrawPath(border, path);

        using var rayPen = new Pen(Theme.Accent, 2F) { StartCap = LineCap.Round, EndCap = LineCap.Round };
        var center = new PointF(18F, 17F);
        for (var index = 0; index < 8; index++)
        {
            var angle = index * Math.PI / 4d;
            var start = new PointF(
                center.X + (float)Math.Cos(angle) * 7F,
                center.Y + (float)Math.Sin(angle) * 7F);
            var end = new PointF(
                center.X + (float)Math.Cos(angle) * 11F,
                center.Y + (float)Math.Sin(angle) * 11F);
            e.Graphics.DrawLine(rayPen, start, end);
        }

        var cursor = new[]
        {
            new PointF(17F, 14F),
            new PointF(27F, 26F),
            new PointF(22F, 25F),
            new PointF(20F, 31F)
        };
        using var cursorBrush = new SolidBrush(Color.White);
        e.Graphics.FillPolygon(cursorBrush, cursor);
    }
}
